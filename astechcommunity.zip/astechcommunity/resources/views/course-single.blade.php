﻿@extends('layouts.front')

@section('content')
<h1>Course Single Page</h1>
@endsection

