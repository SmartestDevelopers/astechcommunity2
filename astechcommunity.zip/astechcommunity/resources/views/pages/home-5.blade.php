<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Google fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com/">
  <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">

  <link rel="stylesheet" href="../../../cdn.jsdelivr.net/npm/choices.js/public/assets/styles/base.min.css') }}" />
  <link rel="stylesheet" href="../../../cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css') }}" />

  <link href="https://fonts.googleapis.com/css2?family=Material+Icons+Outlined" rel="stylesheet">
  <link rel="stylesheet" href="../../../cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css') }}" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="../../../unpkg.com/leaflet%401.7.1/dist/leaflet.css') }}" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />

  <!-- Stylesheets -->
  <link rel="stylesheet" href="{{ asset('template/css/vendors.css') }}">
  <link rel="stylesheet" href="{{ asset('template/css/main.css') }}">

  <title>Educrat</title>
</head>

<body class="preloader-visible" data-barba="wrapper">
  <!-- preloader start -->
  <div class="preloader js-preloader">
    <div class="preloader__bg"></div>
  </div>
  <!-- preloader end -->


  <main class="main-content  ">

    <header data-anim="fade" data-add-bg="" class="header -type-4 -shadow bg-white js-header">


      <div class="header__container border-bottom-light py-10">
        <div class="row justify-between items-center">

          <div class="col-auto">
            <div class="header-left d-flex items-center">

              <div class="header__logo pr-30 xl:pr-20 md:pr-0">
                <a data-barba href="{{ route('home') }}">
                  <img src="{{ asset('template/img/general/logo-dark.svg') }}" alt="logo">
                </a>
              </div>


              <div class="header__explore px-30 xl:px-20 -before-border -after-border xl:d-none">
                <a href="#" class="d-flex items-center" data-el-toggle=".js-explore-toggle">
                  <i class="icon icon-explore mr-15"></i>
                  Explore
                </a>

                <div class="explore-content py-25 rounded-8 bg-white toggle-element js-explore-toggle">

                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Architecture<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Business<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="text-dark-1">Computer Programming</a>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="text-dark-1">Data Analysis</a>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Design<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="{{ route('courses.single-6') }}" class="text-dark-1">Education</a>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Electronics<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Language<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Marketing<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="text-dark-1">Music Arts</a>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="text-dark-1">Social Science</a>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Photography & Video<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="{{ route('courses.single-1') }}" class="text-dark-1">IT & Software</a>
                  </div>

                  <div class="explore__item">
                    <a href="{{ route('courses.single-2') }}" class="text-purple-1 underline">View All Courses</a>
                  </div>
                </div>
              </div>


              <div class="header-menu js-mobile-menu-toggle pl-30 xl:pl-20">
                <div class="header-menu__content">
                  <div class="mobile-bg js-mobile-bg"></div>

                  <div class="d-none xl:d-flex items-center px-20 py-20 border-bottom-light">
                    <a href="{{ route('login') }}" class="text-dark-1">Log in</a>
                    <a href="{{ route('register') }}" class="text-dark-1 ml-30">Sign Up</a>
                  </div>

                  <div class="menu js-navList">
                    <ul class="menu__nav text-dark-1 -is-active">
                      <li class="menu-item-has-children">
                        <a data-barba href="#">
                          Home <i class="icon-chevron-right text-13 ml-10"></i>
                        </a>

                        <ul class="subnav">
                          <li class="menu__backButton js-nav-list-back">
                            <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Home</a>
                          </li>

                          <li><a href="{{ route('home') }}">Home 1</a></li>

                          <li><a href="{{ route('pages.home-2') }}">Home 2</a></li>

                          <li><a href="{{ route('pages.home-3') }}">Home 3</a></li>

                          <li><a href="home-4.html">Home 4</a></li>

                          <li><a href="home-5.html">Home 5</a></li>

                          <li><a href="home-6.html">Home 6</a></li>

                          <li><a href="home-7.html">Home 7</a></li>

                          <li><a href="home-8.html">Home 8</a></li>

                          <li><a href="home-9.html">Home 9</a></li>

                          <li><a href="home-10.html">Home 10</a></li>

                        </ul>
                      </li>

                      <li class="menu-item-has-children -has-mega-menu">
                        <a data-barba href="#">Courses <i class="icon-chevron-right text-13 ml-10"></i></a>


                        <div class="mega xl:d-none">
                          <div class="mega__menu">
                            <div class="row x-gap-40">
                              <div class="col">
                                <h4 class="text-17 fw-500 mb-20">Course List Layouts</h4>

                                <ul class="mega__list">

                                  <li><a data-barba href="{{ route('courses.list-1') }}">Course List v1</a></li>

                                  <li><a data-barba href="{{ route('courses.list-2') }}">Course List v2</a></li>

                                  <li><a data-barba href="{{ route('courses.list-3') }}">Course List v3</a></li>

                                  <li><a data-barba href="{{ route('courses.list-4') }}">Course List v4</a></li>

                                  <li><a data-barba href="{{ route('courses.list-5') }}">Course List v5</a></li>

                                  <li><a data-barba href="{{ route('courses.list-6') }}">Course List v6</a></li>

                                  <li><a data-barba href="{{ route('courses.list-7') }}">Course List v7</a></li>

                                  <li><a data-barba href="{{ route('courses.list-8') }}">Course List v8</a></li>

                                  <li><a data-barba href="{{ route('courses.list-9') }}">Course List v9</a></li>

                                </ul>

                              </div>

                              <div class="col">
                                <h4 class="text-17 fw-500 mb-20">Course Single Layouts</h4>

                                <ul class="mega__list">

                                  <li><a data-barba href="{{ route('courses.single-1') }}">Course Single v1</a></li>

                                  <li><a data-barba href="{{ route('courses.single-2') }}">Course Single v2</a></li>

                                  <li><a data-barba href="{{ route('courses.single-3') }}">Course Single v3</a></li>

                                  <li><a data-barba href="{{ route('courses.single-4') }}">Course Single v4</a></li>

                                  <li><a data-barba href="{{ route('courses.single-5') }}">Course Single v5</a></li>

                                  <li><a data-barba href="{{ route('courses.single-6') }}">Course Single v6</a></li>

                                </ul>

                              </div>

                              <div class="col">
                                <h4 class="text-17 fw-500 mb-20">About Courses</h4>

                                <ul class="mega__list">

                                  <li><a data-barba href="lesson-single-1.html">Lesson Page v1</a></li>

                                  <li><a data-barba href="lesson-single-2.html">Lesson Page v2</a></li>

                                  <li><a data-barba href="instructors-list-1.html">Instructors List v1</a></li>

                                  <li><a data-barba href="instructors-list-2.html">Instructors List v2</a></li>

                                  <li><a data-barba href="instructors-single.html">Instructors Single</a></li>

                                  <li><a data-barba href="instructors-become.html">Become an Instructor</a></li>

                                </ul>

                              </div>

                              <div class="col">
                                <h4 class="text-17 fw-500 mb-20">Dashboard Pages</h4>

                                <ul class="mega__list">

                                  <li><a data-barba href="dashboard.html">Dashboard</a></li>

                                  <li><a data-barba href="dshb-courses.html">My Courses</a></li>

                                  <li><a data-barba href="dshb-bookmarks.html">Bookmarks</a></li>

                                  <li><a data-barba href="dshb-listing.html">Add Listing</a></li>

                                  <li><a data-barba href="dshb-reviews.html">Reviews</a></li>

                                  <li><a data-barba href="dshb-settings.html">Settings</a></li>

                                  <li><a data-barba href="dshb-administration.html">Administration</a></li>

                                  <li><a data-barba href="dshb-assignment.html">Assignment</a></li>

                                  <li><a data-barba href="dshb-calendar.html">Calendar</a></li>

                                  <li><a data-barba href="dshb-dashboard.html">Single Dashboard</a></li>

                                  <li><a data-barba href="dshb-dictionary.html">Dictionary</a></li>

                                  <li><a data-barba href="dshb-forums.html">Forums</a></li>

                                  <li><a data-barba href="dshb-grades.html">Grades</a></li>

                                  <li><a data-barba href="dshb-messages.html">Messages</a></li>

                                  <li><a data-barba href="dshb-participants.html">Participants</a></li>

                                  <li><a data-barba href="dshb-quiz.html">Quiz</a></li>

                                  <li><a data-barba href="dshb-survey.html">Survey</a></li>

                                </ul>

                              </div>

                              <div class="col">
                                <h4 class="text-17 fw-500 mb-20">Popular Courses</h4>

                                <ul class="mega__list">

                                  <li><a data-barba href="#">Web Developer</a></li>

                                  <li><a data-barba href="#">Mobile Developer</a></li>

                                  <li><a data-barba href="#">Digital Marketing</a></li>

                                  <li><a data-barba href="#">Development</a></li>

                                  <li><a data-barba href="#">Finance &amp; Accounting</a></li>

                                  <li><a data-barba href="#">Design</a></li>

                                  <li><a data-barba href="#">View All Courses</a></li>

                                </ul>

                              </div>
                            </div>

                            <div class="mega-banner bg-purple-1 ml-40">
                              <div class="text-24 lh-15 text-white fw-700">
                                Join more than<br>
                                <span class="text-green-1">8 million learners</span>
                                worldwide
                              </div>
                              <a href="#" class="button -md -green-1 text-dark-1 fw-500 col-12">Start Learning For Free</a>
                            </div>
                          </div>
                        </div>


                        <ul class="subnav d-none xl:d-block">
                          <li class="menu__backButton js-nav-list-back">
                            <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Courses</a>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">Course List Layouts<div class="icon-chevron-right text-11"></div></a>

                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Course List Layouts</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-1') }}">Course List v1</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-2') }}">Course List v2</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-3') }}">Course List v3</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-4') }}">Course List v4</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-5') }}">Course List v5</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-6') }}">Course List v6</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-7') }}">Course List v7</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-8') }}">Course List v8</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-all') }}">Course List All</a>
                              </li>

                            </ul>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">Course Single Layouts<div class="icon-chevron-right text-11"></div></a>

                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Course Single Layouts</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.single-1') }}">Course Single v1</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.single-2') }}">Course Single v2</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.single-3') }}">Course Single v3</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.single-4') }}">Course Single v4</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.single-5') }}">Course Single v5</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.single-6') }}">Course Single v6</a>
                              </li>

                            </ul>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">About Courses<div class="icon-chevron-right text-11"></div></a>

                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> About Courses</a>
                              </li>

                              <li>
                                <a href="lesson-single-1.html">Lesson Page v1</a>
                              </li>

                              <li>
                                <a href="lesson-single-2.html">Lesson Page v2</a>
                              </li>

                              <li>
                                <a href="instructors-list-1.html">Instructors List v1</a>
                              </li>

                              <li>
                                <a href="instructors-list-2.html">Instructors List v2</a>
                              </li>

                              <li>
                                <a href="instructors-single.html">Instructors Single</a>
                              </li>

                              <li>
                                <a href="instructors-become.html">Become an Instructor</a>
                              </li>

                            </ul>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">Dashboard Pages<div class="icon-chevron-right text-11"></div></a>

                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Dashboard Pages</a>
                              </li>

                              <li>
                                <a href="dashboard.html">Dashboard</a>
                              </li>

                              <li>
                                <a href="dshb-courses.html">My Courses</a>
                              </li>

                              <li>
                                <a href="dshb-bookmarks.html">Bookmarks</a>
                              </li>

                              <li>
                                <a href="dshb-listing.html">Add Listing</a>
                              </li>

                              <li>
                                <a href="dshb-reviews.html">Reviews</a>
                              </li>

                              <li>
                                <a href="dshb-settings.html">Settings</a>
                              </li>

                              <li>
                                <a href="dshb-administration.html">Administration</a>
                              </li>

                              <li>
                                <a href="dshb-assignment.html">Assignment</a>
                              </li>

                              <li>
                                <a href="dshb-calendar.html">Calendar</a>
                              </li>

                              <li>
                                <a href="dshb-dashboard.html">Single Dashboard</a>
                              </li>

                              <li>
                                <a href="dshb-dictionary.html">Dictionary</a>
                              </li>

                              <li>
                                <a href="dshb-forums.html">Forums</a>
                              </li>

                              <li>
                                <a href="dshb-grades.html">Grades</a>
                              </li>

                              <li>
                                <a href="dshb-messages.html">Messages</a>
                              </li>

                              <li>
                                <a href="dshb-participants.html">Participants</a>
                              </li>

                              <li>
                                <a href="dshb-quiz.html">Quiz</a>
                              </li>

                              <li>
                                <a href="dshb-survey.html">Survey</a>
                              </li>

                            </ul>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">Popular Courses<div class="icon-chevron-right text-11"></div></a>

                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Popular Courses</a>
                              </li>

                              <li>
                                <a href="#">Web Developer</a>
                              </li>

                              <li>
                                <a href="#">Mobile Developer</a>
                              </li>

                              <li>
                                <a href="#">Digital Marketing</a>
                              </li>

                              <li>
                                <a href="#">Development</a>
                              </li>

                              <li>
                                <a href="#">Finance &amp; Accounting</a>
                              </li>

                              <li>
                                <a href="#">Design</a>
                              </li>

                              <li>
                                <a href="#">View All Courses</a>
                              </li>

                            </ul>
                          </li>
                        </ul>
                      </li>

                      <li class="menu-item-has-children">
                        <a data-barba href="#">Events <i class="icon-chevron-right text-13 ml-10"></i></a>
                        <ul class="subnav">
                          <li class="menu__backButton js-nav-list-back">
                            <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Events</a>
                          </li>

                          <li><a href="event-list-1.html">Event List 1</a></li>

                          <li><a href="event-list-2.html">Event List 2</a></li>

                          <li><a href="event-single.html">Event Single</a></li>

                        </ul>
                      </li>

                      <li class="menu-item-has-children">
                        <a data-barba href="#">Blog <i class="icon-chevron-right text-13 ml-10"></i></a>
                        <ul class="subnav">
                          <li class="menu__backButton js-nav-list-back">
                            <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Blog</a>
                          </li>

                          <li><a href="blog-list-1.html">Blog List 1</a></li>

                          <li><a href="blog-list-2.html">Blog List 2</a></li>

                          <li><a href="blog-list-3.html">Blog List 3</a></li>

                          <li><a href="blog-single.html">Blog Single</a></li>

                        </ul>
                      </li>

                      <li class="menu-item-has-children">
                        <a data-barba href="#">
                          Pages <i class="icon-chevron-right text-13 ml-10"></i>
                        </a>

                        <ul class="subnav">
                          <li class="menu__backButton js-nav-list-back">
                            <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Pages</a>
                          </li>
                          <li class="menu-item-has-children">
                            <a href="#">About Us<div class="icon-chevron-right text-11"></div></a>

                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> About Us</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.about-1') }}">About 1</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.about-2') }}">About 2</a>
                              </li>

                            </ul>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">Contact<div class="icon-chevron-right text-11"></div></a>
                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Contact</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.contact-1') }}">Contact 1</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.contact-2') }}">Contact 2</a>
                              </li>

                            </ul>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">Shop<div class="icon-chevron-right text-11"></div></a>
                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Shop</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.shop-cart') }}">Shop Cart</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.shop-checkout') }}">Shop Checkout</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.shop-list') }}">Shop List</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.shop-order') }}">Shop Order</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.shop-single') }}">Shop Single</a>
                              </li>

                            </ul>
                          </li>


                          <li>
                            <a href="pricing.html">Membership plans</a>
                          </li>

                          <li>
                            <a href="404.html">404 Page</a>
                          </li>

                          <li>
                            <a href="terms.html">FAQs</a>
                          </li>

                          <li>
                            <a href="help-center.html">Help Center</a>
                          </li>

                          <li>
                            <a href="{{ route('login') }}">Login</a>
                          </li>

                          <li>
                            <a href="{{ route('register') }}">Register</a>
                          </li>

                          <li>
                            <a href="ui-elements.html">UI Elements</a>
                          </li>

                        </ul>
                      </li>

                      <li>
                        <a data-barba href="{{ route('pages.contact-1') }}">Contact</a>
                      </li>
                    </ul>
                  </div>

                  <div class="mobile-footer px-20 py-20 border-top-light js-mobile-footer">
                    <div class="mobile-footer__number">
                      <div class="text-17 fw-500 text-dark-1">Call us</div>
                      <div class="text-17 fw-500 text-purple-1">800 388 80 90</div>
                    </div>

                    <div class="lh-2 mt-10">
                      <div>329 Queensberry Street,<br> North Melbourne VIC 3051, Australia.</div>
                      <div>hi@educrat.com</div>
                    </div>

                    <div class="mobile-socials mt-10">

                      <a href="#" class="d-flex items-center justify-center rounded-full size-40">
                        <i class="fa fa-facebook"></i>
                      </a>

                      <a href="#" class="d-flex items-center justify-center rounded-full size-40">
                        <i class="fa fa-twitter"></i>
                      </a>

                      <a href="#" class="d-flex items-center justify-center rounded-full size-40">
                        <i class="fa fa-instagram"></i>
                      </a>

                      <a href="#" class="d-flex items-center justify-center rounded-full size-40">
                        <i class="fa fa-linkedin"></i>
                      </a>

                    </div>
                  </div>
                </div>

                <div class="header-menu-close" data-el-toggle=".js-mobile-menu-toggle">
                  <div class="size-40 d-flex items-center justify-center rounded-full bg-white">
                    <div class="icon-close text-dark-1 text-16"></div>
                  </div>
                </div>

                <div class="header-menu-bg"></div>
              </div>

            </div>
          </div>


          <div class="col-auto">
            <div class="header-right d-flex items-center">
              <div class="header-right__icons text-white d-flex items-center">
                <div class="header-search-field">
                  <form action="#">
                    <div class="header-search-field__group">
                      <input type="text" placeholder="What do you want to learn?">
                      <button type="submit">
                        <i class="icon icon-search"></i>
                      </button>
                    </div>
                  </form>
                </div>


                <div class="relative -after-border pl-20 sm:pl-15">
                  <button class="d-flex items-center text-dark-1" data-el-toggle=".js-cart-toggle">
                    <i class="text-20 icon icon-basket"></i>
                  </button>

                  <div class="toggle-element js-cart-toggle">
                    <div class="header-cart bg-white -dark-bg-dark-1 rounded-8">
                      <div class="px-30 pt-30 pb-10">

                        <div class="row justify-between x-gap-40 pb-20">
                          <div class="col">
                            <div class="row x-gap-10 y-gap-10">
                              <div class="col-auto">
                                <img src="{{ asset('template/img/menus/cart/1.png') }}" alt="image">
                              </div>

                              <div class="col">
                                <div class="text-dark-1 lh-15">The Ultimate Drawing Course Beginner to Advanced...</div>

                                <div class="d-flex items-center mt-10">
                                  <div class="lh-12 fw-500 line-through text-light-1 mr-10">$179</div>
                                  <div class="text-18 lh-12 fw-500 text-dark-1">$79</div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="col-auto">
                            <button><img src="{{ asset('template/img/menus/close.svg') }}" alt="icon"></button>
                          </div>
                        </div>

                        <div class="row justify-between x-gap-40 pb-20">
                          <div class="col">
                            <div class="row x-gap-10 y-gap-10">
                              <div class="col-auto">
                                <img src="{{ asset('template/img/menus/cart/2.png') }}" alt="image">
                              </div>

                              <div class="col">
                                <div class="text-dark-1 lh-15">User Experience Design Essentials - Adobe XD UI UX...</div>

                                <div class="d-flex items-center mt-10">
                                  <div class="lh-12 fw-500 line-through text-light-1 mr-10">$179</div>
                                  <div class="text-18 lh-12 fw-500 text-dark-1">$79</div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="col-auto">
                            <button><img src="{{ asset('template/img/menus/close.svg') }}" alt="icon"></button>
                          </div>
                        </div>

                      </div>

                      <div class="px-30 pt-20 pb-30 border-top-light">
                        <div class="d-flex justify-between">
                          <div class="text-18 lh-12 text-dark-1 fw-500">Total:</div>
                          <div class="text-18 lh-12 text-dark-1 fw-500">$659</div>
                        </div>

                        <div class="row x-gap-20 y-gap-10 pt-30">
                          <div class="col-sm-6">
                            <button class="button py-20 -dark-1 text-white -dark-button-white col-12">View Cart</button>
                          </div>
                          <div class="col-sm-6">
                            <button class="button py-20 -purple-1 text-white col-12">Checkout</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


                <div class="d-none xl:d-block pl-20 sm:pl-15">
                  <button class="text-dark-1 items-center" data-el-toggle=".js-mobile-menu-toggle">
                    <i class="text-11 icon icon-mobile-menu"></i>
                  </button>
                </div>

              </div>

              <div class="header-right__buttons d-flex items-center ml-30 xl:ml-20 lg:d-none">
                <a href="{{ route('login') }}" class="button -underline text-purple-1">Log in</a>
                <a href="{{ route('register') }}" class="button h-50 px-30 -purple-1 -rounded text-white ml-20">Sign up</a>
              </div>
            </div>
          </div>

        </div>
      </div>
    </header>


    <div class="content-wrapper  js-content-wrapper">


      <section data-anim-wrap class="masthead -type-4">
        <div class="container">
          <div class="row y-gap-50 justify-center items-center">
            <div class="col-xl-5 col-lg-6">
              <div class="masthead__content">
                <h1 data-anim-child="slide-up delay-3" class="masthead__title">
                  Master the Skills to<br>
                  Drive your <span class="text-purple-1 underline">Career</span>
                </h1>
                <p data-anim-child="slide-up delay-4" class="masthead__text pt-15">
                  Free online courses from the world�s leading experts.<br class="md:d-none">
                  Join 17 million learners today
                </p>
                <div data-anim-child="slide-up delay-5" class="masthead__button row x-gap-20 y-gap-20 pt-30">
                  <div class="col-auto"><a href="#" class="button -md -purple-1 -rounded text-white">Join For Free</a></div>
                  <div class="col-auto"><a href="#" class="button -md -outline-dark-1 -rounded text-dark-1">Find Courses</a></div>
                </div>
              </div>
            </div>

            <div class="col-xl-6 col-lg-6">
              <div data-anim-child="slide-up delay-6" class="masthead__image">
                <img src="{{ asset('template/img/home-5/masthead/bg.svg') }}" alt="image">
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-sm layout-pb-sm bg-light-6">
        <div class="container">
          <div class="row y-gap-30 justify-between sm:justify-start items-center">

            <div class="col-lg-auto col-md-2 col-sm-3 col-4">
              <div class="d-flex justify-center items-center px-4">
                <img class="w-1/1" src="{{ asset('template/img/clients/1.svg') }}" alt="clients image">
              </div>
            </div>

            <div class="col-lg-auto col-md-2 col-sm-3 col-4">
              <div class="d-flex justify-center items-center px-4">
                <img class="w-1/1" src="{{ asset('template/img/clients/2.svg') }}" alt="clients image">
              </div>
            </div>

            <div class="col-lg-auto col-md-2 col-sm-3 col-4">
              <div class="d-flex justify-center items-center px-4">
                <img class="w-1/1" src="{{ asset('template/img/clients/3.svg') }}" alt="clients image">
              </div>
            </div>

            <div class="col-lg-auto col-md-2 col-sm-3 col-4">
              <div class="d-flex justify-center items-center px-4">
                <img class="w-1/1" src="{{ asset('template/img/clients/4.svg') }}" alt="clients image">
              </div>
            </div>

            <div class="col-lg-auto col-md-2 col-sm-3 col-4">
              <div class="d-flex justify-center items-center px-4">
                <img class="w-1/1" src="{{ asset('template/img/clients/5.svg') }}" alt="clients image">
              </div>
            </div>

            <div class="col-lg-auto col-md-2 col-sm-3 col-4">
              <div class="d-flex justify-center items-center px-4">
                <img class="w-1/1" src="{{ asset('template/img/clients/6.svg') }}" alt="clients image">
              </div>
            </div>

          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-md">
        <div data-anim-wrap class="container">
          <div class="tabs -pills js-tabs">
            <div class="row y-gap-20 justify-between items-end">
              <div class="col-auto">

                <div class="sectionTitle ">

                  <h2 class="sectionTitle__title ">Explore Featured Courses</h2>

                  <p class="sectionTitle__text ">10,000+ unique online course list designs</p>

                </div>

              </div>

              <div class="col-auto">
                <div class="tabs__controls d-flex justify-center x-gap-10 js-tabs-controls">

                  <div>
                    <button class="tabs__button px-20 py-8 rounded-200 js-tabs-button is-active" data-tab-target=".-tab-item-1" type="button">All</button>
                  </div>

                  <div>
                    <button class="tabs__button px-20 py-8 rounded-200 js-tabs-button " data-tab-target=".-tab-item-2" type="button">Trending</button>
                  </div>

                  <div>
                    <button class="tabs__button px-20 py-8 rounded-200 js-tabs-button " data-tab-target=".-tab-item-3" type="button">Popular</button>
                  </div>

                  <div>
                    <button class="tabs__button px-20 py-8 rounded-200 js-tabs-button " data-tab-target=".-tab-item-4" type="button">Fetured</button>
                  </div>

                </div>
              </div>
            </div>

            <div class="tabs__content pt-60 lg:pt-50 js-tabs-content">

              <div class="tabs__pane -tab-item-1 is-active">
                <div class="overflow-hidden js-section-slider" data-gap="30" data-slider-cols="xl-4 lg-3 md-2 sm-2">
                  <div class="swiper-wrapper">

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-1">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/1.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Learn Figma - UI/UX Design Essential Training</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-2">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/2.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                              <div>
                                <div class="px-15 rounded-200 bg-purple-1">
                                  <span class="text-11 lh-1 uppercase fw-500 text-white">Popular</span>
                                </div>
                              </div>

                              <div>
                                <div class="px-15 rounded-200 bg-green-1">
                                  <span class="text-11 lh-1 uppercase fw-500 text-dark-1">Best sellers</span>
                                </div>
                              </div>

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Python Bootcamp From Zero to Hero in Python</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-3">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/3.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Angular - The Complete Guide (2022 Edition)</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-4">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/4.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Ultimate Drawing Course Beginner to Advanced</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-5">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/5.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Photography Masterclass: A Complete Guide to Photography</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-6">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/6.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Instagram Marketing 2021: Complete Guide To Instagram</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-7">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/7.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Blender Creator: Learn 3D Modelling for Beginners</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-8">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/8.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Complete Financial Analyst Training &amp; Investing Course</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                  </div>


                  <button class="section-slider-nav -prev -dark-bg-dark-2 -white -absolute size-70 rounded-full shadow-5 js-prev">
                    <i class="icon icon-arrow-left text-24"></i>
                  </button>

                  <button class="section-slider-nav -next -dark-bg-dark-2 -white -absolute size-70 rounded-full shadow-5 js-next">
                    <i class="icon icon-arrow-right text-24"></i>
                  </button>

                </div>
              </div>

              <div class="tabs__pane -tab-item-2 ">
                <div class="overflow-hidden js-section-slider" data-gap="30" data-slider-cols="xl-4 lg-3 md-2 sm-2">
                  <div class="swiper-wrapper">

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-1">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/1.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Learn Figma - UI/UX Design Essential Training</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-2">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/2.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                              <div>
                                <div class="px-15 rounded-200 bg-purple-1">
                                  <span class="text-11 lh-1 uppercase fw-500 text-white">Popular</span>
                                </div>
                              </div>

                              <div>
                                <div class="px-15 rounded-200 bg-green-1">
                                  <span class="text-11 lh-1 uppercase fw-500 text-dark-1">Best sellers</span>
                                </div>
                              </div>

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Python Bootcamp From Zero to Hero in Python</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-3">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/3.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Angular - The Complete Guide (2022 Edition)</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-4">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/4.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Ultimate Drawing Course Beginner to Advanced</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-5">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/5.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Photography Masterclass: A Complete Guide to Photography</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-6">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/6.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Instagram Marketing 2021: Complete Guide To Instagram</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-7">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/7.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Blender Creator: Learn 3D Modelling for Beginners</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-8">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/8.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Complete Financial Analyst Training &amp; Investing Course</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                  </div>


                  <button class="section-slider-nav -prev -dark-bg-dark-2 -white -absolute size-70 rounded-full shadow-5 js-prev">
                    <i class="icon icon-arrow-left text-24"></i>
                  </button>

                  <button class="section-slider-nav -next -dark-bg-dark-2 -white -absolute size-70 rounded-full shadow-5 js-next">
                    <i class="icon icon-arrow-right text-24"></i>
                  </button>

                </div>
              </div>

              <div class="tabs__pane -tab-item-3 ">
                <div class="overflow-hidden js-section-slider" data-gap="30" data-slider-cols="xl-4 lg-3 md-2 sm-2">
                  <div class="swiper-wrapper">

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-1">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/1.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Learn Figma - UI/UX Design Essential Training</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-2">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/2.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                              <div>
                                <div class="px-15 rounded-200 bg-purple-1">
                                  <span class="text-11 lh-1 uppercase fw-500 text-white">Popular</span>
                                </div>
                              </div>

                              <div>
                                <div class="px-15 rounded-200 bg-green-1">
                                  <span class="text-11 lh-1 uppercase fw-500 text-dark-1">Best sellers</span>
                                </div>
                              </div>

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Python Bootcamp From Zero to Hero in Python</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-3">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/3.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Angular - The Complete Guide (2022 Edition)</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-4">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/4.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Ultimate Drawing Course Beginner to Advanced</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-5">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/5.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Photography Masterclass: A Complete Guide to Photography</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-6">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/6.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Instagram Marketing 2021: Complete Guide To Instagram</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-7">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/7.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Blender Creator: Learn 3D Modelling for Beginners</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-8">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/8.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Complete Financial Analyst Training &amp; Investing Course</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                  </div>


                  <button class="section-slider-nav -prev -dark-bg-dark-2 -white -absolute size-70 rounded-full shadow-5 js-prev">
                    <i class="icon icon-arrow-left text-24"></i>
                  </button>

                  <button class="section-slider-nav -next -dark-bg-dark-2 -white -absolute size-70 rounded-full shadow-5 js-next">
                    <i class="icon icon-arrow-right text-24"></i>
                  </button>

                </div>
              </div>

              <div class="tabs__pane -tab-item-4 ">
                <div class="overflow-hidden js-section-slider" data-gap="30" data-slider-cols="xl-4 lg-3 md-2 sm-2">
                  <div class="swiper-wrapper">

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-1">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/1.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Learn Figma - UI/UX Design Essential Training</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-2">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/2.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                              <div>
                                <div class="px-15 rounded-200 bg-purple-1">
                                  <span class="text-11 lh-1 uppercase fw-500 text-white">Popular</span>
                                </div>
                              </div>

                              <div>
                                <div class="px-15 rounded-200 bg-green-1">
                                  <span class="text-11 lh-1 uppercase fw-500 text-dark-1">Best sellers</span>
                                </div>
                              </div>

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Python Bootcamp From Zero to Hero in Python</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-3">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/3.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Angular - The Complete Guide (2022 Edition)</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-4">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/4.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Ultimate Drawing Course Beginner to Advanced</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-5">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/5.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Photography Masterclass: A Complete Guide to Photography</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-6">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/6.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Instagram Marketing 2021: Complete Guide To Instagram</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-7">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/7.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Blender Creator: Learn 3D Modelling for Beginners</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                    <div class="swiper-slide">
                      <div data-anim-child="slide-up delay-8">

                        <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 ">
                          <div class="relative">
                            <div class="coursesCard__image overflow-hidden rounded-8">
                              <img class="w-1/1" src="{{ asset('template/img/coursesCards/8.png') }}" alt="image">
                              <div class="coursesCard__image_overlay rounded-8"></div>
                            </div>
                            <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                            </div>
                          </div>

                          <div class="h-100 pt-15">
                            <div class="d-flex items-center">
                              <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                              <div class="d-flex x-gap-5 items-center">
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                                <div class="icon-star text-9 text-yellow-1"></div>
                              </div>
                              <div class="text-13 lh-1 ml-10">(1991)</div>
                            </div>

                            <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Complete Financial Analyst Training &amp; Investing Course</div>

                            <div class="d-flex x-gap-10 items-center pt-10">

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">6 lesson</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">3h 56m</div>
                              </div>

                              <div class="d-flex items-center">
                                <div class="mr-8">
                                  <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                                </div>
                                <div class="text-14 lh-1">Beginner</div>
                              </div>

                            </div>

                            <div class="coursesCard-footer">
                              <div class="coursesCard-footer__author">
                                <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                                <div>Ali Tufan</div>
                              </div>

                              <div class="coursesCard-footer__price">
                                <div>$179</div>
                                <div>$79</div>
                              </div>
                            </div>
                          </div>
                        </a>

                      </div>
                    </div>

                  </div>


                  <button class="section-slider-nav -prev -dark-bg-dark-2 -white -absolute size-70 rounded-full shadow-5 js-prev">
                    <i class="icon icon-arrow-left text-24"></i>
                  </button>

                  <button class="section-slider-nav -next -dark-bg-dark-2 -white -absolute size-70 rounded-full shadow-5 js-next">
                    <i class="icon icon-arrow-right text-24"></i>
                  </button>

                </div>
              </div>

            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-md layout-pb-lg">
        <div class="container">
          <div class="row y-gap-20 justify-between items-end">
            <div class="col-auto">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Top Categories</h2>

                <p class="sectionTitle__text ">10,000+ unique online course list designs</p>

              </div>

            </div>

            <div class="col-auto">

              <a href="#" class="button -icon -purple-3 text-purple-1">
                All Categories
                <i class="icon-arrow-top-right text-13 ml-10"></i>
              </a>

            </div>
          </div>

          <div data-anim-wrap class="row y-gap-30 pt-50">

            <div class="col-xl-3 col-md-6" data-anim-child="scale delay-1">
              <a href="#" class="categoryCard -type-4">
                <div class="categoryCard__icon bg-light-3">
                  <i class="icon icon-creative-announcement"></i>
                </div>
                <div class="categoryCard__content mt-10">
                  <h4 class="categoryCard__title text-17 fw-500">Digtal Marketing</h4>
                  <div class="categoryCard__text text-13 text-light-1 lh-1 mt-5">573+ Courses</div>
                </div>
              </a>
            </div>

            <div class="col-xl-3 col-md-6" data-anim-child="scale delay-2">
              <a href="#" class="categoryCard -type-4">
                <div class="categoryCard__icon bg-light-3">
                  <i class="icon icon-creative-web"></i>
                </div>
                <div class="categoryCard__content mt-10">
                  <h4 class="categoryCard__title text-17 fw-500">Web Development</h4>
                  <div class="categoryCard__text text-13 text-light-1 lh-1 mt-5">573+ Courses</div>
                </div>
              </a>
            </div>

            <div class="col-xl-3 col-md-6" data-anim-child="scale delay-3">
              <a href="#" class="categoryCard -type-4">
                <div class="categoryCard__icon bg-light-3">
                  <i class="icon icon-creative-design"></i>
                </div>
                <div class="categoryCard__content mt-10">
                  <h4 class="categoryCard__title text-17 fw-500">Graphic Design</h4>
                  <div class="categoryCard__text text-13 text-light-1 lh-1 mt-5">573+ Courses</div>
                </div>
              </a>
            </div>

            <div class="col-xl-3 col-md-6" data-anim-child="scale delay-4">
              <a href="#" class="categoryCard -type-4">
                <div class="categoryCard__icon bg-light-3">
                  <i class="icon icon-creative-photography"></i>
                </div>
                <div class="categoryCard__content mt-10">
                  <h4 class="categoryCard__title text-17 fw-500">Social Sciences</h4>
                  <div class="categoryCard__text text-13 text-light-1 lh-1 mt-5">573+ Courses</div>
                </div>
              </a>
            </div>

            <div class="col-xl-3 col-md-6" data-anim-child="scale delay-5">
              <a href="#" class="categoryCard -type-4">
                <div class="categoryCard__icon bg-light-3">
                  <i class="icon icon-creative-social"></i>
                </div>
                <div class="categoryCard__content mt-10">
                  <h4 class="categoryCard__title text-17 fw-500">Photohraphy</h4>
                  <div class="categoryCard__text text-13 text-light-1 lh-1 mt-5">573+ Courses</div>
                </div>
              </a>
            </div>

            <div class="col-xl-3 col-md-6" data-anim-child="scale delay-6">
              <a href="#" class="categoryCard -type-4">
                <div class="categoryCard__icon bg-light-3">
                  <i class="icon icon-creative-art"></i>
                </div>
                <div class="categoryCard__content mt-10">
                  <h4 class="categoryCard__title text-17 fw-500">Art &amp; Humanities</h4>
                  <div class="categoryCard__text text-13 text-light-1 lh-1 mt-5">573+ Courses</div>
                </div>
              </a>
            </div>

            <div class="col-xl-3 col-md-6" data-anim-child="scale delay-7">
              <a href="#" class="categoryCard -type-4">
                <div class="categoryCard__icon bg-light-3">
                  <i class="icon icon-creative-personal"></i>
                </div>
                <div class="categoryCard__content mt-10">
                  <h4 class="categoryCard__title text-17 fw-500">Personal Development</h4>
                  <div class="categoryCard__text text-13 text-light-1 lh-1 mt-5">573+ Courses</div>
                </div>
              </a>
            </div>

            <div class="col-xl-3 col-md-6" data-anim-child="scale delay-8">
              <a href="#" class="categoryCard -type-4">
                <div class="categoryCard__icon bg-light-3">
                  <i class="icon icon-creative-software"></i>
                </div>
                <div class="categoryCard__content mt-10">
                  <h4 class="categoryCard__title text-17 fw-500">IT and Software</h4>
                  <div class="categoryCard__text text-13 text-light-1 lh-1 mt-5">573+ Courses</div>
                </div>
              </a>
            </div>

          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg bg-beige-1">
        <div data-anim-wrap class="container">
          <div data-anim-child="slide-left delay-1" class="row y-gap-20 justify-between items-center">
            <div class="col-lg-6">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Learn from the best instructors</h2>

                <p class="sectionTitle__text ">Lorem ipsum dolor sit amet, consectetur.</p>

              </div>

            </div>

            <div class="col-auto">

              <a href="instructors-list-1.html" class="button -icon -purple-3 -rounded text-purple-1">
                View All Instructors
                <i class="icon-arrow-top-right text-13 ml-10"></i>
              </a>

            </div>
          </div>

          <div class="row y-gap-30 pt-50">

            <div class="col-lg-3 col-sm-6">
              <div data-anim-child="slide-left delay-2" class="teamCard -type-1 -teamCard-hover">
                <div class="teamCard__image">
                  <img src="{{ asset('template/img/team/1.png') }}" alt="image">
                  <div class="teamCard__socials">
                    <div class="d-flex x-gap-20 y-gap-10 justify-center items-center h-100">
                      <a href="#"><i class="icon-facebook text-white"></i></a>
                      <a href="#"><i class="icon-twitter text-white"></i></a>
                      <a href="#"><i class="icon-instagram text-white"></i></a>
                      <a href="#"><i class="icon-linkedin text-white"></i></a>
                    </div>
                  </div>
                </div>
                <div class="teamCard__content">
                  <h4 class="teamCard__title">Floyd Miles</h4>
                  <p class="teamCard__text">President of Sales</p>

                  <div class="row items-center y-gap-10 x-gap-10 pt-10">
                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-star text-yellow-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12 text-yellow-1 fw-500">4.5</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-online-learning text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">692 Students</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-play text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">15 Course</div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-sm-6">
              <div data-anim-child="slide-left delay-3" class="teamCard -type-1 -teamCard-hover">
                <div class="teamCard__image">
                  <img src="{{ asset('template/img/team/2.png') }}" alt="image">
                  <div class="teamCard__socials">
                    <div class="d-flex x-gap-20 y-gap-10 justify-center items-center h-100">
                      <a href="#"><i class="icon-facebook text-white"></i></a>
                      <a href="#"><i class="icon-twitter text-white"></i></a>
                      <a href="#"><i class="icon-instagram text-white"></i></a>
                      <a href="#"><i class="icon-linkedin text-white"></i></a>
                    </div>
                  </div>
                </div>
                <div class="teamCard__content">
                  <h4 class="teamCard__title">Cameron Williamson</h4>
                  <p class="teamCard__text">Web Designer</p>

                  <div class="row items-center y-gap-10 x-gap-10 pt-10">
                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-star text-yellow-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12 text-yellow-1 fw-500">4.5</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-online-learning text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">692 Students</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-play text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">15 Course</div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-sm-6">
              <div data-anim-child="slide-left delay-4" class="teamCard -type-1 -teamCard-hover">
                <div class="teamCard__image">
                  <img src="{{ asset('template/img/team/3.png') }}" alt="image">
                  <div class="teamCard__socials">
                    <div class="d-flex x-gap-20 y-gap-10 justify-center items-center h-100">
                      <a href="#"><i class="icon-facebook text-white"></i></a>
                      <a href="#"><i class="icon-twitter text-white"></i></a>
                      <a href="#"><i class="icon-instagram text-white"></i></a>
                      <a href="#"><i class="icon-linkedin text-white"></i></a>
                    </div>
                  </div>
                </div>
                <div class="teamCard__content">
                  <h4 class="teamCard__title">Brooklyn Simmons</h4>
                  <p class="teamCard__text">Dog Trainer</p>

                  <div class="row items-center y-gap-10 x-gap-10 pt-10">
                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-star text-yellow-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12 text-yellow-1 fw-500">4.5</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-online-learning text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">692 Students</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-play text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">15 Course</div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-sm-6">
              <div data-anim-child="slide-left delay-5" class="teamCard -type-1 -teamCard-hover">
                <div class="teamCard__image">
                  <img src="{{ asset('template/img/team/4.png') }}" alt="image">
                  <div class="teamCard__socials">
                    <div class="d-flex x-gap-20 y-gap-10 justify-center items-center h-100">
                      <a href="#"><i class="icon-facebook text-white"></i></a>
                      <a href="#"><i class="icon-twitter text-white"></i></a>
                      <a href="#"><i class="icon-instagram text-white"></i></a>
                      <a href="#"><i class="icon-linkedin text-white"></i></a>
                    </div>
                  </div>
                </div>
                <div class="teamCard__content">
                  <h4 class="teamCard__title">Wade Warren</h4>
                  <p class="teamCard__text">Marketing Coordinator</p>

                  <div class="row items-center y-gap-10 x-gap-10 pt-10">
                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-star text-yellow-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12 text-yellow-1 fw-500">4.5</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-online-learning text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">692 Students</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-play text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">15 Course</div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>

          </div>

          <div class="row justify-center text-center pt-60 lg:pt-40">
            <div class="col-auto">
              <p class="lh-1">Want to help people learn, grow and achieve more in life? <a class="text-purple-1 underline" href="instructors-become.html">Become an instructor</a></p>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg bg-light-4">
        <div class="container">
          <div class="row y-gap-15 justify-between items-end">
            <div class="col-lg-6">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Top Students</h2>

                <p class="sectionTitle__text ">Lorem ipsum dolor sit amet, consectetur.</p>

              </div>

            </div>

            <div class="col-auto">

              <a href="#" class="button -icon -purple-3 -rounded text-purple-1">
                View All Students
                <i class="icon-arrow-top-right text-13 ml-10"></i>
              </a>

            </div>
          </div>

          <div data-anim-wrap class="row y-gap-30 pt-60 lg:pt-40">

            <div class="col-lg-3 col-md-6" data-anim-child="slide-right delay-1">
              <div class="teamCard -type-2 bg-white">
                <div class="teamCard__content">
                  <div class="teamCard__img">
                    <img src="{{ asset('template/img/home-2/students/1.png') }}" alt="image">
                  </div>

                  <h4 class="teamCard__title text-17 lh-15 fw-500 mt-12">Brooklyn Simmons</h4>
                  <div class="teamCard__subtitle text-14 lh-1 mt-5">Web Designer</div>

                  <div class="teamCard__socials d-flex x-gap-20 pt-12">
                    <a href="#">
                      <i class="fa fa-facebook"></i>
                    </a>
                    <a href="#">
                      <i class="fa fa-twitter"></i>
                    </a>
                    <a href="#">
                      <i class="fa fa-instagram"></i>
                    </a>
                    <a href="#">
                      <i class="fa fa-linkedin"></i>
                    </a>
                  </div>

                  <div class="teamCard-tags pt-20">
                    <div class="teamCard-tags__item">
                      <div class="teamCard-tags__tag">Design</div>
                    </div>
                    <div class="teamCard-tags__item">
                      <div class="teamCard-tags__tag">Art</div>
                    </div>
                    <div class="teamCard-tags__item">
                      <div class="teamCard-tags__tag">Graphic</div>
                    </div>
                  </div>

                  <div class="teamCard__button mt-20">
                    <a href="#" class="button -icon -outline-purple-1 -rounded text-purple-1">
                      View Profile
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6" data-anim-child="slide-right delay-2">
              <div class="teamCard -type-2 bg-white">
                <div class="teamCard__content">
                  <div class="teamCard__img">
                    <img src="{{ asset('template/img/home-2/students/2.png') }}" alt="image">
                  </div>

                  <h4 class="teamCard__title text-17 lh-15 fw-500 mt-12">Cody Fisher</h4>
                  <div class="teamCard__subtitle text-14 lh-1 mt-5">Dog Trainer</div>

                  <div class="teamCard__socials d-flex x-gap-20 pt-12">
                    <a href="#">
                      <i class="fa fa-facebook"></i>
                    </a>
                    <a href="#">
                      <i class="fa fa-twitter"></i>
                    </a>
                    <a href="#">
                      <i class="fa fa-instagram"></i>
                    </a>
                    <a href="#">
                      <i class="fa fa-linkedin"></i>
                    </a>
                  </div>

                  <div class="teamCard-tags pt-20">
                    <div class="teamCard-tags__item">
                      <div class="teamCard-tags__tag">Design</div>
                    </div>
                    <div class="teamCard-tags__item">
                      <div class="teamCard-tags__tag">Art</div>
                    </div>
                    <div class="teamCard-tags__item">
                      <div class="teamCard-tags__tag">Graphic</div>
                    </div>
                  </div>

                  <div class="teamCard__button mt-20">
                    <a href="#" class="button -icon -outline-purple-1 -rounded text-purple-1">
                      View Profile
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6" data-anim-child="slide-right delay-3">
              <div class="teamCard -type-2 bg-white">
                <div class="teamCard__content">
                  <div class="teamCard__img">
                    <img src="{{ asset('template/img/home-2/students/3.png') }}" alt="image">
                  </div>

                  <h4 class="teamCard__title text-17 lh-15 fw-500 mt-12">Marvin McKinney</h4>
                  <div class="teamCard__subtitle text-14 lh-1 mt-5">President of Sales</div>

                  <div class="teamCard__socials d-flex x-gap-20 pt-12">
                    <a href="#">
                      <i class="fa fa-facebook"></i>
                    </a>
                    <a href="#">
                      <i class="fa fa-twitter"></i>
                    </a>
                    <a href="#">
                      <i class="fa fa-instagram"></i>
                    </a>
                    <a href="#">
                      <i class="fa fa-linkedin"></i>
                    </a>
                  </div>

                  <div class="teamCard-tags pt-20">
                    <div class="teamCard-tags__item">
                      <div class="teamCard-tags__tag">Design</div>
                    </div>
                    <div class="teamCard-tags__item">
                      <div class="teamCard-tags__tag">Art</div>
                    </div>
                    <div class="teamCard-tags__item">
                      <div class="teamCard-tags__tag">Graphic</div>
                    </div>
                  </div>

                  <div class="teamCard__button mt-20">
                    <a href="#" class="button -icon -outline-purple-1 -rounded text-purple-1">
                      View Profile
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6" data-anim-child="slide-right delay-4">
              <div class="teamCard -type-2 bg-white">
                <div class="teamCard__content">
                  <div class="teamCard__img">
                    <img src="{{ asset('template/img/home-2/students/4.png') }}" alt="image">
                  </div>

                  <h4 class="teamCard__title text-17 lh-15 fw-500 mt-12">Jane Cooper</h4>
                  <div class="teamCard__subtitle text-14 lh-1 mt-5">Marketing Coordinator</div>

                  <div class="teamCard__socials d-flex x-gap-20 pt-12">
                    <a href="#">
                      <i class="fa fa-facebook"></i>
                    </a>
                    <a href="#">
                      <i class="fa fa-twitter"></i>
                    </a>
                    <a href="#">
                      <i class="fa fa-instagram"></i>
                    </a>
                    <a href="#">
                      <i class="fa fa-linkedin"></i>
                    </a>
                  </div>

                  <div class="teamCard-tags pt-20">
                    <div class="teamCard-tags__item">
                      <div class="teamCard-tags__tag">Design</div>
                    </div>
                    <div class="teamCard-tags__item">
                      <div class="teamCard-tags__tag">Art</div>
                    </div>
                    <div class="teamCard-tags__item">
                      <div class="teamCard-tags__tag">Graphic</div>
                    </div>
                  </div>

                  <div class="teamCard__button mt-20">
                    <a href="#" class="button -icon -outline-purple-1 -rounded text-purple-1">
                      View Profile
                    </a>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg">
        <div data-anim-wrap class="container">
          <div class="row justify-center text-center">
            <div class="col-auto">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Start your Learning Journey Today!</h2>

                <p class="sectionTitle__text ">Lorem ipsum dolor sit amet, consectetur.</p>

              </div>

            </div>
          </div>

          <div class="row y-gap-30 justify-between pt-60 lg:pt-50">

            <div class="col-lg-3 col-md-6">
              <div class="coursesCard -type-2 text-center pt-50 pb-40 px-30 bg-white rounded-8">
                <div class="coursesCard__image">
                  <img src="{{ asset('template/img/home-5/learning/1.svg') }}" alt="image">
                </div>
                <div class="coursesCard__content mt-30">
                  <h5 class="coursesCard__title text-18 lh-1 fw-500">Learn with Experts</h5>
                  <p class="coursesCard__text text-14 mt-10">Grursus mal suada faci lisis that ipsum ameti consecte.</p>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div class="coursesCard -type-2 text-center pt-50 pb-40 px-30 bg-white rounded-8">
                <div class="coursesCard__image">
                  <img src="{{ asset('template/img/home-5/learning/2.svg') }}" alt="image">
                </div>
                <div class="coursesCard__content mt-30">
                  <h5 class="coursesCard__title text-18 lh-1 fw-500">Learn Anything</h5>
                  <p class="coursesCard__text text-14 mt-10">Grursus mal suada faci lisis that ipsum ameti consecte.</p>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div class="coursesCard -type-2 text-center pt-50 pb-40 px-30 bg-white rounded-8">
                <div class="coursesCard__image">
                  <img src="{{ asset('template/img/home-5/learning/3.svg') }}" alt="image">
                </div>
                <div class="coursesCard__content mt-30">
                  <h5 class="coursesCard__title text-18 lh-1 fw-500">Flexible Learning</h5>
                  <p class="coursesCard__text text-14 mt-10">Grursus mal suada faci lisis that ipsum ameti consecte.</p>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div class="coursesCard -type-2 text-center pt-50 pb-40 px-30 bg-white rounded-8">
                <div class="coursesCard__image">
                  <img src="{{ asset('template/img/home-5/learning/4.svg') }}" alt="image">
                </div>
                <div class="coursesCard__content mt-30">
                  <h5 class="coursesCard__title text-18 lh-1 fw-500">Industrial Standart</h5>
                  <p class="coursesCard__text text-14 mt-10">Grursus mal suada faci lisis that ipsum ameti consecte.</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg bg-light-3">
        <div data-anim-wrap class="container">
          <div class="row justify-center text-center">
            <div class="col-auto">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Simple Pricing</h2>

                <p class="sectionTitle__text ">Lorem ipsum dolor sit amet, consectetur.</p>

              </div>


              <div class="d-flex justify-center items-center pt-60 lg:pt-30">
                <div class="text-14 text-dark-1">Monthly</div>
                <div class="form-switch px-20">
                  <div class="switch" data-switch=".js-switch-content">
                    <input type="checkbox">
                    <span class="switch__slider"></span>
                  </div>
                </div>
                <div class="text-14 text-dark-1">Annually <span class="text-purple-1">Save 30%</span></div>
              </div>
            </div>
          </div>

          <div data-anim-wrap class="row y-gap-30 justify-between pt-60 lg:pt-50">

            <div class="col-lg-4 col-md-6" data-anim-child="slide-right delay-1">
              <div class="priceCard -type-1 rounded-16 overflow-hidden">

                <div class="priceCard__header py-40 pl-50 bg-dark-2">

                  <div class="priceCard__type text-18 lh-11 fw-500 text-white">Basic</div>
                  <div class="priceCard__price text-45 lh-11 fw-700 text-white mt-8">Free</div>
                  <div class="priceCard__period text-white mt-5">per month</div>
                </div>


                <div class="priceCard__content pt-30 pr-90 pb-50 pl-50 bg-white">


                  <div class="priceCard__text">Standard listing submission, active for 30 dayss</div>


                  <div class="priceCard__list mt-30">

                    <div>
                      <i class="text-purple-1 pr-8" data-feather="check"></i>
                      All Operating Supported
                    </div>

                    <div>
                      <i class="text-purple-1 pr-8" data-feather="check"></i>
                      Great Interface
                    </div>

                    <div>
                      <i class="text-purple-1 pr-8" data-feather="check"></i>
                      Allows encryption
                    </div>

                    <div>
                      <i class="text-purple-1 pr-8" data-feather="check"></i>
                      Face recognized system
                    </div>

                    <div>
                      <i class="text-purple-1 pr-8" data-feather="check"></i>
                      24/7 Full support
                    </div>

                  </div>


                  <div class="priceCard__button mt-30">

                    <a class="button -md -purple-3 text-purple-1" href="{{ route('courses.list-1') }}">Get Started Now</a>

                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6" data-anim-child="slide-right delay-2">
              <div class="priceCard -type-1 rounded-16 overflow-hidden">

                <div class="priceCard__header py-40 pl-50 bg-purple-1">

                  <div class="priceCard__type text-18 lh-11 fw-500 text-white">Professional</div>
                  <div class="priceCard__price text-45 lh-11 fw-700 text-white mt-8">$599.95</div>
                  <div class="priceCard__period text-white mt-5">per month</div>
                </div>


                <div class="priceCard__content pt-30 pr-90 pb-50 pl-50 bg-purple-1">


                  <div class="priceCard__text text-white">Standard listing submission, active for 30 dayss</div>


                  <div class="priceCard__list mt-30">

                    <div class="text-white">
                      <i class="pr-8" data-feather="check"></i>
                      All Operating Supported
                    </div>

                    <div class="text-white">
                      <i class="pr-8" data-feather="check"></i>
                      Great Interface
                    </div>

                    <div class="text-white">
                      <i class="pr-8" data-feather="check"></i>
                      Allows encryption
                    </div>

                    <div class="text-white">
                      <i class="pr-8" data-feather="check"></i>
                      Face recognized system
                    </div>

                    <div class="text-white">
                      <i class="pr-8" data-feather="check"></i>
                      24/7 Full support
                    </div>

                  </div>


                  <div class="priceCard__button mt-30">

                    <a class="button -md -white text-purple-1" href="{{ route('courses.list-1') }}">Get Started Now</a>

                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6" data-anim-child="slide-right delay-3">
              <div class="priceCard -type-1 rounded-16 overflow-hidden">

                <div class="priceCard__header py-40 pl-50 bg-dark-2">

                  <div class="priceCard__type text-18 lh-11 fw-500 text-white">Business</div>
                  <div class="priceCard__price text-45 lh-11 fw-700 text-white mt-8">$999.95</div>
                  <div class="priceCard__period text-white mt-5">per month</div>
                </div>


                <div class="priceCard__content pt-30 pr-90 pb-50 pl-50 bg-white">


                  <div class="priceCard__text">Standard listing submission, active for 30 dayss</div>


                  <div class="priceCard__list mt-30">

                    <div>
                      <i class="text-purple-1 pr-8" data-feather="check"></i>
                      All Operating Supported
                    </div>

                    <div>
                      <i class="text-purple-1 pr-8" data-feather="check"></i>
                      Great Interface
                    </div>

                    <div>
                      <i class="text-purple-1 pr-8" data-feather="check"></i>
                      Allows encryption
                    </div>

                    <div>
                      <i class="text-purple-1 pr-8" data-feather="check"></i>
                      Face recognized system
                    </div>

                    <div>
                      <i class="text-purple-1 pr-8" data-feather="check"></i>
                      24/7 Full support
                    </div>

                  </div>


                  <div class="priceCard__button mt-30">

                    <a class="button -md -purple-3 text-purple-1" href="{{ route('courses.list-1') }}">Get Started Now</a>

                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-md">
        <div data-anim-wrap class="container">
          <div class="row y-gap-20 justify-between items-center">
            <div class="col-xl-6 col-lg-7">
              <div data-anim-child="slide-up delay-1" class="app-image">
                <img src="{{ asset('template/img/home-5/apps/img.png') }}" alt="image">
              </div>
            </div>

            <div class="col-lg-5">
              <div class="app-content">
                <h2 data-anim-child="slide-up delay-3" class="app-content__title">Learn From<br> <span>Anywhere</span></h2>
                <p data-anim-child="slide-up delay-4" class="app-content__text">Take classes on the go with the educrat app. Stream or download to watch on the plane, the subway, or wherever you learn best.</p>
                <div data-anim-child="slide-up delay-5" class="app-content__buttons">
                  <a href="#"><img src="{{ asset('template/img/app/buttons/1.svg') }}" alt="button"></a>
                  <a href="#"><img src="{{ asset('template/img/app/buttons/2.svg') }}" alt="button"></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-md layout-pb-lg">
        <div data-anim-wrap class="container">
          <div data-anim-child="slide-left delay-1" class="row y-gap-20 justify-between items-center">
            <div class="col-lg-6">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">News & Events</h2>

                <p class="sectionTitle__text ">Lorem ipsum dolor sit amet, consectetur.</p>

              </div>

            </div>

            <div class="col-auto">

              <a href="#" class="button -icon -purple-3 text-purple-1">
                Browse Blog
                <i class="icon-arrow-top-right text-13 ml-10"></i>
              </a>

            </div>
          </div>

          <div class="row y-gap-30 pt-50">

            <div class="col-lg-4 col-md-6">
              <div data-anim-child="slide-left delay-2" class="blogCard -type-1">
                <div class="blogCard__image">
                  <img src="{{ asset('template/img/blog/1.png') }}" alt="image">
                </div>
                <div class="blogCard__content">
                  <a href="blog-single.html" class="blogCard__category">EDUCATION</a>
                  <h4 class="blogCard__title">Eco-Education in Our Lives: We Can Change the Future</h4>
                  <div class="blogCard__date">December 16, 2022</div>
                </div>
              </div>
            </div>

            <div class="col-lg-4 col-md-6">
              <div data-anim-child="slide-left delay-3" class="blogCard -type-1">
                <div class="blogCard__image">
                  <img src="{{ asset('template/img/blog/2.png') }}" alt="image">
                </div>
                <div class="blogCard__content">
                  <a href="blog-single.html" class="blogCard__category">DESIGN</a>
                  <h4 class="blogCard__title">How to design a simple, yet unique and memorable brand identity</h4>
                  <div class="blogCard__date">December 16, 2022</div>
                </div>
              </div>
            </div>


            <div class="col-lg-4">
              <div class="row y-gap-30">

                <div class="col-lg-12 col-md-6">
                  <a href="#" data-anim-child="slide-left delay-4" class="eventCard -type-4">
                    <div class="eventCard__date bg-light-7 mr-20">
                      <span class="text-30 lh-1 fw-700">15</span>
                      <span class="text-18 lh-1 fw-500 uppercase mt-10">JUNE</span>
                    </div>
                    <div class="eventCard__content">
                      <div class="text-13 lh-1 fw-500 uppercase text-purple-1">Courses</div>
                      <h4 class="text-17 lh-15 fw-500 mt-10">Medical Chemistry: The Molecular Basis</h4>
                    </div>
                  </a>
                </div>

                <div class="col-lg-12 col-md-6">
                  <a href="#" data-anim-child="slide-left delay-5" class="eventCard -type-4">
                    <div class="eventCard__date bg-light-7 mr-20">
                      <span class="text-30 lh-1 fw-700">15</span>
                      <span class="text-18 lh-1 fw-500 uppercase mt-10">JUNE</span>
                    </div>
                    <div class="eventCard__content">
                      <div class="text-13 lh-1 fw-500 uppercase text-purple-1">Courses</div>
                      <h4 class="text-17 lh-15 fw-500 mt-10">Medical Chemistry: The Molecular Basis</h4>
                    </div>
                  </a>
                </div>

                <div class="col-lg-12 col-md-6">
                  <a href="#" data-anim-child="slide-left delay-6" class="eventCard -type-4">
                    <div class="eventCard__date bg-light-7 mr-20">
                      <span class="text-30 lh-1 fw-700">15</span>
                      <span class="text-18 lh-1 fw-500 uppercase mt-10">JUNE</span>
                    </div>
                    <div class="eventCard__content">
                      <div class="text-13 lh-1 fw-500 uppercase text-purple-1">Courses</div>
                      <h4 class="text-17 lh-15 fw-500 mt-10">Medical Chemistry: The Molecular Basis</h4>
                    </div>
                  </a>
                </div>

                <div class="col-lg-12 col-md-6">
                  <a href="#" data-anim-child="slide-left delay-7" class="eventCard -type-4">
                    <div class="eventCard__date bg-light-7 mr-20">
                      <span class="text-30 lh-1 fw-700">15</span>
                      <span class="text-18 lh-1 fw-500 uppercase mt-10">JUNE</span>
                    </div>
                    <div class="eventCard__content">
                      <div class="text-13 lh-1 fw-500 uppercase text-purple-1">Courses</div>
                      <h4 class="text-17 lh-15 fw-500 mt-10">Medical Chemistry: The Molecular Basis</h4>
                    </div>
                  </a>
                </div>

              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg bg-dark-2 relative">
        <div class="side-image pr-25 lg:d-none">
          <img src="{{ asset('template/img/home-5/cta/img.png') }}" alt="image">
        </div>

        <div data-anim-wrap class="container">
          <div class="row">
            <div class="col-xl-12 col-lg-7">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title text-white">Get personal learning recommendations</h2>

                <p class="sectionTitle__text text-white">Enhance your skills with best Online courses</p>

              </div>


              <div class="row x-gap-20 y-gap-20 pt-60 lg:pt-40">
                <div class="col-auto">
                  <div class="dropdown js-dropdown js-catb-active">
                    <div class="dropdown__button d-flex items-center bg-dark-1 text-14 text-white h-60" data-el-toggle=".js-catb-toggle" data-el-toggle-active=".js-catb-active">
                      <span class="js-dropdown-title">Category</span>
                      <i class="icon text-9 ml-40 icon-chevron-down"></i>
                    </div>

                    <div class="toggle-element -dropdown -dark-bg-dark-2 -dark-border-white-10 js-click-dropdown js-catb-toggle">
                      <div class="text-14 y-gap-15 js-dropdown-list">
                        <div><a href="#" class="d-block js-dropdown-link">Animation</a></div>
                        <div><a href="#" class="d-block js-dropdown-link">Design</a></div>
                        <div><a href="#" class="d-block js-dropdown-link">Illustration</a></div>
                        <div><a href="#" class="d-block js-dropdown-link">Lifestyle</a></div>
                        <div><a href="#" class="d-block js-dropdown-link">Business</a></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-auto">
                  <div class="dropdown js-dropdown js-diff-active">
                    <div class="dropdown__button d-flex items-center bg-dark-1 text-14 text-white h-60" data-el-toggle=".js-diff-toggle" data-el-toggle-active=".js-diff-active">
                      <span class="js-dropdown-title">Difficulty</span>
                      <i class="icon text-9 ml-40 icon-chevron-down"></i>
                    </div>

                    <div class="toggle-element -dropdown -dark-bg-dark-2 -dark-border-white-10 js-click-dropdown js-diff-toggle">
                      <div class="text-14 y-gap-15 js-dropdown-list">
                        <div><a href="#" class="d-block js-dropdown-link">Easy</a></div>
                        <div><a href="#" class="d-block js-dropdown-link">Medium</a></div>
                        <div><a href="#" class="d-block js-dropdown-link">Hard</a></div>
                      </div>
                    </div>
                  </div>
                </div>

                <div class="col-auto">
                  <a href="{{ route('courses.list-1') }}" class="button -md -purple-1 text-white">Get Started Now</a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <footer class="footer -type-1 bg-purple-1">
        <div class="container">
          <div class="footer-header">
            <div class="row y-gap-20 justify-between items-center">
              <div class="col-auto">
                <div class="footer-header__logo">
                  <img src="{{ asset('template/img/general/logo-pure-white.svg') }}" alt="logo">
                </div>
              </div>
              <div class="col-auto">
                <div class="footer-header-socials">
                  <div class="footer-header-socials__title text-white">Follow us on social media</div>
                  <div class="footer-header-socials__list">
                    <a href="#"><i class="icon-facebook"></i></a>
                    <a href="#"><i class="icon-twitter"></i></a>
                    <a href="#"><i class="icon-instagram"></i></a>
                    <a href="#"><i class="icon-linkedin"></i></a>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="footer-columns">
            <div class="row y-gap-30">
              <div class="col-xl-2 col-lg-4 col-md-6">
                <div class="text-17 fw-500 text-white uppercase mb-25">ABOUT</div>
                <div class="d-flex y-gap-10 flex-column">
                  <a href="{{ route('pages.about-1') }}">About Us</a>
                  <a href="blog-list-1.html">Learner Stories</a>
                  <a href="instructor-become.html">Careers</a>
                  <a href="blog-list-1.html">Press</a>
                  <a href="#">Leadership</a>
                  <a href="{{ route('pages.contact-1') }}">Contact Us</a>
                </div>
              </div>

              <div class="col-xl-4 col-lg-8">
                <div class="text-17 fw-500 text-white uppercase mb-25">CATEGORIES</div>
                <div class="row justify-between y-gap-20">
                  <div class="col-md-6">
                    <div class="d-flex y-gap-10 flex-column">
                      <a href="{{ route('courses.single-1') }}">Development</a>
                      <a href="{{ route('courses.single-2') }}">Business</a>
                      <a href="{{ route('courses.single-3') }}">Finance & Accounting</a>
                      <a href="{{ route('courses.single-4') }}">IT & Software</a>
                      <a href="{{ route('courses.single-5') }}">Office Productivity</a>
                      <a href="{{ route('courses.single-6') }}">Design</a>
                      <a href="{{ route('courses.single-1') }}">Marketing</a>
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="d-flex y-gap-10 flex-column">
                      <a href="{{ route('courses.single-1') }}">Lifiestyle</a>
                      <a href="{{ route('courses.single-2') }}">Photography & Video</a>
                      <a href="{{ route('courses.single-3') }}">Health & Fitness</a>
                      <a href="{{ route('courses.single-4') }}">Music</a>
                      <a href="{{ route('courses.single-5') }}">UX Design</a>
                      <a href="{{ route('courses.single-6') }}">Seo</a>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-xl-2 offset-xl-1 col-lg-4 col-md-6">
                <div class="text-17 fw-500 text-white uppercase mb-25">SUPPORT</div>
                <div class="d-flex y-gap-10 flex-column">
                  <a href="terms.html">Documentation</a>
                  <a href="help-center.html">FAQS</a>
                  <a href="dashboard.html">Dashboard</a>
                  <a href="{{ route('pages.contact-1') }}">Contact</a>
                </div>
              </div>

              <div class="col-xl-3 col-lg-4 col-md-6">
                <div class="text-17 fw-500 text-white uppercase mb-25">GET IN TOUCH</div>
                <div class="footer-columns-form">
                  <div>We don�t send spam so don�t worry.</div>
                  <form action="https://creativelayers.net/themes/educrat-html/post">
                    <div class="form-group">
                      <input type="text" placeholder="Email...">
                      <button type="submit">Submit</button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>

          <div class="py-30 border-top-light-15">
            <div class="row justify-between items-center y-gap-20">
              <div class="col-auto">
                <div class="d-flex items-center h-100 text-white">
                  � 2022 Educrat. All Right Reserved.
                </div>
              </div>

              <div class="col-auto">
                <div class="d-flex x-gap-20 y-gap-20 items-center flex-wrap">
                  <div>
                    <div class="d-flex x-gap-15 text-white">
                      <a href="help-center.html">Help</a>
                      <a href="terms.html">Privacy Policy</a>
                      <a href="terms.html">Cookie Notice</a>
                      <a href="terms.html">Security</a>
                      <a href="terms.html">Terms of Use</a>
                    </div>
                  </div>

                  <div>
                    <a href="#" class="button px-30 h-50 -dark-6 rounded-200 text-white">
                      <i class="icon-worldwide text-20 mr-15"></i><span class="text-15">English</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>


    </div>
  </main>

  <!-- JavaScript -->
  <script src="../../../unpkg.com/leaflet%401.7.1/dist/leaflet.js') }}" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
  <script src="{{ asset('template/js/vendors.js') }}"></script>
  <script src="{{ asset('template/js/main.js') }}"></script>
</body>
</html>
























