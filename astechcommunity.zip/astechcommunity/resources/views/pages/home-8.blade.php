<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Google fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com/">
  <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">

  <link rel="stylesheet" href="../../../cdn.jsdelivr.net/npm/choices.js/public/assets/styles/base.min.css') }}" />
  <link rel="stylesheet" href="../../../cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css') }}" />

  <link href="https://fonts.googleapis.com/css2?family=Material+Icons+Outlined" rel="stylesheet">
  <link rel="stylesheet" href="../../../cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css') }}" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="../../../unpkg.com/leaflet%401.7.1/dist/leaflet.css') }}" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />

  <!-- Stylesheets -->
  <link rel="stylesheet" href="{{ asset('template/css/vendors.css') }}">
  <link rel="stylesheet" href="{{ asset('template/css/main.css') }}">

  <title>Educrat</title>
</head>

<body class="preloader-visible" data-barba="wrapper">
  <!-- preloader start -->
  <div class="preloader js-preloader">
    <div class="preloader__bg"></div>
  </div>
  <!-- preloader end -->


  <main class="main-content  ">

    <header data-anim="fade" data-add-bg="bg-white" class="header -type-5 js-header">

      <div class="d-flex items-center bg-white py-10 border-bottom-light">
        <div class="header__container">
          <div class="row y-gap-5 justify-between items-center">
            <div class="col-auto">
              <div class="d-flex x-gap-40 y-gap-10 items-center">
                <div class="d-flex items-center text-dark-1 md:d-none">
                  <div class="icon-phone mr-10"></div>
                  <div class="text-13 lh-1">(00) 242 844 39 88</div>
                </div>
                <div class="d-flex items-center text-dark-1">
                  <div class="icon-email mr-10"></div>
                  <div class="text-13 lh-1">hello@educrat.com</div>
                </div>
              </div>
            </div>

            <div class="col-auto">
              <div class="d-flex x-gap-30 y-gap-10">
                <div>
                  <div class="d-flex x-gap-20 items-center text-dark-1">
                    <a href="#"><i class="icon-facebook text-11"></i></a>
                    <a href="#"><i class="icon-twitter text-11"></i></a>
                    <a href="#"><i class="icon-instagram text-11"></i></a>
                    <a href="#"><i class="icon-linkedin text-11"></i></a>
                  </div>
                </div>

                <div class="d-flex items-center text-dark-1 text-13 sm:d-none">
                  English <i class="icon-chevron-down text-9 ml-10"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>


      <div class="header__container py-10">
        <div class="row justify-between items-center">

          <div class="col-auto">
            <div class="header-left d-flex items-center">

              <div class="header__logo ">
                <a data-barba href="{{ route('home') }}">
                  <img src="{{ asset('template/img/general/logo-dark.svg') }}" alt="logo">
                </a>
              </div>


              <div class="header__explore text-dark-1 ml-50 xl:ml-30 xl:d-none">
                <a href="#" class="d-flex items-center" data-el-toggle=".js-explore-toggle">
                  <i class="icon icon-explore mr-15"></i>
                  Explore
                </a>

                <div class="explore-content py-25 rounded-8 bg-white toggle-element js-explore-toggle">

                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Architecture<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Business<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="text-dark-1">Computer Programming</a>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="text-dark-1">Data Analysis</a>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Design<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="{{ route('courses.single-6') }}" class="text-dark-1">Education</a>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Electronics<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Language<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Marketing<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="text-dark-1">Music Arts</a>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="text-dark-1">Social Science</a>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Photography & Video<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="{{ route('courses.single-1') }}" class="text-dark-1">IT & Software</a>
                  </div>

                  <div class="explore__item">
                    <a href="{{ route('courses.single-2') }}" class="text-purple-1 underline">View All Courses</a>
                  </div>
                </div>
              </div>


              <div class="header-menu js-mobile-menu-toggle ">
                <div class="header-menu__content">
                  <div class="mobile-bg js-mobile-bg"></div>

                  <div class="d-none xl:d-flex items-center px-20 py-20 border-bottom-light">
                    <a href="{{ route('login') }}" class="text-dark-1">Log in</a>
                    <a href="{{ route('register') }}" class="text-dark-1 ml-30">Sign Up</a>
                  </div>

                  <div class="menu js-navList">
                    <ul class="menu__nav text-dark-1 ml-50 xl:ml-30 -is-active">
                      <li class="menu-item-has-children">
                        <a data-barba href="#">
                          Home <i class="icon-chevron-right text-13 ml-10"></i>
                        </a>

                        <ul class="subnav">
                          <li class="menu__backButton js-nav-list-back">
                            <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Home</a>
                          </li>

                          <li><a href="{{ route('home') }}">Home 1</a></li>

                          <li><a href="{{ route('pages.home-2') }}">Home 2</a></li>

                          <li><a href="{{ route('pages.home-3') }}">Home 3</a></li>

                          <li><a href="home-4.html">Home 4</a></li>

                          <li><a href="home-5.html">Home 5</a></li>

                          <li><a href="home-6.html">Home 6</a></li>

                          <li><a href="home-7.html">Home 7</a></li>

                          <li><a href="home-8.html">Home 8</a></li>

                          <li><a href="home-9.html">Home 9</a></li>

                          <li><a href="home-10.html">Home 10</a></li>

                        </ul>
                      </li>

                      <li class="menu-item-has-children -has-mega-menu">
                        <a data-barba href="#">Courses <i class="icon-chevron-right text-13 ml-10"></i></a>


                        <div class="mega xl:d-none">
                          <div class="mega__menu">
                            <div class="row x-gap-40">
                              <div class="col">
                                <h4 class="text-17 fw-500 mb-20">Course List Layouts</h4>

                                <ul class="mega__list">

                                  <li><a data-barba href="{{ route('courses.list-1') }}">Course List v1</a></li>

                                  <li><a data-barba href="{{ route('courses.list-2') }}">Course List v2</a></li>

                                  <li><a data-barba href="{{ route('courses.list-3') }}">Course List v3</a></li>

                                  <li><a data-barba href="{{ route('courses.list-4') }}">Course List v4</a></li>

                                  <li><a data-barba href="{{ route('courses.list-5') }}">Course List v5</a></li>

                                  <li><a data-barba href="{{ route('courses.list-6') }}">Course List v6</a></li>

                                  <li><a data-barba href="{{ route('courses.list-7') }}">Course List v7</a></li>

                                  <li><a data-barba href="{{ route('courses.list-8') }}">Course List v8</a></li>

                                  <li><a data-barba href="{{ route('courses.list-9') }}">Course List v9</a></li>

                                </ul>

                              </div>

                              <div class="col">
                                <h4 class="text-17 fw-500 mb-20">Course Single Layouts</h4>

                                <ul class="mega__list">

                                  <li><a data-barba href="{{ route('courses.single-1') }}">Course Single v1</a></li>

                                  <li><a data-barba href="{{ route('courses.single-2') }}">Course Single v2</a></li>

                                  <li><a data-barba href="{{ route('courses.single-3') }}">Course Single v3</a></li>

                                  <li><a data-barba href="{{ route('courses.single-4') }}">Course Single v4</a></li>

                                  <li><a data-barba href="{{ route('courses.single-5') }}">Course Single v5</a></li>

                                  <li><a data-barba href="{{ route('courses.single-6') }}">Course Single v6</a></li>

                                </ul>

                              </div>

                              <div class="col">
                                <h4 class="text-17 fw-500 mb-20">About Courses</h4>

                                <ul class="mega__list">

                                  <li><a data-barba href="lesson-single-1.html">Lesson Page v1</a></li>

                                  <li><a data-barba href="lesson-single-2.html">Lesson Page v2</a></li>

                                  <li><a data-barba href="instructors-list-1.html">Instructors List v1</a></li>

                                  <li><a data-barba href="instructors-list-2.html">Instructors List v2</a></li>

                                  <li><a data-barba href="instructors-single.html">Instructors Single</a></li>

                                  <li><a data-barba href="instructors-become.html">Become an Instructor</a></li>

                                </ul>

                              </div>

                              <div class="col">
                                <h4 class="text-17 fw-500 mb-20">Dashboard Pages</h4>

                                <ul class="mega__list">

                                  <li><a data-barba href="dashboard.html">Dashboard</a></li>

                                  <li><a data-barba href="dshb-courses.html">My Courses</a></li>

                                  <li><a data-barba href="dshb-bookmarks.html">Bookmarks</a></li>

                                  <li><a data-barba href="dshb-listing.html">Add Listing</a></li>

                                  <li><a data-barba href="dshb-reviews.html">Reviews</a></li>

                                  <li><a data-barba href="dshb-settings.html">Settings</a></li>

                                  <li><a data-barba href="dshb-administration.html">Administration</a></li>

                                  <li><a data-barba href="dshb-assignment.html">Assignment</a></li>

                                  <li><a data-barba href="dshb-calendar.html">Calendar</a></li>

                                  <li><a data-barba href="dshb-dashboard.html">Single Dashboard</a></li>

                                  <li><a data-barba href="dshb-dictionary.html">Dictionary</a></li>

                                  <li><a data-barba href="dshb-forums.html">Forums</a></li>

                                  <li><a data-barba href="dshb-grades.html">Grades</a></li>

                                  <li><a data-barba href="dshb-messages.html">Messages</a></li>

                                  <li><a data-barba href="dshb-participants.html">Participants</a></li>

                                  <li><a data-barba href="dshb-quiz.html">Quiz</a></li>

                                  <li><a data-barba href="dshb-survey.html">Survey</a></li>

                                </ul>

                              </div>

                              <div class="col">
                                <h4 class="text-17 fw-500 mb-20">Popular Courses</h4>

                                <ul class="mega__list">

                                  <li><a data-barba href="#">Web Developer</a></li>

                                  <li><a data-barba href="#">Mobile Developer</a></li>

                                  <li><a data-barba href="#">Digital Marketing</a></li>

                                  <li><a data-barba href="#">Development</a></li>

                                  <li><a data-barba href="#">Finance &amp; Accounting</a></li>

                                  <li><a data-barba href="#">Design</a></li>

                                  <li><a data-barba href="#">View All Courses</a></li>

                                </ul>

                              </div>
                            </div>

                            <div class="mega-banner bg-purple-1 ml-40">
                              <div class="text-24 lh-15 text-white fw-700">
                                Join more than<br>
                                <span class="text-green-1">8 million learners</span>
                                worldwide
                              </div>
                              <a href="#" class="button -md -green-1 text-dark-1 fw-500 col-12">Start Learning For Free</a>
                            </div>
                          </div>
                        </div>


                        <ul class="subnav d-none xl:d-block">
                          <li class="menu__backButton js-nav-list-back">
                            <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Courses</a>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">Course List Layouts<div class="icon-chevron-right text-11"></div></a>

                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Course List Layouts</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-1') }}">Course List v1</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-2') }}">Course List v2</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-3') }}">Course List v3</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-4') }}">Course List v4</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-5') }}">Course List v5</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-6') }}">Course List v6</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-7') }}">Course List v7</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-8') }}">Course List v8</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.list-all') }}">Course List All</a>
                              </li>

                            </ul>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">Course Single Layouts<div class="icon-chevron-right text-11"></div></a>

                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Course Single Layouts</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.single-1') }}">Course Single v1</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.single-2') }}">Course Single v2</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.single-3') }}">Course Single v3</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.single-4') }}">Course Single v4</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.single-5') }}">Course Single v5</a>
                              </li>

                              <li>
                                <a href="{{ route('courses.single-6') }}">Course Single v6</a>
                              </li>

                            </ul>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">About Courses<div class="icon-chevron-right text-11"></div></a>

                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> About Courses</a>
                              </li>

                              <li>
                                <a href="lesson-single-1.html">Lesson Page v1</a>
                              </li>

                              <li>
                                <a href="lesson-single-2.html">Lesson Page v2</a>
                              </li>

                              <li>
                                <a href="instructors-list-1.html">Instructors List v1</a>
                              </li>

                              <li>
                                <a href="instructors-list-2.html">Instructors List v2</a>
                              </li>

                              <li>
                                <a href="instructors-single.html">Instructors Single</a>
                              </li>

                              <li>
                                <a href="instructors-become.html">Become an Instructor</a>
                              </li>

                            </ul>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">Dashboard Pages<div class="icon-chevron-right text-11"></div></a>

                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Dashboard Pages</a>
                              </li>

                              <li>
                                <a href="dashboard.html">Dashboard</a>
                              </li>

                              <li>
                                <a href="dshb-courses.html">My Courses</a>
                              </li>

                              <li>
                                <a href="dshb-bookmarks.html">Bookmarks</a>
                              </li>

                              <li>
                                <a href="dshb-listing.html">Add Listing</a>
                              </li>

                              <li>
                                <a href="dshb-reviews.html">Reviews</a>
                              </li>

                              <li>
                                <a href="dshb-settings.html">Settings</a>
                              </li>

                              <li>
                                <a href="dshb-administration.html">Administration</a>
                              </li>

                              <li>
                                <a href="dshb-assignment.html">Assignment</a>
                              </li>

                              <li>
                                <a href="dshb-calendar.html">Calendar</a>
                              </li>

                              <li>
                                <a href="dshb-dashboard.html">Single Dashboard</a>
                              </li>

                              <li>
                                <a href="dshb-dictionary.html">Dictionary</a>
                              </li>

                              <li>
                                <a href="dshb-forums.html">Forums</a>
                              </li>

                              <li>
                                <a href="dshb-grades.html">Grades</a>
                              </li>

                              <li>
                                <a href="dshb-messages.html">Messages</a>
                              </li>

                              <li>
                                <a href="dshb-participants.html">Participants</a>
                              </li>

                              <li>
                                <a href="dshb-quiz.html">Quiz</a>
                              </li>

                              <li>
                                <a href="dshb-survey.html">Survey</a>
                              </li>

                            </ul>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">Popular Courses<div class="icon-chevron-right text-11"></div></a>

                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Popular Courses</a>
                              </li>

                              <li>
                                <a href="#">Web Developer</a>
                              </li>

                              <li>
                                <a href="#">Mobile Developer</a>
                              </li>

                              <li>
                                <a href="#">Digital Marketing</a>
                              </li>

                              <li>
                                <a href="#">Development</a>
                              </li>

                              <li>
                                <a href="#">Finance &amp; Accounting</a>
                              </li>

                              <li>
                                <a href="#">Design</a>
                              </li>

                              <li>
                                <a href="#">View All Courses</a>
                              </li>

                            </ul>
                          </li>
                        </ul>
                      </li>

                      <li class="menu-item-has-children">
                        <a data-barba href="#">Events <i class="icon-chevron-right text-13 ml-10"></i></a>
                        <ul class="subnav">
                          <li class="menu__backButton js-nav-list-back">
                            <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Events</a>
                          </li>

                          <li><a href="event-list-1.html">Event List 1</a></li>

                          <li><a href="event-list-2.html">Event List 2</a></li>

                          <li><a href="event-single.html">Event Single</a></li>

                        </ul>
                      </li>

                      <li class="menu-item-has-children">
                        <a data-barba href="#">Blog <i class="icon-chevron-right text-13 ml-10"></i></a>
                        <ul class="subnav">
                          <li class="menu__backButton js-nav-list-back">
                            <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Blog</a>
                          </li>

                          <li><a href="blog-list-1.html">Blog List 1</a></li>

                          <li><a href="blog-list-2.html">Blog List 2</a></li>

                          <li><a href="blog-list-3.html">Blog List 3</a></li>

                          <li><a href="blog-single.html">Blog Single</a></li>

                        </ul>
                      </li>

                      <li class="menu-item-has-children">
                        <a data-barba href="#">
                          Pages <i class="icon-chevron-right text-13 ml-10"></i>
                        </a>

                        <ul class="subnav">
                          <li class="menu__backButton js-nav-list-back">
                            <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Pages</a>
                          </li>
                          <li class="menu-item-has-children">
                            <a href="#">About Us<div class="icon-chevron-right text-11"></div></a>

                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> About Us</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.about-1') }}">About 1</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.about-2') }}">About 2</a>
                              </li>

                            </ul>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">Contact<div class="icon-chevron-right text-11"></div></a>
                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Contact</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.contact-1') }}">Contact 1</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.contact-2') }}">Contact 2</a>
                              </li>

                            </ul>
                          </li>

                          <li class="menu-item-has-children">
                            <a href="#">Shop<div class="icon-chevron-right text-11"></div></a>
                            <ul class="subnav">
                              <li class="menu__backButton js-nav-list-back">
                                <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Shop</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.shop-cart') }}">Shop Cart</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.shop-checkout') }}">Shop Checkout</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.shop-list') }}">Shop List</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.shop-order') }}">Shop Order</a>
                              </li>

                              <li>
                                <a href="{{ route('pages.shop-single') }}">Shop Single</a>
                              </li>

                            </ul>
                          </li>


                          <li>
                            <a href="pricing.html">Membership plans</a>
                          </li>

                          <li>
                            <a href="404.html">404 Page</a>
                          </li>

                          <li>
                            <a href="terms.html">FAQs</a>
                          </li>

                          <li>
                            <a href="help-center.html">Help Center</a>
                          </li>

                          <li>
                            <a href="{{ route('login') }}">Login</a>
                          </li>

                          <li>
                            <a href="{{ route('register') }}">Register</a>
                          </li>

                          <li>
                            <a href="ui-elements.html">UI Elements</a>
                          </li>

                        </ul>
                      </li>

                      <li>
                        <a data-barba href="{{ route('pages.contact-1') }}">Contact</a>
                      </li>
                    </ul>
                  </div>

                  <div class="mobile-footer px-20 py-20 border-top-light js-mobile-footer">
                    <div class="mobile-footer__number">
                      <div class="text-17 fw-500 text-dark-1">Call us</div>
                      <div class="text-17 fw-500 text-purple-1">800 388 80 90</div>
                    </div>

                    <div class="lh-2 mt-10">
                      <div>329 Queensberry Street,<br> North Melbourne VIC 3051, Australia.</div>
                      <div>hi@educrat.com</div>
                    </div>

                    <div class="mobile-socials mt-10">

                      <a href="#" class="d-flex items-center justify-center rounded-full size-40">
                        <i class="fa fa-facebook"></i>
                      </a>

                      <a href="#" class="d-flex items-center justify-center rounded-full size-40">
                        <i class="fa fa-twitter"></i>
                      </a>

                      <a href="#" class="d-flex items-center justify-center rounded-full size-40">
                        <i class="fa fa-instagram"></i>
                      </a>

                      <a href="#" class="d-flex items-center justify-center rounded-full size-40">
                        <i class="fa fa-linkedin"></i>
                      </a>

                    </div>
                  </div>
                </div>

                <div class="header-menu-close" data-el-toggle=".js-mobile-menu-toggle">
                  <div class="size-40 d-flex items-center justify-center rounded-full bg-white">
                    <div class="icon-close text-dark-1 text-16"></div>
                  </div>
                </div>

                <div class="header-menu-bg"></div>
              </div>

            </div>
          </div>


          <div class="col-auto">
            <div class="header-right d-flex items-center">
              <div class="header-right__icons text-white d-flex items-center">

                <div class="">
                  <button class="d-flex items-center text-dark-1" data-el-toggle=".js-search-toggle">
                    <i class="text-20 icon icon-search"></i>
                  </button>

                  <div class="toggle-element js-search-toggle">
                    <div class="header-search pt-90 bg-white shadow-4">
                      <div class="container">
                        <div class="header-search__field">
                          <div class="icon icon-search text-dark-1"></div>
                          <input type="text" class="col-12 text-18 lh-12 text-dark-1 fw-500" placeholder="What do you want to learn?">

                          <button class="d-flex items-center justify-center size-40 rounded-full bg-purple-3" data-el-toggle=".js-search-toggle">
                            <img src="{{ asset('template/img/menus/close.svg') }}" alt="icon">
                          </button>
                        </div>

                        <div class="header-search__content mt-30">
                          <div class="text-17 text-dark-1 fw-500">Popular Right Now</div>

                          <div class="d-flex y-gap-5 flex-column mt-20">
                            <a href="{{ route('courses.single-1') }}" class="text-dark-1">The Ultimate Drawing Course - Beginner to Advanced</a>
                            <a href="{{ route('courses.single-2') }}" class="text-dark-1">Character Art School: Complete Character Drawing Course</a>
                            <a href="{{ route('courses.single-3') }}" class="text-dark-1">Complete Blender Creator: Learn 3D Modelling for Beginners</a>
                            <a href="{{ route('courses.single-4') }}" class="text-dark-1">User Experience Design Essentials - Adobe XD UI UX Design</a>
                            <a href="{{ route('courses.single-5') }}" class="text-dark-1">Graphic Design Masterclass - Learn GREAT Design</a>
                            <a href="{{ route('courses.single-6') }}" class="text-dark-1">Adobe Photoshop CC � Essentials Training Course</a>
                          </div>

                          <div class="mt-30">
                            <button class="uppercase underline">PRESS ENTER TO SEE ALL SEARCH RESULTS</button>
                          </div>
                        </div>
                      </div>
                    </div>
                    <div class="header-search__bg" data-el-toggle=".js-search-toggle"></div>
                  </div>
                </div>


                <div class="relative ml-30 xl:ml-20">
                  <button class="d-flex items-center text-dark-1" data-el-toggle=".js-cart-toggle">
                    <i class="text-20 icon icon-basket"></i>
                  </button>

                  <div class="toggle-element js-cart-toggle">
                    <div class="header-cart bg-white -dark-bg-dark-1 rounded-8">
                      <div class="px-30 pt-30 pb-10">

                        <div class="row justify-between x-gap-40 pb-20">
                          <div class="col">
                            <div class="row x-gap-10 y-gap-10">
                              <div class="col-auto">
                                <img src="{{ asset('template/img/menus/cart/1.png') }}" alt="image">
                              </div>

                              <div class="col">
                                <div class="text-dark-1 lh-15">The Ultimate Drawing Course Beginner to Advanced...</div>

                                <div class="d-flex items-center mt-10">
                                  <div class="lh-12 fw-500 line-through text-light-1 mr-10">$179</div>
                                  <div class="text-18 lh-12 fw-500 text-dark-1">$79</div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="col-auto">
                            <button><img src="{{ asset('template/img/menus/close.svg') }}" alt="icon"></button>
                          </div>
                        </div>

                        <div class="row justify-between x-gap-40 pb-20">
                          <div class="col">
                            <div class="row x-gap-10 y-gap-10">
                              <div class="col-auto">
                                <img src="{{ asset('template/img/menus/cart/2.png') }}" alt="image">
                              </div>

                              <div class="col">
                                <div class="text-dark-1 lh-15">User Experience Design Essentials - Adobe XD UI UX...</div>

                                <div class="d-flex items-center mt-10">
                                  <div class="lh-12 fw-500 line-through text-light-1 mr-10">$179</div>
                                  <div class="text-18 lh-12 fw-500 text-dark-1">$79</div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="col-auto">
                            <button><img src="{{ asset('template/img/menus/close.svg') }}" alt="icon"></button>
                          </div>
                        </div>

                      </div>

                      <div class="px-30 pt-20 pb-30 border-top-light">
                        <div class="d-flex justify-between">
                          <div class="text-18 lh-12 text-dark-1 fw-500">Total:</div>
                          <div class="text-18 lh-12 text-dark-1 fw-500">$659</div>
                        </div>

                        <div class="row x-gap-20 y-gap-10 pt-30">
                          <div class="col-sm-6">
                            <button class="button py-20 -dark-1 text-white -dark-button-white col-12">View Cart</button>
                          </div>
                          <div class="col-sm-6">
                            <button class="button py-20 -purple-1 text-white col-12">Checkout</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


                <div class="d-none xl:d-block ml-20">
                  <button class="text-dark-1 items-center" data-el-toggle=".js-mobile-menu-toggle">
                    <i class="text-11 icon icon-mobile-menu"></i>
                  </button>
                </div>

              </div>

              <div class="header-right__buttons d-flex items-center ml-30 xl:ml-20 lg:d-none">
                <a href="{{ route('login') }}" class="button -underline text-dark-1">Log in</a>
                <a href="{{ route('register') }}" class="button px-25 h-50 -dark-1 text-white ml-20">Sign up</a>
              </div>
            </div>
          </div>

        </div>
      </div>
    </header>


    <div class="content-wrapper  js-content-wrapper">

      <section data-anim-wrap class="masthead -type-5">
        <div class="masthead__bg"></div>

        <div class="masthead__container">
          <div class="row y-gap-50 items-center">
            <div class="col-lg-6">
              <div class="masthead__content">
                <div data-anim-child="slide-up delay-2" class="text-17 lh-15 text-orange-1 fw-500 mb-10">
                  Start learning for free
                </div>
                <h1 data-anim-child="slide-up delay-2" class="masthead__title">
                  Studies can now be done
                  online much easily
                </h1>
                <p data-anim-child="slide-up delay-3" class="mt-5">
                  You can access 7900+ different courses from 600<br class="lg:d-none">
                  professional trainers for free
                </p>
                <div data-anim-child="slide-up delay-4" class="row items-center x-gap-20 y-gap-20 pt-20">
                  <div class="col-auto">
                    <a href="{{ route('register') }}" class="button -md -orange-1 text-white">Join For Free</a>
                  </div>
                  <div class="col-auto">
                    <a href="{{ route('courses.list-1') }}" class="button -md -outline-light-5 text-dark-1">Find Courses</a>
                  </div>
                </div>

                <div data-anim-child="slide-up delay-5" class="row x-gap-20 y-gap-20 items-center pt-60 lg:pt-30">

                  <div class="col-xl-4 col-auto">
                    <div class="text-dark-1">
                      <div class="mr-10">
                        <img src="{{ asset('template/img/home-8/hero/icons/1.svg') }}" alt="icon">
                      </div>
                      <div class="fw-500 lh-11 mt-10">Over 12 million<br> students</div>
                    </div>
                  </div>

                  <div class="col-xl-4 col-auto">
                    <div class="text-dark-1">
                      <div class="mr-10">
                        <img src="{{ asset('template/img/home-8/hero/icons/2.svg') }}" alt="icon">
                      </div>
                      <div class="fw-500 lh-11 mt-10">More than<br> 60,000 courses</div>
                    </div>
                  </div>

                  <div class="col-xl-4 col-auto">
                    <div class="text-dark-1">
                      <div class="mr-10">
                        <img src="{{ asset('template/img/home-8/hero/icons/3.svg') }}" alt="icon">
                      </div>
                      <div class="fw-500 lh-11 mt-10">Learn anything<br> online</div>
                    </div>
                  </div>

                </div>
              </div>
            </div>

            <div class="col-lg-6">
              <div data-anim-child="slide-up delay-6" class="masthead__image">
                <img src="{{ asset('template/img/home-8/hero/image.png') }}" alt="image">
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-md">
        <div class="container">
          <div class="row justify-center text-center">
            <div class="col-auto">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Top Categories</h2>

                <p class="sectionTitle__text ">10,000+ unique online course list designs</p>

              </div>

            </div>
          </div>

          <div class="row x-gap-40 y-gap-40 justify-between lg:justify-center pt-60 lg:pt-40">

            <div class="col-lg-auto col-sm-4 col-6">
              <div class="text-center">
                <div class="d-flex justify-center items-center rounded-8 size-90 mx-auto bg-orange-2">
                  <img src="{{ asset('template/img/home-8/categories/1.svg') }}" alt="icon">
                </div>
                <h5 class="text-17 lh-15 fw-500 mt-20">Digital<br>Marketing</h5>
                <p class="text-13 lh-1 mt-10">573+ Courses</p>
              </div>
            </div>

            <div class="col-lg-auto col-sm-4 col-6">
              <div class="text-center">
                <div class="d-flex justify-center items-center rounded-8 size-90 mx-auto bg-green-2">
                  <img src="{{ asset('template/img/home-8/categories/2.svg') }}" alt="icon">
                </div>
                <h5 class="text-17 lh-15 fw-500 mt-20">Web <br>Development</h5>
                <p class="text-13 lh-1 mt-10">573+ Courses</p>
              </div>
            </div>

            <div class="col-lg-auto col-sm-4 col-6">
              <div class="text-center">
                <div class="d-flex justify-center items-center rounded-8 size-90 mx-auto bg-purple-2">
                  <img src="{{ asset('template/img/home-8/categories/3.svg') }}" alt="icon">
                </div>
                <h5 class="text-17 lh-15 fw-500 mt-20">Art &<br>Humanities</h5>
                <p class="text-13 lh-1 mt-10">573+ Courses</p>
              </div>
            </div>

            <div class="col-lg-auto col-sm-4 col-6">
              <div class="text-center">
                <div class="d-flex justify-center items-center rounded-8 size-90 mx-auto bg-yellow-5">
                  <img src="{{ asset('template/img/home-8/categories/4.svg') }}" alt="icon">
                </div>
                <h5 class="text-17 lh-15 fw-500 mt-20">Personal<br>Development</h5>
                <p class="text-13 lh-1 mt-10">573+ Courses</p>
              </div>
            </div>

            <div class="col-lg-auto col-sm-4 col-6">
              <div class="text-center">
                <div class="d-flex justify-center items-center rounded-8 size-90 mx-auto bg-green-6">
                  <img src="{{ asset('template/img/home-8/categories/5.svg') }}" alt="icon">
                </div>
                <h5 class="text-17 lh-15 fw-500 mt-20">IT and<br>Software</h5>
                <p class="text-13 lh-1 mt-10">573+ Courses</p>
              </div>
            </div>

            <div class="col-lg-auto col-sm-4 col-6">
              <div class="text-center">
                <div class="d-flex justify-center items-center rounded-8 size-90 mx-auto bg-light-10">
                  <img src="{{ asset('template/img/home-8/categories/6.svg') }}" alt="icon">
                </div>
                <h5 class="text-17 lh-15 fw-500 mt-20">Social<br>Sciences</h5>
                <p class="text-13 lh-1 mt-10">573+ Courses</p>
              </div>
            </div>

            <div class="col-lg-auto col-sm-4 col-6">
              <div class="text-center">
                <div class="d-flex justify-center items-center rounded-8 size-90 mx-auto bg-green-7">
                  <img src="{{ asset('template/img/home-8/categories/7.svg') }}" alt="icon">
                </div>
                <h5 class="text-17 lh-15 fw-500 mt-20">Graphic<br>Design</h5>
                <p class="text-13 lh-1 mt-10">573+ Courses</p>
              </div>
            </div>

          </div>
        </div>
      </section>

      <section class="layout-pt-md layout-pb-lg">
        <div data-anim-wrap class="container">
          <div class="row justify-center text-center">
            <div class="col-auto">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Our Most Popular Courses</h2>

                <p class="sectionTitle__text ">10,000+ unique online course list designs</p>

              </div>


              <div class="d-flex x-gap-20 text-left pt-60 lg:pt-40">
                <div>

                  <div class="dropdown js-dropdown js-category-active">
                    <div class="dropdown__button d-flex items-center text-14 rounded-8 px-15 py-10 text-dark-1" data-el-toggle=".js-category-toggle" data-el-toggle-active=".js-category-active">
                      <span class="js-dropdown-title">Category</span>
                      <i class="icon text-9 ml-40 icon-chevron-down"></i>
                    </div>

                    <div class="toggle-element -dropdown -dark-bg-dark-2 -dark-border-white-10 js-click-dropdown js-category-toggle">
                      <div class="text-14 y-gap-15 js-dropdown-list">

                        <div><a href="#" class="d-block js-dropdown-link">Animation</a></div>

                        <div><a href="#" class="d-block js-dropdown-link">Design</a></div>

                        <div><a href="#" class="d-block js-dropdown-link">Illustration</a></div>

                        <div><a href="#" class="d-block js-dropdown-link">Lifestyle</a></div>

                        <div><a href="#" class="d-block js-dropdown-link">Business</a></div>

                      </div>
                    </div>
                  </div>

                </div>
                <div>

                  <div class="dropdown js-dropdown js-rating-active">
                    <div class="dropdown__button d-flex items-center text-14 rounded-8 px-15 py-10 text-dark-1" data-el-toggle=".js-rating-toggle" data-el-toggle-active=".js-rating-active">
                      <span class="js-dropdown-title">Rating</span>
                      <i class="icon text-9 ml-40 icon-chevron-down"></i>
                    </div>

                    <div class="toggle-element -dropdown -dark-bg-dark-2 -dark-border-white-10 js-click-dropdown js-rating-toggle">
                      <div class="text-14 y-gap-15 js-dropdown-list">

                        <div><a href="#" class="d-block js-dropdown-link">Great</a></div>

                        <div><a href="#" class="d-block js-dropdown-link">Good</a></div>

                        <div><a href="#" class="d-block js-dropdown-link">Medium</a></div>

                        <div><a href="#" class="d-block js-dropdown-link">Low</a></div>

                      </div>
                    </div>
                  </div>

                </div>
                <div>

                  <div class="dropdown js-dropdown js-diff-active">
                    <div class="dropdown__button d-flex items-center text-14 rounded-8 px-15 py-10 text-dark-1" data-el-toggle=".js-diff-toggle" data-el-toggle-active=".js-diff-active">
                      <span class="js-dropdown-title">Diffiulty</span>
                      <i class="icon text-9 ml-40 icon-chevron-down"></i>
                    </div>

                    <div class="toggle-element -dropdown -dark-bg-dark-2 -dark-border-white-10 js-click-dropdown js-diff-toggle">
                      <div class="text-14 y-gap-15 js-dropdown-list">

                        <div><a href="#" class="d-block js-dropdown-link">Hard</a></div>

                        <div><a href="#" class="d-block js-dropdown-link">Meduium</a></div>

                        <div><a href="#" class="d-block js-dropdown-link">Easy</a></div>

                      </div>
                    </div>
                  </div>

                </div>
              </div>
            </div>
          </div>

          <div class="row y-gap-30 justify-center pt-60 lg:pt-40">

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-1">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/1.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Learn Figma - UI/UX Design Essential Training</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-2">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/2.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                      <div>
                        <div class="px-15 rounded-200 bg-purple-1">
                          <span class="text-11 lh-1 uppercase fw-500 text-white">Popular</span>
                        </div>
                      </div>

                      <div>
                        <div class="px-15 rounded-200 bg-green-1">
                          <span class="text-11 lh-1 uppercase fw-500 text-dark-1">Best sellers</span>
                        </div>
                      </div>

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Python Bootcamp From Zero to Hero in Python</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-3">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/3.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Angular - The Complete Guide (2022 Edition)</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-4">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/4.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Ultimate Drawing Course Beginner to Advanced</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-5">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/5.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Photography Masterclass: A Complete Guide to Photography</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-6">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/6.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Instagram Marketing 2021: Complete Guide To Instagram</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-7">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/7.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Blender Creator: Learn 3D Modelling for Beginners</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-8">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/8.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Complete Financial Analyst Training &amp; Investing Course</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

          </div>

          <div class="row justify-center pt-60 lg:pt-40">
            <div class="col-auto">
              <a href="#" class="button -md -outline-light-5 text-dark-1">
                View All Courses
              </a>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg bg-dark-5">
        <div data-anim-wrap class="container">
          <div class="row justify-center text-center">
            <div data-anim-child="slide-up delay-1" class="col-auto">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title text-white">Why learn with our courses?</h2>

                <p class="sectionTitle__text text-white">Lorem ipsum dolor sit amet, consectetur.</p>

              </div>

            </div>
          </div>

          <div class="row y-gap-30 pt-50">

            <div data-anim-child="slide-up delay-2" class="col-lg-4 col-md-6">
              <div class="stepCard -type-1 -stepCard-hover">
                <div class="stepCard__content">
                  <div class="stepCard__icon">
                    <i class="icon-online-learning-4 text-64 text-green-1"></i>
                  </div>
                  <h4 class="stepCard__title">01. Learn</h4>
                  <p class="stepCard__text"> Lorem ipsum dolor sit amet, consectetur dolorili adipiscing elit. Felis donec massa aliqua.</p>
                </div>
              </div>
            </div>

            <div data-anim-child="slide-up delay-3" class="col-lg-4 col-md-6">
              <div class="stepCard -type-1 -stepCard-hover">
                <div class="stepCard__content">
                  <div class="stepCard__icon">
                    <i class="icon-graduation-1 text-64 text-green-1"></i>
                  </div>
                  <h4 class="stepCard__title">02. Graduate</h4>
                  <p class="stepCard__text"> Lorem ipsum dolor sit amet, consectetur dolorili adipiscing elit. Felis donec massa aliqua.</p>
                </div>
              </div>
            </div>

            <div data-anim-child="slide-up delay-4" class="col-lg-4 col-md-6">
              <div class="stepCard -type-1 -stepCard-hover">
                <div class="stepCard__content">
                  <div class="stepCard__icon">
                    <i class="icon-working-at-home-2 text-64 text-green-1"></i>
                  </div>
                  <h4 class="stepCard__title">03. Work</h4>
                  <p class="stepCard__text"> Lorem ipsum dolor sit amet, consectetur dolorili adipiscing elit. Felis donec massa aliqua.</p>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg">
        <div class="container">
          <div class="row justify-center text-center">
            <div class="col-xl-6 col-lg-7">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">What is Educrat?</h2>

                <p class="sectionTitle__text ">Learn the data skills you need online at your own pace�from non-coding essentials to data science and machine learning.</p>

              </div>

            </div>
          </div>

          <div data-anim-wrap class="row y-gap-30 justify-between items-center pt-60 lg:pt-40">
            <div data-anim-child="slide-up" class="col-lg-6">
              <img class="w-1/1" src="{{ asset('template/img/home-8/what/1.png') }}" alt="image">
            </div>

            <div class="col-xl-5 col-lg-6 col-md-9">
              <div class="d-flex flex-column y-gap-30">

                <div data-anim-child="slide-up delay-2" class="d-flex">
                  <div class="d-flex justify-center items-center size-70 bg-orange-5 rounded-full">
                    <img src="{{ asset('template/img/home-8/what/icons/1.svg') }}" alt="icon">
                  </div>
                  <div class="ml-20">
                    <h5 class="text-18 lh-11 text-dark-1 fw-500">Industry expert teachers</h5>
                    <p class="text-dark-1 mt-5">Lorem ipsum dolor sit amet, consectetur dolorili adipiscing elit. Felis donec massa aliquam id dolor .</p>
                  </div>
                </div>

                <div data-anim-child="slide-up delay-3" class="d-flex">
                  <div class="d-flex justify-center items-center size-70 bg-orange-5 rounded-full">
                    <img src="{{ asset('template/img/home-8/what/icons/2.svg') }}" alt="icon">
                  </div>
                  <div class="ml-20">
                    <h5 class="text-18 lh-11 text-dark-1 fw-500">Up-to-date course content</h5>
                    <p class="text-dark-1 mt-5">Lorem ipsum dolor sit amet, consectetur dolorili adipiscing elit. Felis donec massa aliquam id dolor .</p>
                  </div>
                </div>

                <div data-anim-child="slide-up delay-4" class="d-flex">
                  <div class="d-flex justify-center items-center size-70 bg-orange-5 rounded-full">
                    <img src="{{ asset('template/img/home-8/what/icons/3.svg') }}" alt="icon">
                  </div>
                  <div class="ml-20">
                    <h5 class="text-18 lh-11 text-dark-1 fw-500">Students community</h5>
                    <p class="text-dark-1 mt-5">Lorem ipsum dolor sit amet, consectetur dolorili adipiscing elit. Felis donec massa aliquam id dolor .</p>
                  </div>
                </div>

              </div>

              <div data-anim-child="slide-up delay-5" class="d-inline-block mt-30">
                <a href="#" class="button -md -orange-1 text-white">Start Learning For Free </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="section-bg pt-90 pb-90 lg:pt-50 lg:pb-50">
        <div class="section-bg__item -full">
          <div class="bg-image js-lazy" data-bg="img/home-8/grow/bg.png') }}"></div>
        </div>

        <div class="container">
          <div data-anim-wrap class="row y-gap-30 justify-between items-center">
            <div data-anim-child="slide-up delay-3" class="col-xl-4 col-lg-5 col-md-8">
              <h2 class="text-30 lh-15 text-white">Grow your career today with the Education courses</h2>
              <p class="text-white mt-15">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt.</p>
              <div class="d-inline-block mt-25">
                <a href="#" class="button -md -green-1 text-dark-1">Explore Courses</a>
              </div>
            </div>

            <div data-anim-child="slide-up delay-1" class="col-lg-auto">
              <div class="composition -type-6">
                <div class="-el-1">
                  <div class="bg-white rounded-16 px-60 py-50 sm:px-30 sm:py-40 text-center">
                    <div class="text-55 fw-700 text-dark-1">9/10</div>
                    <div class="mt-10">Overall courses satisfaction score</div>
                  </div>
                </div>

                <div class="-el-2">
                  <div class="bg-white rounded-16 px-60 py-50 sm:px-30 sm:py-40 text-center">
                    <div class="text-55 fw-700 text-dark-1">10K+</div>
                    <div class="mt-10">Happy Students Worldwide</div>
                  </div>
                </div>

                <div class="-el-3">
                  <div class="bg-white rounded-16 px-60 py-50 sm:px-30 sm:py-40 text-center">
                    <div class="text-55 fw-700 text-dark-1">96%</div>
                    <div class="mt-10">Completition Rate On All Courses</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg">
        <div class="container">
          <div class="row y-gap-50">
            <div class="col-xl-3 col-lg-4 col-md-8">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Learn from the best instructors</h2>

                <p class="sectionTitle__text ">Lorem ipsum dolor sit amet, consectetur dolorili adipiscing elit. Felis donec massa aliquam id dolor.</p>

              </div>


              <div class="d-inline-block">

                <a href="instructors-list-1.html" class="button -icon -red-2 text-orange-1 mt-30">
                  View All Instructors
                  <i class="icon-arrow-top-right text-13 ml-10"></i>
                </a>

              </div>
            </div>

            <div class="offset-xl-1 col-lg-8">
              <div class="overflow-hidden js-section-slider" data-loop data-pagination data-slider-cols="xl-3 lg-3 md-2 sm-2">
                <div class="swiper-wrapper">

                  <div class="swiper-slide">
                    <div class="d-flex flex-column items-center">
                      <div>
                        <img src="{{ asset('template/img/speakers/1.png') }}" alt="image">
                      </div>
                      <div class="d-flex items-center mt-20">
                        <div class="icon-star text-9 text-yellow-1 mr-5"></div>
                        <div class="text-yellow-1">4.5</div>
                      </div>
                      <h5 class="text-17 fw-500 mt-10">Jerome Bell</h5>
                      <p class="mt-5">Marketing Coordinator</p>

                      <div class="d-flex x-gap-15 items-center pt-5">

                        <div class="d-flex items-center">
                          <div class="mr-10">
                            <img src="{{ asset('template/img/team/icons/1.svg') }}" alt="icon">
                          </div>
                          <div class="text-13 lh-1">692 Students</div>
                        </div>

                        <div class="d-flex items-center">
                          <div class="mr-10">
                            <img src="{{ asset('template/img/team/icons/2.svg') }}" alt="icon">
                          </div>
                          <div class="text-13 lh-1">15 Course</div>
                        </div>

                      </div>
                    </div>
                  </div>

                  <div class="swiper-slide">
                    <div class="d-flex flex-column items-center">
                      <div>
                        <img src="{{ asset('template/img/speakers/2.png') }}" alt="image">
                      </div>
                      <div class="d-flex items-center mt-20">
                        <div class="icon-star text-9 text-yellow-1 mr-5"></div>
                        <div class="text-yellow-1">4.5</div>
                      </div>
                      <h5 class="text-17 fw-500 mt-10">Bessie Cooper</h5>
                      <p class="mt-5">President of Sales</p>

                      <div class="d-flex x-gap-15 items-center pt-5">

                        <div class="d-flex items-center">
                          <div class="mr-10">
                            <img src="{{ asset('template/img/team/icons/1.svg') }}" alt="icon">
                          </div>
                          <div class="text-13 lh-1">692 Students</div>
                        </div>

                        <div class="d-flex items-center">
                          <div class="mr-10">
                            <img src="{{ asset('template/img/team/icons/2.svg') }}" alt="icon">
                          </div>
                          <div class="text-13 lh-1">15 Course</div>
                        </div>

                      </div>
                    </div>
                  </div>

                  <div class="swiper-slide">
                    <div class="d-flex flex-column items-center">
                      <div>
                        <img src="{{ asset('template/img/speakers/3.png') }}" alt="image">
                      </div>
                      <div class="d-flex items-center mt-20">
                        <div class="icon-star text-9 text-yellow-1 mr-5"></div>
                        <div class="text-yellow-1">4.5</div>
                      </div>
                      <h5 class="text-17 fw-500 mt-10">Kristin Watson</h5>
                      <p class="mt-5">Nursing Assistant</p>

                      <div class="d-flex x-gap-15 items-center pt-5">

                        <div class="d-flex items-center">
                          <div class="mr-10">
                            <img src="{{ asset('template/img/team/icons/1.svg') }}" alt="icon">
                          </div>
                          <div class="text-13 lh-1">692 Students</div>
                        </div>

                        <div class="d-flex items-center">
                          <div class="mr-10">
                            <img src="{{ asset('template/img/team/icons/2.svg') }}" alt="icon">
                          </div>
                          <div class="text-13 lh-1">15 Course</div>
                        </div>

                      </div>
                    </div>
                  </div>

                </div>

                <div class="d-flex justify-center x-gap-15 items-center pt-60 lg:pt-40">
                  <div class="col-auto">
                    <div class="pagination -arrows js-pagination"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-md">
        <div data-anim-wrap class="container">
          <div class="row justify-center text-center">
            <div data-anim-child="slide-up delay-1" class="col-auto">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Upcoming Events</h2>

                <p class="sectionTitle__text ">Lorem ipsum dolor sit amet, consectetur.</p>

              </div>

            </div>
          </div>

          <div class="row y-gap-30 pt-60 lg:pt-40">

            <div data-anim-child="slide-up delay-2" class="col-lg-6">
              <div class="py-10 pl-10 pr-20 border-light bg-white rounded-8 shadow-1 -button-hover-1">
                <div class="row y-gap-20 items-center">
                  <div class="col-auto">
                    <div class="size-120">
                      <img class="img-full rounded-8" src="{{ asset('template/img/courses-list/1.png') }}" alt="icon">
                    </div>
                  </div>

                  <div class="col">
                    <div class="row y-gap-20 items-center">
                      <div class="col">
                        <h4 class="text-17 lh-15 fw-500">Eco-Education in Our Lives: We Can Change the Future</h4>
                        <div class="d-flex x-gap-15 items-center pt-10">
                          <div class="d-flex items-center text-light-1">
                            <div class="icon-calendar-2 text-16"></div>
                            <div class="text-14 lh-1 ml-8">6 April, 2022</div>
                          </div>
                          <div class="d-flex items-center text-light-1">
                            <div class="icon-location text-16"></div>
                            <div class="text-14 lh-1 ml-8">London, UK</div>
                          </div>
                        </div>
                      </div>

                      <div class="col-auto">
                        <div class="-button-hover-1__button">

                          <a href="#" class="button -icon -orange-1 text-white">
                            Buy
                            <i class="icon-arrow-top-right text-13 ml-10"></i>
                          </a>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div data-anim-child="slide-up delay-3" class="col-lg-6">
              <div class="py-10 pl-10 pr-20 border-light bg-white rounded-8 shadow-1 -button-hover-1">
                <div class="row y-gap-20 items-center">
                  <div class="col-auto">
                    <div class="size-120">
                      <img class="img-full rounded-8" src="{{ asset('template/img/courses-list/2.png') }}" alt="icon">
                    </div>
                  </div>

                  <div class="col">
                    <div class="row y-gap-20 items-center">
                      <div class="col">
                        <h4 class="text-17 lh-15 fw-500">Eco-Education in Our Lives: We Can Change the Future</h4>
                        <div class="d-flex x-gap-15 items-center pt-10">
                          <div class="d-flex items-center text-light-1">
                            <div class="icon-calendar-2 text-16"></div>
                            <div class="text-14 lh-1 ml-8">6 April, 2022</div>
                          </div>
                          <div class="d-flex items-center text-light-1">
                            <div class="icon-location text-16"></div>
                            <div class="text-14 lh-1 ml-8">London, UK</div>
                          </div>
                        </div>
                      </div>

                      <div class="col-auto">
                        <div class="-button-hover-1__button">

                          <a href="#" class="button -icon -orange-1 text-white">
                            Buy
                            <i class="icon-arrow-top-right text-13 ml-10"></i>
                          </a>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div data-anim-child="slide-up delay-4" class="col-lg-6">
              <div class="py-10 pl-10 pr-20 border-light bg-white rounded-8 shadow-1 -button-hover-1">
                <div class="row y-gap-20 items-center">
                  <div class="col-auto">
                    <div class="size-120">
                      <img class="img-full rounded-8" src="{{ asset('template/img/courses-list/3.png') }}" alt="icon">
                    </div>
                  </div>

                  <div class="col">
                    <div class="row y-gap-20 items-center">
                      <div class="col">
                        <h4 class="text-17 lh-15 fw-500">Eco-Education in Our Lives: We Can Change the Future</h4>
                        <div class="d-flex x-gap-15 items-center pt-10">
                          <div class="d-flex items-center text-light-1">
                            <div class="icon-calendar-2 text-16"></div>
                            <div class="text-14 lh-1 ml-8">6 April, 2022</div>
                          </div>
                          <div class="d-flex items-center text-light-1">
                            <div class="icon-location text-16"></div>
                            <div class="text-14 lh-1 ml-8">London, UK</div>
                          </div>
                        </div>
                      </div>

                      <div class="col-auto">
                        <div class="-button-hover-1__button">

                          <a href="#" class="button -icon -orange-1 text-white">
                            Buy
                            <i class="icon-arrow-top-right text-13 ml-10"></i>
                          </a>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div data-anim-child="slide-up delay-5" class="col-lg-6">
              <div class="py-10 pl-10 pr-20 border-light bg-white rounded-8 shadow-1 -button-hover-1">
                <div class="row y-gap-20 items-center">
                  <div class="col-auto">
                    <div class="size-120">
                      <img class="img-full rounded-8" src="{{ asset('template/img/courses-list/4.png') }}" alt="icon">
                    </div>
                  </div>

                  <div class="col">
                    <div class="row y-gap-20 items-center">
                      <div class="col">
                        <h4 class="text-17 lh-15 fw-500">Eco-Education in Our Lives: We Can Change the Future</h4>
                        <div class="d-flex x-gap-15 items-center pt-10">
                          <div class="d-flex items-center text-light-1">
                            <div class="icon-calendar-2 text-16"></div>
                            <div class="text-14 lh-1 ml-8">6 April, 2022</div>
                          </div>
                          <div class="d-flex items-center text-light-1">
                            <div class="icon-location text-16"></div>
                            <div class="text-14 lh-1 ml-8">London, UK</div>
                          </div>
                        </div>
                      </div>

                      <div class="col-auto">
                        <div class="-button-hover-1__button">

                          <a href="#" class="button -icon -orange-1 text-white">
                            Buy
                            <i class="icon-arrow-top-right text-13 ml-10"></i>
                          </a>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div data-anim-child="slide-up delay-6" class="col-lg-6">
              <div class="py-10 pl-10 pr-20 border-light bg-white rounded-8 shadow-1 -button-hover-1">
                <div class="row y-gap-20 items-center">
                  <div class="col-auto">
                    <div class="size-120">
                      <img class="img-full rounded-8" src="{{ asset('template/img/courses-list/5.png') }}" alt="icon">
                    </div>
                  </div>

                  <div class="col">
                    <div class="row y-gap-20 items-center">
                      <div class="col">
                        <h4 class="text-17 lh-15 fw-500">Eco-Education in Our Lives: We Can Change the Future</h4>
                        <div class="d-flex x-gap-15 items-center pt-10">
                          <div class="d-flex items-center text-light-1">
                            <div class="icon-calendar-2 text-16"></div>
                            <div class="text-14 lh-1 ml-8">6 April, 2022</div>
                          </div>
                          <div class="d-flex items-center text-light-1">
                            <div class="icon-location text-16"></div>
                            <div class="text-14 lh-1 ml-8">London, UK</div>
                          </div>
                        </div>
                      </div>

                      <div class="col-auto">
                        <div class="-button-hover-1__button">

                          <a href="#" class="button -icon -orange-1 text-white">
                            Buy
                            <i class="icon-arrow-top-right text-13 ml-10"></i>
                          </a>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div data-anim-child="slide-up delay-7" class="col-lg-6">
              <div class="py-10 pl-10 pr-20 border-light bg-white rounded-8 shadow-1 -button-hover-1">
                <div class="row y-gap-20 items-center">
                  <div class="col-auto">
                    <div class="size-120">
                      <img class="img-full rounded-8" src="{{ asset('template/img/courses-list/6.png') }}" alt="icon">
                    </div>
                  </div>

                  <div class="col">
                    <div class="row y-gap-20 items-center">
                      <div class="col">
                        <h4 class="text-17 lh-15 fw-500">Eco-Education in Our Lives: We Can Change the Future</h4>
                        <div class="d-flex x-gap-15 items-center pt-10">
                          <div class="d-flex items-center text-light-1">
                            <div class="icon-calendar-2 text-16"></div>
                            <div class="text-14 lh-1 ml-8">6 April, 2022</div>
                          </div>
                          <div class="d-flex items-center text-light-1">
                            <div class="icon-location text-16"></div>
                            <div class="text-14 lh-1 ml-8">London, UK</div>
                          </div>
                        </div>
                      </div>

                      <div class="col-auto">
                        <div class="-button-hover-1__button">

                          <a href="#" class="button -icon -orange-1 text-white">
                            Buy
                            <i class="icon-arrow-top-right text-13 ml-10"></i>
                          </a>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg">
        <div class="container">
          <div class="row y-gap-30 justify-between items-center">
            <div class="col-xl-4 col-lg-5 col-md-9">
              <h2 class="text-30 lh-13">What Our Students<br>Have To <span class="text-orange-1">Say</span></h2>
              <p class="mt-15">Lorem ipsum dolor sit amet, consectetur dolorili adipiscing elit. Felis donec massa aliquam id dolor.</p>

              <div class="pt-60 lg:pt-50 pr-5 overflow-hidden js-section-slider" data-gap="30" data-pagination data-slider-cols="xl-1" data-anim-wrap>
                <div class="swiper-wrapper">

                  <div class="swiper-slide">
                    <div data-anim="slide-left" class="pt-40 pb-30 px-40 border-light rounded-8">
                      <div class="testimonials__content">
                        <h4 class="text-18 fw-500 text-orange-1">Great Work</h4>
                        <p class="lh-2 fw-500 mt-15 mb-30"> �I think Educrat is the best theme I ever seen this year. Amazing design, easy to customize and a design quality superlative account on its cloud platform for the optimized performance�</p>

                        <div class="row x-gap-20 y-gap-20 items-center border-top-light pt-15">
                          <div class="col-auto">
                            <img src="{{ asset('template/img/testimonials/1.png') }}" alt="image">
                          </div>

                          <div class="col-auto">
                            <div class="lh-12 fw-500 text-dark-1">Courtney Henry</div>
                            <div class="text-13 lh-1 mt-5">Web Designer</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="swiper-slide">
                    <div data-anim="slide-left" class="pt-40 pb-30 px-40 border-light rounded-8">
                      <div class="testimonials__content">
                        <h4 class="text-18 fw-500 text-orange-1">Great Work</h4>
                        <p class="lh-2 fw-500 mt-15 mb-30"> �I think Educrat is the best theme I ever seen this year. Amazing design, easy to customize and a design quality superlative account on its cloud platform for the optimized performance�</p>

                        <div class="row x-gap-20 y-gap-20 items-center border-top-light pt-15">
                          <div class="col-auto">
                            <img src="{{ asset('template/img/testimonials/2.png') }}" alt="image">
                          </div>

                          <div class="col-auto">
                            <div class="lh-12 fw-500 text-dark-1">Ronald Richards</div>
                            <div class="text-13 lh-1 mt-5">President of Sales</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="swiper-slide">
                    <div data-anim="slide-left" class="pt-40 pb-30 px-40 border-light rounded-8">
                      <div class="testimonials__content">
                        <h4 class="text-18 fw-500 text-orange-1">Great Work</h4>
                        <p class="lh-2 fw-500 mt-15 mb-30"> �I think Educrat is the best theme I ever seen this year. Amazing design, easy to customize and a design quality superlative account on its cloud platform for the optimized performance�</p>

                        <div class="row x-gap-20 y-gap-20 items-center border-top-light pt-15">
                          <div class="col-auto">
                            <img src="{{ asset('template/img/testimonials/3.png') }}" alt="image">
                          </div>

                          <div class="col-auto">
                            <div class="lh-12 fw-500 text-dark-1">Annette Black</div>
                            <div class="text-13 lh-1 mt-5">Nursing Assistant</div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                </div>

                <div class="d-flex x-gap-15 items-center pt-30">
                  <div class="col-auto">
                    <button class="d-flex items-center text-24 arrow-left-hover js-prev">
                      <i class="icon icon-arrow-left"></i>
                    </button>
                  </div>
                  <div class="col-auto">
                    <div class="pagination -arrows js-pagination"></div>
                  </div>
                  <div class="col-auto">
                    <button class="d-flex items-center text-24 arrow-right-hover js-next">
                      <i class="icon icon-arrow-right"></i>
                    </button>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-6">
              <div class="composition -type-7">
                <div class="-el-1">
                  <img class="w-1/1" src="{{ asset('template/img/home-8/testimonials/1.png') }}" alt="image">
                </div>

                <div class="-el-2">
                  <a href="https://www.youtube.com/watch?v=ANYfx4-jyqY" class="d-flex items-center justify-center bg-white size-90 rounded-full js-gallery" data-gallery="gallery1">
                    <div class="icon-play text-30"></div>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-md layout-pb-md bg-light-6">
        <div data-anim-wrap class="container">
          <div class="row justify-center">
            <div class="col text-center">
              <p class="text-lg text-dark-1">Trusted by the world�s best</p>
            </div>
          </div>

          <div class="row y-gap-30 justify-between sm:justify-start items-center pt-60 md:pt-50">

            <div data-anim-child="slide-up delay-1" class="col-lg-auto col-md-2 col-sm-3 col-6">
              <div class="d-flex justify-center items-center px-4">
                <img class="w-1/1" src="{{ asset('template/img/clients/1.svg') }}" alt="clients image">
              </div>
            </div>

            <div data-anim-child="slide-up delay-1" class="col-lg-auto col-md-2 col-sm-3 col-6">
              <div class="d-flex justify-center items-center px-4">
                <img class="w-1/1" src="{{ asset('template/img/clients/2.svg') }}" alt="clients image">
              </div>
            </div>

            <div data-anim-child="slide-up delay-1" class="col-lg-auto col-md-2 col-sm-3 col-6">
              <div class="d-flex justify-center items-center px-4">
                <img class="w-1/1" src="{{ asset('template/img/clients/3.svg') }}" alt="clients image">
              </div>
            </div>

            <div data-anim-child="slide-up delay-1" class="col-lg-auto col-md-2 col-sm-3 col-6">
              <div class="d-flex justify-center items-center px-4">
                <img class="w-1/1" src="{{ asset('template/img/clients/4.svg') }}" alt="clients image">
              </div>
            </div>

            <div data-anim-child="slide-up delay-1" class="col-lg-auto col-md-2 col-sm-3 col-6">
              <div class="d-flex justify-center items-center px-4">
                <img class="w-1/1" src="{{ asset('template/img/clients/5.svg') }}" alt="clients image">
              </div>
            </div>

            <div data-anim-child="slide-up delay-1" class="col-lg-auto col-md-2 col-sm-3 col-6">
              <div class="d-flex justify-center items-center px-4">
                <img class="w-1/1" src="{{ asset('template/img/clients/6.svg') }}" alt="clients image">
              </div>
            </div>

          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-md">
        <div class="container">
          <div class="row y-gap-30 items-center">
            <div class="col-xl-5 offset-xl-1 col-lg-6">
              <img class="w-1/1" src="{{ asset('template/img/home-8/features/1.png') }}" alt="image">
            </div>

            <div class="col-xl-4 offset-xl-1 col-lg-6">
              <h3 class="text-24 lh-1">Become an Instructor</h3>
              <p class="mt-20">Join millions of people from around the world learning together. Online learning is as easy and natural as chatting.</p>
              <div class="d-inline-block mt-20">
                <a href="instructors-become.html" class="button -md -outline-purple-1 text-purple-1">Apply Now</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-md layout-pb-lg">
        <div class="container">
          <div class="row y-gap-30 items-center">
            <div class="col-xl-4 offset-xl-1 order-lg-1 col-lg-6 order-2">
              <h3 class="text-24 lh-1">Become a Student</h3>
              <p class="mt-20">Join millions of people from around the world learning together. Online learning is as easy and natural as chatting..</p>
              <div class="d-inline-block mt-20">
                <a href="#" class="button -md -outline-dark-2 text-dark-2">Apply Now</a>
              </div>
            </div>

            <div class="col-xl-5 offset-xl-1 col-lg-6 order-lg-2 order-1">
              <img class="w-1/1" src="{{ asset('template/img/home-8/features/2.png') }}" alt="image">
            </div>
          </div>
        </div>
      </section>

      <footer class="footer -type-5 pt-60 bg-dark-2">
        <div class="container">
          <div class="row y-gap-30 pb-60">
            <div class="col-xl-3 col-lg-5 col-md-6">
              <div class="footer-header__logo">
                <img src="{{ asset('template/img/general/logo-dark.svg') }}" alt="logo">
              </div>

              <div class="mt-30">
                <div class="text-17 text-white">Call Us</div>
                <div class="text-17 lh-1 fw-500 text-white mt-5">800 388 80 90</div>
              </div>

              <div class="mt-30 pr-20">
                <div class="lh-17 text-white">329 Queensberry Street, North Melbourne VIC 3051, Australia. hi@educrat.com</div>
              </div>

              <div class="footer-header-socials mt-30">
                <div class="footer-header-socials__list d-flex items-center text-white">
                  <a href="#" class="size-40 d-flex justify-center items-center"><i class="icon-facebook"></i></a>
                  <a href="#" class="size-40 d-flex justify-center items-center"><i class="icon-twitter"></i></a>
                  <a href="#" class="size-40 d-flex justify-center items-center"><i class="icon-instagram"></i></a>
                  <a href="#" class="size-40 d-flex justify-center items-center"><i class="icon-linkedin"></i></a>
                </div>
              </div>
            </div>

            <div class="col-xl-2 col-lg-4 col-md-6">
              <div class="text-17 fw-500 text-white uppercase mb-25">ABOUT</div>
              <div class="d-flex y-gap-10 flex-column text-white">
                <a href="{{ route('pages.about-1') }}">About Us</a>
                <a href="blog-list-1.html">Learner Stories</a>
                <a href="instructor-become.html">Careers</a>
                <a href="blog-list-1.html">Press</a>
                <a href="#">Leadership</a>
                <a href="{{ route('pages.contact-1') }}">Contact Us</a>
              </div>
            </div>

            <div class="col-xl-4 col-lg-8">
              <div class="text-17 fw-500 text-white uppercase mb-25">CATEGORIES</div>
              <div class="row justify-between y-gap-20">
                <div class="col-lg-auto col-md-6">
                  <div class="d-flex y-gap-10 flex-column text-white">
                    <a href="{{ route('courses.single-1') }}">Development</a>
                    <a href="{{ route('courses.single-2') }}">Business</a>
                    <a href="{{ route('courses.single-3') }}">Finance & Accounting</a>
                    <a href="{{ route('courses.single-4') }}">IT & Software</a>
                    <a href="{{ route('courses.single-5') }}">Office Productivity</a>
                    <a href="{{ route('courses.single-6') }}">Design</a>
                    <a href="{{ route('courses.single-1') }}">Marketing</a>
                  </div>
                </div>

                <div class="col-lg-auto col-md-6">
                  <div class="d-flex y-gap-10 flex-column text-white">
                    <a href="{{ route('courses.single-1') }}">Lifiestyle</a>
                    <a href="{{ route('courses.single-2') }}">Photography & Video</a>
                    <a href="{{ route('courses.single-3') }}">Health & Fitness</a>
                    <a href="{{ route('courses.single-4') }}">Music</a>
                    <a href="{{ route('courses.single-5') }}">UX Design</a>
                    <a href="{{ route('courses.single-6') }}">Seo</a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-2 offset-xl-1 col-lg-4 col-md-6">
              <div class="text-17 fw-500 text-white uppercase mb-25">SUPPORT</div>
              <div class="d-flex y-gap-10 flex-column text-white">
                <a href="terms.html">Documentation</a>
                <a href="help-center.html">FAQS</a>
                <a href="dashboard.html">Dashboard</a>
                <a href="{{ route('pages.contact-1') }}">Contact</a>
              </div>
            </div>
          </div>

          <div class="py-30 border-top-light-15">
            <div class="row justify-between items-center y-gap-20">
              <div class="col-auto">
                <div class="d-flex items-center h-100 text-white">
                  � 2022 Educrat. All Right Reserved.
                </div>
              </div>

              <div class="col-auto">
                <div class="d-flex x-gap-20 y-gap-20 items-center flex-wrap">
                  <div>
                    <div class="d-flex x-gap-15 text-white">
                      <a href="help-center.html">Help</a>
                      <a href="terms.html">Privacy Policy</a>
                      <a href="terms.html">Cookie Notice</a>
                      <a href="terms.html">Security</a>
                      <a href="terms.html">Terms of Use</a>
                    </div>
                  </div>

                  <div>
                    <a href="#" class="button px-30 h-50 -dark-6 rounded-200 text-white">
                      <i class="icon-worldwide text-20 mr-15"></i><span class="text-15">English</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>


    </div>
  </main>

  <!-- JavaScript -->
  <script src="../../../unpkg.com/leaflet%401.7.1/dist/leaflet.js') }}" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
  <script src="{{ asset('template/js/vendors.js') }}"></script>
  <script src="{{ asset('template/js/main.js') }}"></script>
</body>
</html>
























