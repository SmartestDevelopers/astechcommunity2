<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Required meta tags -->
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Google fonts -->
  <link rel="preconnect" href="https://fonts.googleapis.com/">
  <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Work+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;display=swap" rel="stylesheet">

  <link rel="stylesheet" href="../../../cdn.jsdelivr.net/npm/choices.js/public/assets/styles/base.min.css') }}" />
  <link rel="stylesheet" href="../../../cdn.jsdelivr.net/npm/choices.js/public/assets/styles/choices.min.css') }}" />

  <link href="https://fonts.googleapis.com/css2?family=Material+Icons+Outlined" rel="stylesheet">
  <link rel="stylesheet" href="../../../cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css') }}" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="../../../unpkg.com/leaflet%401.7.1/dist/leaflet.css') }}" integrity="sha512-xodZBNTC5n17Xt2atTPuE1HxjVMSvLVW9ocqUKLsCC5CXdbqCmblAshOMAS6/keqq/sMZMZ19scR4PsZChSR7A==" crossorigin="" />

  <!-- Stylesheets -->
  <link rel="stylesheet" href="{{ asset('template/css/vendors.css') }}">
  <link rel="stylesheet" href="{{ asset('template/css/main.css') }}">

  <title>Educrat</title>
</head>

<body class="preloader-visible" data-barba="wrapper">
  <!-- preloader start -->
  <div class="preloader js-preloader">
    <div class="preloader__bg"></div>
  </div>
  <!-- preloader end -->


  <main class="main-content  ">

    <header data-anim="fade" data-add-bg="" class="header -type-3 js-header">


      <div class="header__container py-10">
        <div class="row justify-between items-center">

          <div class="col-auto">
            <div class="header-left d-flex items-center">

              <div class="header__logo ">
                <a data-barba href="{{ route('home') }}">
                  <img src="{{ asset('template/img/general/logo-dark.svg') }}" alt="logo">
                </a>
              </div>


              <div class="header__explore text-purple-1 ml-30 xl:d-none">
                <a href="#" class="d-flex items-center" data-el-toggle=".js-explore-toggle">
                  <i class="icon icon-explore mr-15"></i>
                  Explore
                </a>

                <div class="explore-content py-25 rounded-8 bg-white toggle-element js-explore-toggle">

                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Architecture<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Business<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="text-dark-1">Computer Programming</a>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="text-dark-1">Data Analysis</a>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Design<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="{{ route('courses.single-6') }}" class="text-dark-1">Education</a>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Electronics<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Language<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Marketing<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="text-dark-1">Music Arts</a>
                  </div>

                  <div class="explore__item">
                    <a href="#" class="text-dark-1">Social Science</a>
                  </div>


                  <div class="explore__item">
                    <a href="#" class="d-flex items-center justify-between text-dark-1">
                      Photography & Video<div class="icon-chevron-right text-11"></div>
                    </a>
                    <div class="explore__subnav rounded-8">
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Web Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Graphic Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-3') }}">Design Tools</a>
                      <a class="text-dark-1" href="{{ route('courses.single-4') }}">User Experience Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-5') }}">Game Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-6') }}">3D & Animation</a>
                      <a class="text-dark-1" href="{{ route('courses.single-1') }}">Fashion Design</a>
                      <a class="text-dark-1" href="{{ route('courses.single-2') }}">Interior Design</a>
                    </div>
                  </div>

                  <div class="explore__item">
                    <a href="{{ route('courses.single-1') }}" class="text-dark-1">IT & Software</a>
                  </div>

                  <div class="explore__item">
                    <a href="{{ route('courses.single-2') }}" class="text-purple-1 underline">View All Courses</a>
                  </div>
                </div>
              </div>


              <div class="header-search-field ml-30">
                <form action="#">
                  <div class="header-search-field__group">
                    <input type="text" placeholder="What do you want to learn?">
                    <button type="submit">
                      <i class="icon icon-search"></i>
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>


          <div class="col-auto">
            <div class="header-right d-flex items-center">
              <div class="header-right__icons text-white d-flex items-center">

                <div class="header-menu js-mobile-menu-toggle ">
                  <div class="header-menu__content">
                    <div class="mobile-bg js-mobile-bg"></div>

                    <div class="d-none xl:d-flex items-center px-20 py-20 border-bottom-light">
                      <a href="{{ route('login') }}" class="text-dark-1">Log in</a>
                      <a href="{{ route('register') }}" class="text-dark-1 ml-30">Sign Up</a>
                    </div>

                    <div class="menu js-navList">
                      <ul class="menu__nav text-dark-1 -is-active">
                        <li class="menu-item-has-children">
                          <a data-barba href="#">
                            Home <i class="icon-chevron-right text-13 ml-10"></i>
                          </a>

                          <ul class="subnav">
                            <li class="menu__backButton js-nav-list-back">
                              <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Home</a>
                            </li>

                            <li><a href="{{ route('home') }}">Home 1</a></li>

                            <li><a href="{{ route('pages.home-2') }}">Home 2</a></li>

                            <li><a href="{{ route('pages.home-3') }}">Home 3</a></li>

                            <li><a href="home-4.html">Home 4</a></li>

                            <li><a href="home-5.html">Home 5</a></li>

                            <li><a href="home-6.html">Home 6</a></li>

                            <li><a href="home-7.html">Home 7</a></li>

                            <li><a href="home-8.html">Home 8</a></li>

                            <li><a href="home-9.html">Home 9</a></li>

                            <li><a href="home-10.html">Home 10</a></li>

                          </ul>
                        </li>

                        <li class="menu-item-has-children -has-mega-menu">
                          <a data-barba href="#">Courses <i class="icon-chevron-right text-13 ml-10"></i></a>


                          <div class="mega xl:d-none">
                            <div class="mega__menu">
                              <div class="row x-gap-40">
                                <div class="col">
                                  <h4 class="text-17 fw-500 mb-20">Course List Layouts</h4>

                                  <ul class="mega__list">

                                    <li><a data-barba href="{{ route('courses.list-1') }}">Course List v1</a></li>

                                    <li><a data-barba href="{{ route('courses.list-2') }}">Course List v2</a></li>

                                    <li><a data-barba href="{{ route('courses.list-3') }}">Course List v3</a></li>

                                    <li><a data-barba href="{{ route('courses.list-4') }}">Course List v4</a></li>

                                    <li><a data-barba href="{{ route('courses.list-5') }}">Course List v5</a></li>

                                    <li><a data-barba href="{{ route('courses.list-6') }}">Course List v6</a></li>

                                    <li><a data-barba href="{{ route('courses.list-7') }}">Course List v7</a></li>

                                    <li><a data-barba href="{{ route('courses.list-8') }}">Course List v8</a></li>

                                    <li><a data-barba href="{{ route('courses.list-9') }}">Course List v9</a></li>

                                  </ul>

                                </div>

                                <div class="col">
                                  <h4 class="text-17 fw-500 mb-20">Course Single Layouts</h4>

                                  <ul class="mega__list">

                                    <li><a data-barba href="{{ route('courses.single-1') }}">Course Single v1</a></li>

                                    <li><a data-barba href="{{ route('courses.single-2') }}">Course Single v2</a></li>

                                    <li><a data-barba href="{{ route('courses.single-3') }}">Course Single v3</a></li>

                                    <li><a data-barba href="{{ route('courses.single-4') }}">Course Single v4</a></li>

                                    <li><a data-barba href="{{ route('courses.single-5') }}">Course Single v5</a></li>

                                    <li><a data-barba href="{{ route('courses.single-6') }}">Course Single v6</a></li>

                                  </ul>

                                </div>

                                <div class="col">
                                  <h4 class="text-17 fw-500 mb-20">About Courses</h4>

                                  <ul class="mega__list">

                                    <li><a data-barba href="lesson-single-1.html">Lesson Page v1</a></li>

                                    <li><a data-barba href="lesson-single-2.html">Lesson Page v2</a></li>

                                    <li><a data-barba href="instructors-list-1.html">Instructors List v1</a></li>

                                    <li><a data-barba href="instructors-list-2.html">Instructors List v2</a></li>

                                    <li><a data-barba href="instructors-single.html">Instructors Single</a></li>

                                    <li><a data-barba href="instructors-become.html">Become an Instructor</a></li>

                                  </ul>

                                </div>

                                <div class="col">
                                  <h4 class="text-17 fw-500 mb-20">Dashboard Pages</h4>

                                  <ul class="mega__list">

                                    <li><a data-barba href="dashboard.html">Dashboard</a></li>

                                    <li><a data-barba href="dshb-courses.html">My Courses</a></li>

                                    <li><a data-barba href="dshb-bookmarks.html">Bookmarks</a></li>

                                    <li><a data-barba href="dshb-listing.html">Add Listing</a></li>

                                    <li><a data-barba href="dshb-reviews.html">Reviews</a></li>

                                    <li><a data-barba href="dshb-settings.html">Settings</a></li>

                                    <li><a data-barba href="dshb-administration.html">Administration</a></li>

                                    <li><a data-barba href="dshb-assignment.html">Assignment</a></li>

                                    <li><a data-barba href="dshb-calendar.html">Calendar</a></li>

                                    <li><a data-barba href="dshb-dashboard.html">Single Dashboard</a></li>

                                    <li><a data-barba href="dshb-dictionary.html">Dictionary</a></li>

                                    <li><a data-barba href="dshb-forums.html">Forums</a></li>

                                    <li><a data-barba href="dshb-grades.html">Grades</a></li>

                                    <li><a data-barba href="dshb-messages.html">Messages</a></li>

                                    <li><a data-barba href="dshb-participants.html">Participants</a></li>

                                    <li><a data-barba href="dshb-quiz.html">Quiz</a></li>

                                    <li><a data-barba href="dshb-survey.html">Survey</a></li>

                                  </ul>

                                </div>

                                <div class="col">
                                  <h4 class="text-17 fw-500 mb-20">Popular Courses</h4>

                                  <ul class="mega__list">

                                    <li><a data-barba href="#">Web Developer</a></li>

                                    <li><a data-barba href="#">Mobile Developer</a></li>

                                    <li><a data-barba href="#">Digital Marketing</a></li>

                                    <li><a data-barba href="#">Development</a></li>

                                    <li><a data-barba href="#">Finance &amp; Accounting</a></li>

                                    <li><a data-barba href="#">Design</a></li>

                                    <li><a data-barba href="#">View All Courses</a></li>

                                  </ul>

                                </div>
                              </div>

                              <div class="mega-banner bg-purple-1 ml-40">
                                <div class="text-24 lh-15 text-white fw-700">
                                  Join more than<br>
                                  <span class="text-green-1">8 million learners</span>
                                  worldwide
                                </div>
                                <a href="#" class="button -md -green-1 text-dark-1 fw-500 col-12">Start Learning For Free</a>
                              </div>
                            </div>
                          </div>


                          <ul class="subnav d-none xl:d-block">
                            <li class="menu__backButton js-nav-list-back">
                              <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Courses</a>
                            </li>

                            <li class="menu-item-has-children">
                              <a href="#">Course List Layouts<div class="icon-chevron-right text-11"></div></a>

                              <ul class="subnav">
                                <li class="menu__backButton js-nav-list-back">
                                  <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Course List Layouts</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.list-1') }}">Course List v1</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.list-2') }}">Course List v2</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.list-3') }}">Course List v3</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.list-4') }}">Course List v4</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.list-5') }}">Course List v5</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.list-6') }}">Course List v6</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.list-7') }}">Course List v7</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.list-8') }}">Course List v8</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.list-all') }}">Course List All</a>
                                </li>

                              </ul>
                            </li>

                            <li class="menu-item-has-children">
                              <a href="#">Course Single Layouts<div class="icon-chevron-right text-11"></div></a>

                              <ul class="subnav">
                                <li class="menu__backButton js-nav-list-back">
                                  <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Course Single Layouts</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.single-1') }}">Course Single v1</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.single-2') }}">Course Single v2</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.single-3') }}">Course Single v3</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.single-4') }}">Course Single v4</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.single-5') }}">Course Single v5</a>
                                </li>

                                <li>
                                  <a href="{{ route('courses.single-6') }}">Course Single v6</a>
                                </li>

                              </ul>
                            </li>

                            <li class="menu-item-has-children">
                              <a href="#">About Courses<div class="icon-chevron-right text-11"></div></a>

                              <ul class="subnav">
                                <li class="menu__backButton js-nav-list-back">
                                  <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> About Courses</a>
                                </li>

                                <li>
                                  <a href="lesson-single-1.html">Lesson Page v1</a>
                                </li>

                                <li>
                                  <a href="lesson-single-2.html">Lesson Page v2</a>
                                </li>

                                <li>
                                  <a href="instructors-list-1.html">Instructors List v1</a>
                                </li>

                                <li>
                                  <a href="instructors-list-2.html">Instructors List v2</a>
                                </li>

                                <li>
                                  <a href="instructors-single.html">Instructors Single</a>
                                </li>

                                <li>
                                  <a href="instructors-become.html">Become an Instructor</a>
                                </li>

                              </ul>
                            </li>

                            <li class="menu-item-has-children">
                              <a href="#">Dashboard Pages<div class="icon-chevron-right text-11"></div></a>

                              <ul class="subnav">
                                <li class="menu__backButton js-nav-list-back">
                                  <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Dashboard Pages</a>
                                </li>

                                <li>
                                  <a href="dashboard.html">Dashboard</a>
                                </li>

                                <li>
                                  <a href="dshb-courses.html">My Courses</a>
                                </li>

                                <li>
                                  <a href="dshb-bookmarks.html">Bookmarks</a>
                                </li>

                                <li>
                                  <a href="dshb-listing.html">Add Listing</a>
                                </li>

                                <li>
                                  <a href="dshb-reviews.html">Reviews</a>
                                </li>

                                <li>
                                  <a href="dshb-settings.html">Settings</a>
                                </li>

                                <li>
                                  <a href="dshb-administration.html">Administration</a>
                                </li>

                                <li>
                                  <a href="dshb-assignment.html">Assignment</a>
                                </li>

                                <li>
                                  <a href="dshb-calendar.html">Calendar</a>
                                </li>

                                <li>
                                  <a href="dshb-dashboard.html">Single Dashboard</a>
                                </li>

                                <li>
                                  <a href="dshb-dictionary.html">Dictionary</a>
                                </li>

                                <li>
                                  <a href="dshb-forums.html">Forums</a>
                                </li>

                                <li>
                                  <a href="dshb-grades.html">Grades</a>
                                </li>

                                <li>
                                  <a href="dshb-messages.html">Messages</a>
                                </li>

                                <li>
                                  <a href="dshb-participants.html">Participants</a>
                                </li>

                                <li>
                                  <a href="dshb-quiz.html">Quiz</a>
                                </li>

                                <li>
                                  <a href="dshb-survey.html">Survey</a>
                                </li>

                              </ul>
                            </li>

                            <li class="menu-item-has-children">
                              <a href="#">Popular Courses<div class="icon-chevron-right text-11"></div></a>

                              <ul class="subnav">
                                <li class="menu__backButton js-nav-list-back">
                                  <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Popular Courses</a>
                                </li>

                                <li>
                                  <a href="#">Web Developer</a>
                                </li>

                                <li>
                                  <a href="#">Mobile Developer</a>
                                </li>

                                <li>
                                  <a href="#">Digital Marketing</a>
                                </li>

                                <li>
                                  <a href="#">Development</a>
                                </li>

                                <li>
                                  <a href="#">Finance &amp; Accounting</a>
                                </li>

                                <li>
                                  <a href="#">Design</a>
                                </li>

                                <li>
                                  <a href="#">View All Courses</a>
                                </li>

                              </ul>
                            </li>
                          </ul>
                        </li>

                        <li class="menu-item-has-children">
                          <a data-barba href="#">Events <i class="icon-chevron-right text-13 ml-10"></i></a>
                          <ul class="subnav">
                            <li class="menu__backButton js-nav-list-back">
                              <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Events</a>
                            </li>

                            <li><a href="event-list-1.html">Event List 1</a></li>

                            <li><a href="event-list-2.html">Event List 2</a></li>

                            <li><a href="event-single.html">Event Single</a></li>

                          </ul>
                        </li>

                        <li class="menu-item-has-children">
                          <a data-barba href="#">Blog <i class="icon-chevron-right text-13 ml-10"></i></a>
                          <ul class="subnav">
                            <li class="menu__backButton js-nav-list-back">
                              <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Blog</a>
                            </li>

                            <li><a href="blog-list-1.html">Blog List 1</a></li>

                            <li><a href="blog-list-2.html">Blog List 2</a></li>

                            <li><a href="blog-list-3.html">Blog List 3</a></li>

                            <li><a href="blog-single.html">Blog Single</a></li>

                          </ul>
                        </li>

                        <li class="menu-item-has-children">
                          <a data-barba href="#">
                            Pages <i class="icon-chevron-right text-13 ml-10"></i>
                          </a>

                          <ul class="subnav">
                            <li class="menu__backButton js-nav-list-back">
                              <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Pages</a>
                            </li>
                            <li class="menu-item-has-children">
                              <a href="#">About Us<div class="icon-chevron-right text-11"></div></a>

                              <ul class="subnav">
                                <li class="menu__backButton js-nav-list-back">
                                  <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> About Us</a>
                                </li>

                                <li>
                                  <a href="{{ route('pages.about-1') }}">About 1</a>
                                </li>

                                <li>
                                  <a href="{{ route('pages.about-2') }}">About 2</a>
                                </li>

                              </ul>
                            </li>

                            <li class="menu-item-has-children">
                              <a href="#">Contact<div class="icon-chevron-right text-11"></div></a>
                              <ul class="subnav">
                                <li class="menu__backButton js-nav-list-back">
                                  <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Contact</a>
                                </li>

                                <li>
                                  <a href="{{ route('pages.contact-1') }}">Contact 1</a>
                                </li>

                                <li>
                                  <a href="{{ route('pages.contact-2') }}">Contact 2</a>
                                </li>

                              </ul>
                            </li>

                            <li class="menu-item-has-children">
                              <a href="#">Shop<div class="icon-chevron-right text-11"></div></a>
                              <ul class="subnav">
                                <li class="menu__backButton js-nav-list-back">
                                  <a href="#"><i class="icon-chevron-left text-13 mr-10"></i> Shop</a>
                                </li>

                                <li>
                                  <a href="{{ route('pages.shop-cart') }}">Shop Cart</a>
                                </li>

                                <li>
                                  <a href="{{ route('pages.shop-checkout') }}">Shop Checkout</a>
                                </li>

                                <li>
                                  <a href="{{ route('pages.shop-list') }}">Shop List</a>
                                </li>

                                <li>
                                  <a href="{{ route('pages.shop-order') }}">Shop Order</a>
                                </li>

                                <li>
                                  <a href="{{ route('pages.shop-single') }}">Shop Single</a>
                                </li>

                              </ul>
                            </li>


                            <li>
                              <a href="pricing.html">Membership plans</a>
                            </li>

                            <li>
                              <a href="404.html">404 Page</a>
                            </li>

                            <li>
                              <a href="terms.html">FAQs</a>
                            </li>

                            <li>
                              <a href="help-center.html">Help Center</a>
                            </li>

                            <li>
                              <a href="{{ route('login') }}">Login</a>
                            </li>

                            <li>
                              <a href="{{ route('register') }}">Register</a>
                            </li>

                            <li>
                              <a href="ui-elements.html">UI Elements</a>
                            </li>

                          </ul>
                        </li>

                        <li>
                          <a data-barba href="{{ route('pages.contact-1') }}">Contact</a>
                        </li>
                      </ul>
                    </div>

                    <div class="mobile-footer px-20 py-20 border-top-light js-mobile-footer">
                      <div class="mobile-footer__number">
                        <div class="text-17 fw-500 text-dark-1">Call us</div>
                        <div class="text-17 fw-500 text-purple-1">800 388 80 90</div>
                      </div>

                      <div class="lh-2 mt-10">
                        <div>329 Queensberry Street,<br> North Melbourne VIC 3051, Australia.</div>
                        <div>hi@educrat.com</div>
                      </div>

                      <div class="mobile-socials mt-10">

                        <a href="#" class="d-flex items-center justify-center rounded-full size-40">
                          <i class="fa fa-facebook"></i>
                        </a>

                        <a href="#" class="d-flex items-center justify-center rounded-full size-40">
                          <i class="fa fa-twitter"></i>
                        </a>

                        <a href="#" class="d-flex items-center justify-center rounded-full size-40">
                          <i class="fa fa-instagram"></i>
                        </a>

                        <a href="#" class="d-flex items-center justify-center rounded-full size-40">
                          <i class="fa fa-linkedin"></i>
                        </a>

                      </div>
                    </div>
                  </div>

                  <div class="header-menu-close" data-el-toggle=".js-mobile-menu-toggle">
                    <div class="size-40 d-flex items-center justify-center rounded-full bg-white">
                      <div class="icon-close text-dark-1 text-16"></div>
                    </div>
                  </div>

                  <div class="header-menu-bg"></div>
                </div>


                <div class="relative ml-30 xl:ml-20">
                  <button class="d-flex items-center text-dark-1" data-el-toggle=".js-cart-toggle">
                    <i class="text-20 icon icon-basket"></i>
                  </button>

                  <div class="toggle-element js-cart-toggle">
                    <div class="header-cart bg-white -dark-bg-dark-1 rounded-8">
                      <div class="px-30 pt-30 pb-10">

                        <div class="row justify-between x-gap-40 pb-20">
                          <div class="col">
                            <div class="row x-gap-10 y-gap-10">
                              <div class="col-auto">
                                <img src="{{ asset('template/img/menus/cart/1.png') }}" alt="image">
                              </div>

                              <div class="col">
                                <div class="text-dark-1 lh-15">The Ultimate Drawing Course Beginner to Advanced...</div>

                                <div class="d-flex items-center mt-10">
                                  <div class="lh-12 fw-500 line-through text-light-1 mr-10">$179</div>
                                  <div class="text-18 lh-12 fw-500 text-dark-1">$79</div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="col-auto">
                            <button><img src="{{ asset('template/img/menus/close.svg') }}" alt="icon"></button>
                          </div>
                        </div>

                        <div class="row justify-between x-gap-40 pb-20">
                          <div class="col">
                            <div class="row x-gap-10 y-gap-10">
                              <div class="col-auto">
                                <img src="{{ asset('template/img/menus/cart/2.png') }}" alt="image">
                              </div>

                              <div class="col">
                                <div class="text-dark-1 lh-15">User Experience Design Essentials - Adobe XD UI UX...</div>

                                <div class="d-flex items-center mt-10">
                                  <div class="lh-12 fw-500 line-through text-light-1 mr-10">$179</div>
                                  <div class="text-18 lh-12 fw-500 text-dark-1">$79</div>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="col-auto">
                            <button><img src="{{ asset('template/img/menus/close.svg') }}" alt="icon"></button>
                          </div>
                        </div>

                      </div>

                      <div class="px-30 pt-20 pb-30 border-top-light">
                        <div class="d-flex justify-between">
                          <div class="text-18 lh-12 text-dark-1 fw-500">Total:</div>
                          <div class="text-18 lh-12 text-dark-1 fw-500">$659</div>
                        </div>

                        <div class="row x-gap-20 y-gap-10 pt-30">
                          <div class="col-sm-6">
                            <button class="button py-20 -dark-1 text-white -dark-button-white col-12">View Cart</button>
                          </div>
                          <div class="col-sm-6">
                            <button class="button py-20 -purple-1 text-white col-12">Checkout</button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>


                <div class="d-none xl:d-block ml-20">
                  <button class="text-dark-1 items-center" data-el-toggle=".js-mobile-menu-toggle">
                    <i class="text-11 icon icon-mobile-menu"></i>
                  </button>
                </div>

              </div>

              <div class="header-right__buttons d-flex items-center ml-30 xl:ml-20 md:d-none">
                <a href="{{ route('login') }}" class="button px-30 h-50 -outline-dark-1 text-dark-1">Log in</a>
                <a href="{{ route('register') }}" class="button px-30 h-50 -dark-1 text-white ml-10">Sign up</a>
              </div>
            </div>
          </div>

        </div>
      </div>
    </header>


    <div class="content-wrapper  js-content-wrapper">


      <section data-anim-wrap class="masthead -type-2">
        <div class="masthead__bg">
          <div class="bg-image js-lazy" data-bg="img/home-3/masthead/bg.png') }}"></div>
        </div>

        <div class="container">
          <div class="row y-gap-50 justify-center items-center">
            <div class="col-xl-6 col-lg-11">
              <div class="masthead__content">
                <div data-anim-child="slide-up delay-2" class="masthead__subtitle fw-500 text-green-1 text-17 lh-15">
                  Start learning for free
                </div>
                <h1 data-anim-child="slide-up delay-3" class="masthead__title text-white mt-10">
                  Explore your creativity
                  with thousands of
                  online classes.
                </h1>
                <div data-anim-child="slide-up delay-4" class="masthead__button mt-20">
                  <a href="{{ route('courses.list-1') }}" class="button -md -white text-dark-1">Find Courses</a>
                </div>
              </div>
            </div>

            <div class="col-xl-5 col-lg-11">
              <div data-anim-child="slide-up delay-6" class="masthead-form">
                <h4 class="masthead-form__title text-center text-20 lh-15 fw-500 mb-30">
                  Create Your <span class="text-purple-1">Free Account</span>
                </h4>

                <form action="#">
                  <div class="masthead-form__group">
                    <label>Email Address</label>
                    <input type="text" placeholder="Your Email">
                  </div>

                  <div class="masthead-form__group">
                    <label>Password</label>
                    <input type="text" placeholder="Your Password">
                  </div>

                  <div class="masthead-form__group">
                    <button type="submit" class="button -md -purple-1 text-white">Start Learning For Free</button>
                  </div>

                  <div class="masthead-form__desc">
                    By continuing, you accept our Terms of Use, our Privacy Policy and that your data is stored in the USA. You confirm you are at least 16 years old (13 if you are an authorized Classrooms user).
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-sm layout-pb-sm border-bottom-light">
        <div class="container">
          <div class="row y-gap-30 justify-between">

            <div class="col-xl-3 col-md-6">
              <div class="d-flex items-center">
                <div class="mr-20">
                  <img src="{{ asset('template/img/home-3/masthead/icons/1.svg') }}" alt="icon">
                </div>

                <div>
                  <h4 class="text-20 fw-500">100,000 online courses</h4>
                  <div class="text-dark-1">Explore a variety of fresh topics</div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-6">
              <div class="d-flex items-center">
                <div class="mr-20">
                  <img src="{{ asset('template/img/home-3/masthead/icons/2.svg') }}" alt="icon">
                </div>

                <div>
                  <h4 class="text-20 fw-500">Expert instruction</h4>
                  <div class="text-dark-1">Find the right instructor for you</div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-md-6">
              <div class="d-flex items-center">
                <div class="mr-20">
                  <img src="{{ asset('template/img/home-3/masthead/icons/3.svg') }}" alt="icon">
                </div>

                <div>
                  <h4 class="text-20 fw-500">Lifetime access</h4>
                  <div class="text-dark-1">Learn on your schedule</div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg">
        <div class="container">
          <div class="row y-gap-20 justify-between items-end">
            <div class="col-lg-6">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Top Categories</h2>

                <p class="sectionTitle__text ">Lorem ipsum dolor sit amet, consectetur.</p>

              </div>

            </div>

            <div class="col-auto">

              <a href="#" class="button -icon -purple-3 text-purple-1">
                All Categories
                <i class="icon-arrow-top-right text-13 ml-10"></i>
              </a>

            </div>
          </div>

          <div class="row y-gap-50 pt-60 lg:pt-50">

            <div class="col-xl-3 col-lg-4 col-sm-6">
              <div class="categoryCard -type-2">
                <div class="categoryCard__image mr-20">
                  <img src="{{ asset('template/img/home-3/category/1.png') }}" alt="image">
                </div>

                <div class="categoryCard__content">
                  <h4 class="categoryCard__title text-17 fw-500">Digtal Marketing</h4>
                  <div class="categoryCard__text text-13 lh-1 mt-5">573+ Courses </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6">
              <div class="categoryCard -type-2">
                <div class="categoryCard__image mr-20">
                  <img src="{{ asset('template/img/home-3/category/2.png') }}" alt="image">
                </div>

                <div class="categoryCard__content">
                  <h4 class="categoryCard__title text-17 fw-500">Web Development</h4>
                  <div class="categoryCard__text text-13 lh-1 mt-5">573+ Courses </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6">
              <div class="categoryCard -type-2">
                <div class="categoryCard__image mr-20">
                  <img src="{{ asset('template/img/home-3/category/3.png') }}" alt="image">
                </div>

                <div class="categoryCard__content">
                  <h4 class="categoryCard__title text-17 fw-500">Graphic Design</h4>
                  <div class="categoryCard__text text-13 lh-1 mt-5">573+ Courses </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6">
              <div class="categoryCard -type-2">
                <div class="categoryCard__image mr-20">
                  <img src="{{ asset('template/img/home-3/category/4.png') }}" alt="image">
                </div>

                <div class="categoryCard__content">
                  <h4 class="categoryCard__title text-17 fw-500">Social Sciences</h4>
                  <div class="categoryCard__text text-13 lh-1 mt-5">573+ Courses </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6">
              <div class="categoryCard -type-2">
                <div class="categoryCard__image mr-20">
                  <img src="{{ asset('template/img/home-3/category/5.png') }}" alt="image">
                </div>

                <div class="categoryCard__content">
                  <h4 class="categoryCard__title text-17 fw-500">Photohraphy</h4>
                  <div class="categoryCard__text text-13 lh-1 mt-5">573+ Courses </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6">
              <div class="categoryCard -type-2">
                <div class="categoryCard__image mr-20">
                  <img src="{{ asset('template/img/home-3/category/6.png') }}" alt="image">
                </div>

                <div class="categoryCard__content">
                  <h4 class="categoryCard__title text-17 fw-500">Art &amp; Humanities</h4>
                  <div class="categoryCard__text text-13 lh-1 mt-5">573+ Courses </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6">
              <div class="categoryCard -type-2">
                <div class="categoryCard__image mr-20">
                  <img src="{{ asset('template/img/home-3/category/7.png') }}" alt="image">
                </div>

                <div class="categoryCard__content">
                  <h4 class="categoryCard__title text-17 fw-500">Personal Development</h4>
                  <div class="categoryCard__text text-13 lh-1 mt-5">573+ Courses </div>
                </div>
              </div>
            </div>

            <div class="col-xl-3 col-lg-4 col-sm-6">
              <div class="categoryCard -type-2">
                <div class="categoryCard__image mr-20">
                  <img src="{{ asset('template/img/home-3/category/8.png') }}" alt="image">
                </div>

                <div class="categoryCard__content">
                  <h4 class="categoryCard__title text-17 fw-500">IT and Software</h4>
                  <div class="categoryCard__text text-13 lh-1 mt-5">573+ Courses </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg section-bg">
        <div class="section-bg__item bg-light-6"></div>

        <div data-anim-wrap class="container">
          <div class="row y-gap-15 justify-between items-center">
            <div class="col-lg-6">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Top courses</h2>

                <p class="sectionTitle__text ">10,000+ unique online course list designs</p>

              </div>

            </div>

            <div class="col-lg-auto">
              <div class="d-inline-block">

                <a href="#" class="button -icon -light-11 text-purple-1">
                  All Courses
                  <i class="icon-arrow-top-right text-13 ml-10"></i>
                </a>

              </div>
            </div>
          </div>

          <div class="relative">
            <div class="overflow-hidden pt-60 lg:pt-50 js-section-slider" data-gap="30" data-loop data-pagination data-nav-prev="js-courses-prev" data-nav-next="js-courses-next" data-slider-cols="xl-4 lg-3 md-2 sm-2">
              <div class="swiper-wrapper">

                <div class="swiper-slide">
                  <div data-anim-child="slide-up delay-1">

                    <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 px-10 py-10 border-light bg-white rounded-8">
                      <div class="relative">
                        <div class="coursesCard__image overflow-hidden rounded-8">
                          <img class="w-1/1" src="{{ asset('template/img/coursesCards/1.png') }}" alt="image">
                          <div class="coursesCard__image_overlay rounded-8"></div>
                        </div>
                        <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                        </div>
                      </div>

                      <div class="h-100 px-10 pt-10">
                        <div class="d-flex items-center">
                          <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                          <div class="d-flex x-gap-5 items-center">
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                          </div>
                          <div class="text-13 lh-1 ml-10">(1991)</div>
                        </div>

                        <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Learn Figma - UI/UX Design Essential Training</div>

                        <div class="d-flex x-gap-10 items-center pt-10">

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">6 lesson</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">3h 56m</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">Beginner</div>
                          </div>

                        </div>

                        <div class="coursesCard-footer">
                          <div class="coursesCard-footer__author">
                            <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                            <div>Ali Tufan</div>
                          </div>

                          <div class="coursesCard-footer__price">
                            <div>$179</div>
                            <div>$79</div>
                          </div>
                        </div>
                      </div>
                    </a>

                  </div>
                </div>

                <div class="swiper-slide">
                  <div data-anim-child="slide-up delay-2">

                    <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 px-10 py-10 border-light bg-white rounded-8">
                      <div class="relative">
                        <div class="coursesCard__image overflow-hidden rounded-8">
                          <img class="w-1/1" src="{{ asset('template/img/coursesCards/2.png') }}" alt="image">
                          <div class="coursesCard__image_overlay rounded-8"></div>
                        </div>
                        <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                          <div>
                            <div class="px-15 rounded-200 bg-purple-1">
                              <span class="text-11 lh-1 uppercase fw-500 text-white">Popular</span>
                            </div>
                          </div>

                          <div>
                            <div class="px-15 rounded-200 bg-green-1">
                              <span class="text-11 lh-1 uppercase fw-500 text-dark-1">Best sellers</span>
                            </div>
                          </div>

                        </div>
                      </div>

                      <div class="h-100 px-10 pt-10">
                        <div class="d-flex items-center">
                          <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                          <div class="d-flex x-gap-5 items-center">
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                          </div>
                          <div class="text-13 lh-1 ml-10">(1991)</div>
                        </div>

                        <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Python Bootcamp From Zero to Hero in Python</div>

                        <div class="d-flex x-gap-10 items-center pt-10">

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">6 lesson</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">3h 56m</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">Beginner</div>
                          </div>

                        </div>

                        <div class="coursesCard-footer">
                          <div class="coursesCard-footer__author">
                            <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                            <div>Ali Tufan</div>
                          </div>

                          <div class="coursesCard-footer__price">
                            <div>$179</div>
                            <div>$79</div>
                          </div>
                        </div>
                      </div>
                    </a>

                  </div>
                </div>

                <div class="swiper-slide">
                  <div data-anim-child="slide-up delay-3">

                    <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 px-10 py-10 border-light bg-white rounded-8">
                      <div class="relative">
                        <div class="coursesCard__image overflow-hidden rounded-8">
                          <img class="w-1/1" src="{{ asset('template/img/coursesCards/3.png') }}" alt="image">
                          <div class="coursesCard__image_overlay rounded-8"></div>
                        </div>
                        <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                        </div>
                      </div>

                      <div class="h-100 px-10 pt-10">
                        <div class="d-flex items-center">
                          <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                          <div class="d-flex x-gap-5 items-center">
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                          </div>
                          <div class="text-13 lh-1 ml-10">(1991)</div>
                        </div>

                        <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Angular - The Complete Guide (2022 Edition)</div>

                        <div class="d-flex x-gap-10 items-center pt-10">

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">6 lesson</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">3h 56m</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">Beginner</div>
                          </div>

                        </div>

                        <div class="coursesCard-footer">
                          <div class="coursesCard-footer__author">
                            <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                            <div>Ali Tufan</div>
                          </div>

                          <div class="coursesCard-footer__price">
                            <div>$179</div>
                            <div>$79</div>
                          </div>
                        </div>
                      </div>
                    </a>

                  </div>
                </div>

                <div class="swiper-slide">
                  <div data-anim-child="slide-up delay-4">

                    <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 px-10 py-10 border-light bg-white rounded-8">
                      <div class="relative">
                        <div class="coursesCard__image overflow-hidden rounded-8">
                          <img class="w-1/1" src="{{ asset('template/img/coursesCards/4.png') }}" alt="image">
                          <div class="coursesCard__image_overlay rounded-8"></div>
                        </div>
                        <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                        </div>
                      </div>

                      <div class="h-100 px-10 pt-10">
                        <div class="d-flex items-center">
                          <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                          <div class="d-flex x-gap-5 items-center">
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                          </div>
                          <div class="text-13 lh-1 ml-10">(1991)</div>
                        </div>

                        <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Ultimate Drawing Course Beginner to Advanced</div>

                        <div class="d-flex x-gap-10 items-center pt-10">

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">6 lesson</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">3h 56m</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">Beginner</div>
                          </div>

                        </div>

                        <div class="coursesCard-footer">
                          <div class="coursesCard-footer__author">
                            <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                            <div>Ali Tufan</div>
                          </div>

                          <div class="coursesCard-footer__price">
                            <div>$179</div>
                            <div>$79</div>
                          </div>
                        </div>
                      </div>
                    </a>

                  </div>
                </div>

                <div class="swiper-slide">
                  <div data-anim-child="slide-up delay-5">

                    <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 px-10 py-10 border-light bg-white rounded-8">
                      <div class="relative">
                        <div class="coursesCard__image overflow-hidden rounded-8">
                          <img class="w-1/1" src="{{ asset('template/img/coursesCards/5.png') }}" alt="image">
                          <div class="coursesCard__image_overlay rounded-8"></div>
                        </div>
                        <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                        </div>
                      </div>

                      <div class="h-100 px-10 pt-10">
                        <div class="d-flex items-center">
                          <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                          <div class="d-flex x-gap-5 items-center">
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                          </div>
                          <div class="text-13 lh-1 ml-10">(1991)</div>
                        </div>

                        <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Photography Masterclass: A Complete Guide to Photography</div>

                        <div class="d-flex x-gap-10 items-center pt-10">

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">6 lesson</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">3h 56m</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">Beginner</div>
                          </div>

                        </div>

                        <div class="coursesCard-footer">
                          <div class="coursesCard-footer__author">
                            <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                            <div>Ali Tufan</div>
                          </div>

                          <div class="coursesCard-footer__price">
                            <div>$179</div>
                            <div>$79</div>
                          </div>
                        </div>
                      </div>
                    </a>

                  </div>
                </div>

                <div class="swiper-slide">
                  <div data-anim-child="slide-up delay-6">

                    <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 px-10 py-10 border-light bg-white rounded-8">
                      <div class="relative">
                        <div class="coursesCard__image overflow-hidden rounded-8">
                          <img class="w-1/1" src="{{ asset('template/img/coursesCards/6.png') }}" alt="image">
                          <div class="coursesCard__image_overlay rounded-8"></div>
                        </div>
                        <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                        </div>
                      </div>

                      <div class="h-100 px-10 pt-10">
                        <div class="d-flex items-center">
                          <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                          <div class="d-flex x-gap-5 items-center">
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                          </div>
                          <div class="text-13 lh-1 ml-10">(1991)</div>
                        </div>

                        <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Instagram Marketing 2021: Complete Guide To Instagram</div>

                        <div class="d-flex x-gap-10 items-center pt-10">

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">6 lesson</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">3h 56m</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">Beginner</div>
                          </div>

                        </div>

                        <div class="coursesCard-footer">
                          <div class="coursesCard-footer__author">
                            <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                            <div>Ali Tufan</div>
                          </div>

                          <div class="coursesCard-footer__price">
                            <div>$179</div>
                            <div>$79</div>
                          </div>
                        </div>
                      </div>
                    </a>

                  </div>
                </div>

                <div class="swiper-slide">
                  <div data-anim-child="slide-up delay-7">

                    <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 px-10 py-10 border-light bg-white rounded-8">
                      <div class="relative">
                        <div class="coursesCard__image overflow-hidden rounded-8">
                          <img class="w-1/1" src="{{ asset('template/img/coursesCards/7.png') }}" alt="image">
                          <div class="coursesCard__image_overlay rounded-8"></div>
                        </div>
                        <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                        </div>
                      </div>

                      <div class="h-100 px-10 pt-10">
                        <div class="d-flex items-center">
                          <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                          <div class="d-flex x-gap-5 items-center">
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                          </div>
                          <div class="text-13 lh-1 ml-10">(1991)</div>
                        </div>

                        <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Blender Creator: Learn 3D Modelling for Beginners</div>

                        <div class="d-flex x-gap-10 items-center pt-10">

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">6 lesson</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">3h 56m</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">Beginner</div>
                          </div>

                        </div>

                        <div class="coursesCard-footer">
                          <div class="coursesCard-footer__author">
                            <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                            <div>Ali Tufan</div>
                          </div>

                          <div class="coursesCard-footer__price">
                            <div>$179</div>
                            <div>$79</div>
                          </div>
                        </div>
                      </div>
                    </a>

                  </div>
                </div>

                <div class="swiper-slide">
                  <div data-anim-child="slide-up delay-8">

                    <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 px-10 py-10 border-light bg-white rounded-8">
                      <div class="relative">
                        <div class="coursesCard__image overflow-hidden rounded-8">
                          <img class="w-1/1" src="{{ asset('template/img/coursesCards/8.png') }}" alt="image">
                          <div class="coursesCard__image_overlay rounded-8"></div>
                        </div>
                        <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                        </div>
                      </div>

                      <div class="h-100 px-10 pt-10">
                        <div class="d-flex items-center">
                          <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                          <div class="d-flex x-gap-5 items-center">
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                            <div class="icon-star text-9 text-yellow-1"></div>
                          </div>
                          <div class="text-13 lh-1 ml-10">(1991)</div>
                        </div>

                        <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Complete Financial Analyst Training &amp; Investing Course</div>

                        <div class="d-flex x-gap-10 items-center pt-10">

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">6 lesson</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">3h 56m</div>
                          </div>

                          <div class="d-flex items-center">
                            <div class="mr-8">
                              <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                            </div>
                            <div class="text-14 lh-1">Beginner</div>
                          </div>

                        </div>

                        <div class="coursesCard-footer">
                          <div class="coursesCard-footer__author">
                            <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                            <div>Ali Tufan</div>
                          </div>

                          <div class="coursesCard-footer__price">
                            <div>$179</div>
                            <div>$79</div>
                          </div>
                        </div>
                      </div>
                    </a>

                  </div>
                </div>

              </div>
            </div>


            <button class="section-slider-nav -prev -dark-bg-dark-2 -outline-dark-1 -absolute-out size-50 rounded-full xl:d-none js-courses-prev">
              <i class="icon icon-arrow-left text-24"></i>
            </button>

            <button class="section-slider-nav -next -dark-bg-dark-2 -outline-dark-1 -absolute-out size-50 rounded-full xl:d-none js-courses-next">
              <i class="icon icon-arrow-right text-24"></i>
            </button>

          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg">
        <div class="container">
          <div class="row y-gap-20 justify-center text-center">
            <div class="col-auto">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">How it works?</h2>

                <p class="sectionTitle__text ">10,000+ unique online course list designs</p>

              </div>

            </div>
          </div>

          <div class="row y-gap-30 justify-between pt-60 lg:pt-40">

            <div class="col-xl-2 col-lg-3 col-md-6">
              <div class="d-flex flex-column items-center text-center">
                <div class="relative size-120 d-flex justify-center items-center rounded-full bg-light-4">
                  <img src="{{ asset('template/img/home-3/works/1.svg') }}" alt="image">
                  <div class="side-badge">
                    <div class="size-35 d-flex justify-center items-center rounded-full bg-dark-1 -dark-bg-purple-1">
                      <span class="text-14 fw-500 text-white">01</span>
                    </div>
                  </div>
                </div>
                <div class="text-17 fw-500 text-dark-1 mt-30">Browse courses from our expert contributors.</div>
              </div>
            </div>


            <div class="col-auto xl:d-none">
              <div class="pt-30">
                <img src="{{ asset('template/img/misc/lines/1.svg') }}" alt="icon">
              </div>
            </div>


            <div class="col-xl-2 col-lg-3 col-md-6">
              <div class="d-flex flex-column items-center text-center">
                <div class="relative size-120 d-flex justify-center items-center rounded-full bg-light-4">
                  <img src="{{ asset('template/img/home-3/works/2.svg') }}" alt="image">
                  <div class="side-badge">
                    <div class="size-35 d-flex justify-center items-center rounded-full bg-dark-1 -dark-bg-purple-1">
                      <span class="text-14 fw-500 text-white">02</span>
                    </div>
                  </div>
                </div>
                <div class="text-17 fw-500 text-dark-1 mt-30">Purchase quickly and securely.</div>
              </div>
            </div>


            <div class="col-auto xl:d-none">
              <div class="pt-30">
                <img src="{{ asset('template/img/misc/lines/2.svg') }}" alt="icon">
              </div>
            </div>


            <div class="col-xl-2 col-lg-3 col-md-6">
              <div class="d-flex flex-column items-center text-center">
                <div class="relative size-120 d-flex justify-center items-center rounded-full bg-light-4">
                  <img src="{{ asset('template/img/home-3/works/3.svg') }}" alt="image">
                  <div class="side-badge">
                    <div class="size-35 d-flex justify-center items-center rounded-full bg-dark-1 -dark-bg-purple-1">
                      <span class="text-14 fw-500 text-white">03</span>
                    </div>
                  </div>
                </div>
                <div class="text-17 fw-500 text-dark-1 mt-30">That�s it! Start learning right away.</div>
              </div>
            </div>


          </div>
        </div>
      </section>

      <div class="line px-50">
        <div class="line__item bg-light-5"></div>
      </div>

      <section class="layout-pt-lg layout-pb-lg">
        <div data-anim-wrap class="container">
          <div data-anim-child="slide-left delay-1" class="row y-gap-20 justify-between items-center">
            <div class="col-lg-6">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Learn from the best instructors</h2>

                <p class="sectionTitle__text ">Lorem ipsum dolor sit amet, consectetur.</p>

              </div>

            </div>

            <div class="col-auto">

              <a href="instructors-list-1.html" class="button -icon -purple-3 text-purple-1">
                View All Instructors
                <i class="icon-arrow-top-right text-13 ml-10"></i>
              </a>

            </div>
          </div>

          <div class="row y-gap-30 pt-50">

            <div class="col-lg-3 col-sm-6">
              <div data-anim-child="slide-left delay-2" class="teamCard -type-1 -teamCard-hover">
                <div class="teamCard__image">
                  <img src="{{ asset('template/img/team/1.png') }}" alt="image">
                  <div class="teamCard__socials">
                    <div class="d-flex x-gap-20 y-gap-10 justify-center items-center h-100">
                      <a href="#"><i class="icon-facebook text-white"></i></a>
                      <a href="#"><i class="icon-twitter text-white"></i></a>
                      <a href="#"><i class="icon-instagram text-white"></i></a>
                      <a href="#"><i class="icon-linkedin text-white"></i></a>
                    </div>
                  </div>
                </div>
                <div class="teamCard__content">
                  <h4 class="teamCard__title">Floyd Miles</h4>
                  <p class="teamCard__text">President of Sales</p>

                  <div class="row items-center y-gap-10 x-gap-10 pt-10">
                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-star text-yellow-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12 text-yellow-1 fw-500">4.5</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-online-learning text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">692 Students</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-play text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">15 Course</div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-sm-6">
              <div data-anim-child="slide-left delay-3" class="teamCard -type-1 -teamCard-hover">
                <div class="teamCard__image">
                  <img src="{{ asset('template/img/team/2.png') }}" alt="image">
                  <div class="teamCard__socials">
                    <div class="d-flex x-gap-20 y-gap-10 justify-center items-center h-100">
                      <a href="#"><i class="icon-facebook text-white"></i></a>
                      <a href="#"><i class="icon-twitter text-white"></i></a>
                      <a href="#"><i class="icon-instagram text-white"></i></a>
                      <a href="#"><i class="icon-linkedin text-white"></i></a>
                    </div>
                  </div>
                </div>
                <div class="teamCard__content">
                  <h4 class="teamCard__title">Cameron Williamson</h4>
                  <p class="teamCard__text">Web Designer</p>

                  <div class="row items-center y-gap-10 x-gap-10 pt-10">
                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-star text-yellow-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12 text-yellow-1 fw-500">4.5</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-online-learning text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">692 Students</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-play text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">15 Course</div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-sm-6">
              <div data-anim-child="slide-left delay-4" class="teamCard -type-1 -teamCard-hover">
                <div class="teamCard__image">
                  <img src="{{ asset('template/img/team/3.png') }}" alt="image">
                  <div class="teamCard__socials">
                    <div class="d-flex x-gap-20 y-gap-10 justify-center items-center h-100">
                      <a href="#"><i class="icon-facebook text-white"></i></a>
                      <a href="#"><i class="icon-twitter text-white"></i></a>
                      <a href="#"><i class="icon-instagram text-white"></i></a>
                      <a href="#"><i class="icon-linkedin text-white"></i></a>
                    </div>
                  </div>
                </div>
                <div class="teamCard__content">
                  <h4 class="teamCard__title">Brooklyn Simmons</h4>
                  <p class="teamCard__text">Dog Trainer</p>

                  <div class="row items-center y-gap-10 x-gap-10 pt-10">
                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-star text-yellow-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12 text-yellow-1 fw-500">4.5</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-online-learning text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">692 Students</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-play text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">15 Course</div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-sm-6">
              <div data-anim-child="slide-left delay-5" class="teamCard -type-1 -teamCard-hover">
                <div class="teamCard__image">
                  <img src="{{ asset('template/img/team/4.png') }}" alt="image">
                  <div class="teamCard__socials">
                    <div class="d-flex x-gap-20 y-gap-10 justify-center items-center h-100">
                      <a href="#"><i class="icon-facebook text-white"></i></a>
                      <a href="#"><i class="icon-twitter text-white"></i></a>
                      <a href="#"><i class="icon-instagram text-white"></i></a>
                      <a href="#"><i class="icon-linkedin text-white"></i></a>
                    </div>
                  </div>
                </div>
                <div class="teamCard__content">
                  <h4 class="teamCard__title">Wade Warren</h4>
                  <p class="teamCard__text">Marketing Coordinator</p>

                  <div class="row items-center y-gap-10 x-gap-10 pt-10">
                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-star text-yellow-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12 text-yellow-1 fw-500">4.5</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-online-learning text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">692 Students</div>
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="d-flex items-center">
                        <div class="icon-play text-light-1 text-11 mr-5"></div>
                        <div class="text-14 lh-12">15 Course</div>
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>

          </div>

          <div class="row justify-center text-center pt-60 lg:pt-40">
            <div class="col-auto">
              <p class="lh-1">Want to help people learn, grow and achieve more in life? <a class="text-purple-1 underline" href="instructors-become.html">Become an instructor</a></p>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg section-bg">
        <div class="section-bg__item bg-light-6"></div>

        <div class="container">
          <div class="row y-gap-20 justify-center text-center">
            <div class="col-auto">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Testimonials</h2>

                <p class="sectionTitle__text ">10,000+ unique online course list designs</p>

              </div>

            </div>
          </div>

          <div class="row justify-center pt-60">
            <div class="col-xl-6 col-lg-8 col-md-10">
              <div class="overflow-hidden js-testimonials-slider">
                <div class="swiper-wrapper">

                  <div class="swiper-slide h-100">
                    <div data-anim="slide-up" class="testimonials -type-2 text-center">
                      <div class="testimonials__icon">
                        <img src="{{ asset('template/img/misc/quote.svg') }}" alt="quote">
                      </div>
                      <div class="testimonials__text md:text-20 fw-500 text-dark-1">It is no exaggeration to say this Educrat experience was transformative�both professionally and personally. This workshop will long remain a high point of my life.</div>
                      <div class="testimonials__author">
                        <h5 class="text-17 lh-15 fw-500">Ali Tufan</h5>
                        <div class="mt-5">Product Manager, Apple Inc</div>
                      </div>
                    </div>
                  </div>

                  <div class="swiper-slide h-100">
                    <div data-anim="slide-up" class="testimonials -type-2 text-center">
                      <div class="testimonials__icon">
                        <img src="{{ asset('template/img/misc/quote.svg') }}" alt="quote">
                      </div>
                      <div class="testimonials__text md:text-20 fw-500 text-dark-1">It is no exaggeration to say this Educrat experience was transformative�both professionally and personally. This workshop will long remain a high point of my life.</div>
                      <div class="testimonials__author">
                        <h5 class="text-17 lh-15 fw-500">Ali Tufan</h5>
                        <div class="mt-5">Product Manager, Apple Inc</div>
                      </div>
                    </div>
                  </div>

                  <div class="swiper-slide h-100">
                    <div data-anim="slide-up" class="testimonials -type-2 text-center">
                      <div class="testimonials__icon">
                        <img src="{{ asset('template/img/misc/quote.svg') }}" alt="quote">
                      </div>
                      <div class="testimonials__text md:text-20 fw-500 text-dark-1">It is no exaggeration to say this Educrat experience was transformative�both professionally and personally. This workshop will long remain a high point of my life.</div>
                      <div class="testimonials__author">
                        <h5 class="text-17 lh-15 fw-500">Ali Tufan</h5>
                        <div class="mt-5">Product Manager, Apple Inc</div>
                      </div>
                    </div>
                  </div>

                  <div class="swiper-slide h-100">
                    <div data-anim="slide-up" class="testimonials -type-2 text-center">
                      <div class="testimonials__icon">
                        <img src="{{ asset('template/img/misc/quote.svg') }}" alt="quote">
                      </div>
                      <div class="testimonials__text md:text-20 fw-500 text-dark-1">It is no exaggeration to say this Educrat experience was transformative�both professionally and personally. This workshop will long remain a high point of my life.</div>
                      <div class="testimonials__author">
                        <h5 class="text-17 lh-15 fw-500">Ali Tufan</h5>
                        <div class="mt-5">Product Manager, Apple Inc</div>
                      </div>
                    </div>
                  </div>

                  <div class="swiper-slide h-100">
                    <div data-anim="slide-up" class="testimonials -type-2 text-center">
                      <div class="testimonials__icon">
                        <img src="{{ asset('template/img/misc/quote.svg') }}" alt="quote">
                      </div>
                      <div class="testimonials__text md:text-20 fw-500 text-dark-1">It is no exaggeration to say this Educrat experience was transformative�both professionally and personally. This workshop will long remain a high point of my life.</div>
                      <div class="testimonials__author">
                        <h5 class="text-17 lh-15 fw-500">Ali Tufan</h5>
                        <div class="mt-5">Product Manager, Apple Inc</div>
                      </div>
                    </div>
                  </div>

                </div>

                <div class="pt-60 lg:pt-40">
                  <div class="pagination -avatars row x-gap-40 y-gap-20 justify-center js-testimonials-pagination">

                    <div class="col-auto">
                      <div class="pagination__item is-active">
                        <img src="{{ asset('template/img/home-3/testimonials/1.png') }}" alt="image">
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="pagination__item ">
                        <img src="{{ asset('template/img/home-3/testimonials/2.png') }}" alt="image">
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="pagination__item ">
                        <img src="{{ asset('template/img/home-3/testimonials/3.png') }}" alt="image">
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="pagination__item ">
                        <img src="{{ asset('template/img/home-3/testimonials/4.png') }}" alt="image">
                      </div>
                    </div>

                    <div class="col-auto">
                      <div class="pagination__item ">
                        <img src="{{ asset('template/img/home-3/testimonials/5.png') }}" alt="image">
                      </div>
                    </div>

                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg">
        <div data-anim-wrap class="container">
          <div class="row y-gap-15 justify-between items-center">
            <div class="col-lg-6">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Recent courses</h2>

                <p class="sectionTitle__text ">10,000+ unique online course list designs</p>

              </div>

            </div>

            <div class="col-lg-auto">
              <div class="d-inline-block">

                <div class="dropdown js-dropdown js-category-active">
                  <div class="dropdown__button d-flex items-center text-14 rounded-8 px-15 py-10 text-dark-1" data-el-toggle=".js-category-toggle" data-el-toggle-active=".js-category-active">
                    <span class="js-dropdown-title">Popular Most Viwed</span>
                    <i class="icon text-9 ml-40 icon-chevron-down"></i>
                  </div>

                  <div class="toggle-element -dropdown -dark-bg-dark-2 -dark-border-white-10 js-click-dropdown js-category-toggle">
                    <div class="text-14 y-gap-15 js-dropdown-list">

                      <div><a href="#" class="d-block js-dropdown-link">Great</a></div>

                      <div><a href="#" class="d-block js-dropdown-link">Good</a></div>

                      <div><a href="#" class="d-block js-dropdown-link">Medium</a></div>

                      <div><a href="#" class="d-block js-dropdown-link">Low</a></div>

                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>

          <div class="row y-gap-30 justify-center pt-50">

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-1">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/1.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Learn Figma - UI/UX Design Essential Training</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-2">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/2.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                      <div>
                        <div class="px-15 rounded-200 bg-purple-1">
                          <span class="text-11 lh-1 uppercase fw-500 text-white">Popular</span>
                        </div>
                      </div>

                      <div>
                        <div class="px-15 rounded-200 bg-green-1">
                          <span class="text-11 lh-1 uppercase fw-500 text-dark-1">Best sellers</span>
                        </div>
                      </div>

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Python Bootcamp From Zero to Hero in Python</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-3">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/3.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Angular - The Complete Guide (2022 Edition)</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-4">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/4.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Ultimate Drawing Course Beginner to Advanced</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-5">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/5.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Photography Masterclass: A Complete Guide to Photography</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-6">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/6.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Instagram Marketing 2021: Complete Guide To Instagram</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-7">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/7.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">Complete Blender Creator: Learn 3D Modelling for Beginners</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-up delay-8">

                <a href="{{ route('courses.single-1') }}" class="coursesCard -type-1 border-light rounded-8">
                  <div class="relative">
                    <div class="coursesCard__image overflow-hidden rounded-top-8">
                      <img class="w-1/1" src="{{ asset('template/img/coursesCards/8.png') }}" alt="image">
                      <div class="coursesCard__image_overlay rounded-top-8"></div>
                    </div>
                    <div class="d-flex justify-between py-10 px-10 absolute-full-center z-3">

                    </div>
                  </div>

                  <div class="h-100 pt-15 pb-10 px-20">
                    <div class="d-flex items-center">
                      <div class="text-14 lh-1 text-yellow-1 mr-10">4.5</div>
                      <div class="d-flex x-gap-5 items-center">
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                        <div class="icon-star text-9 text-yellow-1"></div>
                      </div>
                      <div class="text-13 lh-1 ml-10">(1991)</div>
                    </div>

                    <div class="text-17 lh-15 fw-500 text-dark-1 mt-10">The Complete Financial Analyst Training &amp; Investing Course</div>

                    <div class="d-flex x-gap-10 items-center pt-10">

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/1.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">6 lesson</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/2.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">3h 56m</div>
                      </div>

                      <div class="d-flex items-center">
                        <div class="mr-8">
                          <img src="{{ asset('template/img/coursesCards/icons/3.svg') }}" alt="icon">
                        </div>
                        <div class="text-14 lh-1">Beginner</div>
                      </div>

                    </div>

                    <div class="coursesCard-footer">
                      <div class="coursesCard-footer__author">
                        <img src="{{ asset('template/img/general/avatar-1.png') }}" alt="image">
                        <div>Ali Tufan</div>
                      </div>

                      <div class="coursesCard-footer__price">
                        <div>$179</div>
                        <div>$79</div>
                      </div>
                    </div>
                  </div>
                </a>

              </div>
            </div>

          </div>

          <div class="row justify-center pt-60 lg:pt-40">
            <div class="col-auto">

              <a href="#" class="button -icon -purple-3 text-purple-1">
                All Courses
                <i class="icon-arrow-top-right text-13 ml-10"></i>
              </a>

            </div>
          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg section-bg">
        <div class="section-bg__item bg-light-6"></div>

        <div class="container">
          <div class="row y-gap-20 justify-center text-center">
            <div class="col-auto">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">School Achievements</h2>

                <p class="sectionTitle__text ">10,000+ unique online course list designs</p>

              </div>

            </div>
          </div>

          <div class="row pt-60">

            <div class="col-lg-3 col-md-6">
              <div class="infoCard -type-2 text-center py-40 -infoCard-hover">
                <div class="infoCard__image">
                  <img src="{{ asset('template/img/home-3/achieve/1.svg') }}" alt="image">
                </div>
                <h5 class="infoCard__title text-24 lh-1 mt-25">350,000+</h5>
                <p class="infoCard__text mt-5">Students worldwide</p>
              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div class="infoCard -type-2 text-center py-40 -infoCard-hover">
                <div class="infoCard__image">
                  <img src="{{ asset('template/img/home-3/achieve/2.svg') }}" alt="image">
                </div>
                <h5 class="infoCard__title text-24 lh-1 mt-25">496,00+</h5>
                <p class="infoCard__text mt-5">Total course views</p>
              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div class="infoCard -type-2 text-center py-40 -infoCard-hover">
                <div class="infoCard__image">
                  <img src="{{ asset('template/img/home-3/achieve/3.svg') }}" alt="image">
                </div>
                <h5 class="infoCard__title text-24 lh-1 mt-25">19,000+</h5>
                <p class="infoCard__text mt-5">Five-star course reviews</p>
              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div class="infoCard -type-2 text-center py-40 -infoCard-hover">
                <div class="infoCard__image">
                  <img src="{{ asset('template/img/home-3/achieve/4.svg') }}" alt="image">
                </div>
                <h5 class="infoCard__title text-24 lh-1 mt-25">987,000+</h5>
                <p class="infoCard__text mt-5">Students community</p>
              </div>
            </div>

          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg">
        <div class="container">
          <div class="row y-gap-20 justify-center text-center">
            <div class="col-auto">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">What will you learn</h2>

                <p class="sectionTitle__text ">10,000+ unique online course list designs</p>

              </div>

            </div>
          </div>

          <div data-anim-wrap class="pt-60 lg:pt-50">
            <div class="overflow-hidden js-section-slider" data-gap="30" data-loop data-pagination data-slider-cols="xl-6 lg-4 md-3 sm-2">
              <div class="swiper-wrapper">

                <div class="swiper-slide h-100">
                  <div data-anim-child="slide-left delay-1" class="infoCard -type-1">
                    <div class="infoCard__image">
                      <img src="{{ asset('template/img/home-3/learn/1.png') }}" alt="image">
                    </div>
                    <h5 class="infoCard__title text-17 lh-15 mt-10">Node Js</h5>
                  </div>
                </div>

                <div class="swiper-slide h-100">
                  <div data-anim-child="slide-left delay-2" class="infoCard -type-1">
                    <div class="infoCard__image">
                      <img src="{{ asset('template/img/home-3/learn/2.png') }}" alt="image">
                    </div>
                    <h5 class="infoCard__title text-17 lh-15 mt-10">HTML5</h5>
                  </div>
                </div>

                <div class="swiper-slide h-100">
                  <div data-anim-child="slide-left delay-3" class="infoCard -type-1">
                    <div class="infoCard__image">
                      <img src="{{ asset('template/img/home-3/learn/3.png') }}" alt="image">
                    </div>
                    <h5 class="infoCard__title text-17 lh-15 mt-10">JQuery</h5>
                  </div>
                </div>

                <div class="swiper-slide h-100">
                  <div data-anim-child="slide-left delay-4" class="infoCard -type-1">
                    <div class="infoCard__image">
                      <img src="{{ asset('template/img/home-3/learn/4.png') }}" alt="image">
                    </div>
                    <h5 class="infoCard__title text-17 lh-15 mt-10">CSS</h5>
                  </div>
                </div>

                <div class="swiper-slide h-100">
                  <div data-anim-child="slide-left delay-5" class="infoCard -type-1">
                    <div class="infoCard__image">
                      <img src="{{ asset('template/img/home-3/learn/5.png') }}" alt="image">
                    </div>
                    <h5 class="infoCard__title text-17 lh-15 mt-10">React Native</h5>
                  </div>
                </div>

                <div class="swiper-slide h-100">
                  <div data-anim-child="slide-left delay-6" class="infoCard -type-1">
                    <div class="infoCard__image">
                      <img src="{{ asset('template/img/home-3/learn/6.png') }}" alt="image">
                    </div>
                    <h5 class="infoCard__title text-17 lh-15 mt-10">Vue Js</h5>
                  </div>
                </div>

              </div>

              <div class="d-flex justify-center x-gap-15 items-center pt-60 lg:pt-40">
                <div class="col-auto">
                  <div class="pagination -arrows js-pagination"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div class="line px-50">
        <div class="line__item bg-light-5"></div>
      </div>

      <section class="layout-pt-lg layout-pb-lg">
        <div data-anim-wrap class="container">
          <div data-anim-child="slide-left delay-1" class="row y-gap-20 justify-between items-center">
            <div class="col-lg-6">

              <div class="sectionTitle ">

                <h2 class="sectionTitle__title ">Blog</h2>

                <p class="sectionTitle__text ">10,000+ unique online course list designs</p>

              </div>

            </div>

            <div class="col-auto">

              <a href="#" class="button -icon -purple-3 text-purple-1">
                Browse Blog
                <i class="icon-arrow-top-right text-13 ml-10"></i>
              </a>

            </div>
          </div>

          <div class="row y-gap-30 pt-60">

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-left delay-2" class="blogCard -type-1">
                <div class="blogCard__image">
                  <img src="{{ asset('template/img/home-3/blog/1.png') }}" alt="image">
                </div>
                <div class="blogCard__content mt-20">
                  <a href="blog-single.html" class="blogCard__category">EDUCATION</a>
                  <h4 class="blogCard__title text-17 lh-15 mt-5">Eco-Education in Our Lives: We Can Change the Future</h4>
                  <div class="blogCard__date text-14 mt-5">December 16, 2022</div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-left delay-3" class="blogCard -type-1">
                <div class="blogCard__image">
                  <img src="{{ asset('template/img/home-3/blog/2.png') }}" alt="image">
                </div>
                <div class="blogCard__content mt-20">
                  <a href="blog-single.html" class="blogCard__category">EDUCATION</a>
                  <h4 class="blogCard__title text-17 lh-15 mt-5">Eco-Education in Our Lives: We Can Change the Future</h4>
                  <div class="blogCard__date text-14 mt-5">December 16, 2022</div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-left delay-4" class="blogCard -type-1">
                <div class="blogCard__image">
                  <img src="{{ asset('template/img/home-3/blog/3.png') }}" alt="image">
                </div>
                <div class="blogCard__content mt-20">
                  <a href="blog-single.html" class="blogCard__category">EDUCATION</a>
                  <h4 class="blogCard__title text-17 lh-15 mt-5">Eco-Education in Our Lives: We Can Change the Future</h4>
                  <div class="blogCard__date text-14 mt-5">December 16, 2022</div>
                </div>
              </div>
            </div>

            <div class="col-lg-3 col-md-6">
              <div data-anim-child="slide-left delay-5" class="blogCard -type-1">
                <div class="blogCard__image">
                  <img src="{{ asset('template/img/home-3/blog/4.png') }}" alt="image">
                </div>
                <div class="blogCard__content mt-20">
                  <a href="blog-single.html" class="blogCard__category">EDUCATION</a>
                  <h4 class="blogCard__title text-17 lh-15 mt-5">Eco-Education in Our Lives: We Can Change the Future</h4>
                  <div class="blogCard__date text-14 mt-5">December 16, 2022</div>
                </div>
              </div>
            </div>


          </div>
        </div>
      </section>

      <section class="layout-pt-lg layout-pb-lg mb-90 section-bg">
        <div class="section-bg__item">
          <img class="img-full rounded-16" src="{{ asset('template/img/home-3/cta/bg.png') }}" alt="image">
        </div>

        <div class="container">
          <div class="row justify-center text-center">
            <div class="col-xl-5 col-lg-6 col-md-11">

              <div class="sectionTitle -light">

                <h2 class="sectionTitle__title ">Subscribe our Newsletter &</h2>

                <p class="sectionTitle__text ">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>

              </div>

            </div>
          </div>

          <div class="row mt-30 justify-center">
            <div class="col-lg-6">
              <form class="form-single-field -help" action="https://creativelayers.net/themes/educrat-html/post">
                <input type="text" placeholder="Your Email...">
                <button class="button -purple-1 text-white" type="submit">
                  Submit
                </button>
              </form>
            </div>
          </div>
        </div>
      </section>

      <footer class="footer -type-5 pt-60">
        <div class="container">
          <div class="row y-gap-30 pb-60">
            <div class="col-xl-3 col-lg-5 col-md-6">
              <div class="footer-header__logo">
                <img src="{{ asset('template/img/general/logo-dark.svg') }}" alt="logo">
              </div>

              <div class="mt-30">
                <div class="text-17 text-dark-1">Call Us</div>
                <div class="text-17 lh-1 fw-500 text-purple-1 mt-5">800 388 80 90</div>
              </div>

              <div class="mt-30 pr-20">
                <div class="lh-17">329 Queensberry Street, North Melbourne VIC 3051, Australia. hi@educrat.com</div>
              </div>

              <div class="footer-header-socials mt-30">
                <div class="footer-header-socials__list d-flex items-center">
                  <a href="#" class="size-40 d-flex justify-center items-center"><i class="icon-facebook"></i></a>
                  <a href="#" class="size-40 d-flex justify-center items-center"><i class="icon-twitter"></i></a>
                  <a href="#" class="size-40 d-flex justify-center items-center"><i class="icon-instagram"></i></a>
                  <a href="#" class="size-40 d-flex justify-center items-center"><i class="icon-linkedin"></i></a>
                </div>
              </div>
            </div>

            <div class="col-xl-2 col-lg-4 col-md-6">
              <div class="text-17 fw-500 text-dark-1 uppercase mb-25">ABOUT</div>
              <div class="d-flex y-gap-10 flex-column">
                <a href="{{ route('pages.about-1') }}">About Us</a>
                <a href="blog-list-1.html">Learner Stories</a>
                <a href="instructor-become.html">Careers</a>
                <a href="blog-list-1.html">Press</a>
                <a href="#">Leadership</a>
                <a href="{{ route('pages.contact-1') }}">Contact Us</a>
              </div>
            </div>

            <div class="col-xl-4 col-lg-8">
              <div class="text-17 fw-500 text-dark-1 uppercase mb-25">CATEGORIES</div>
              <div class="row justify-between y-gap-20">
                <div class="col-lg-auto col-md-6">
                  <div class="d-flex y-gap-10 flex-column">
                    <a href="{{ route('courses.single-1') }}">Development</a>
                    <a href="{{ route('courses.single-2') }}">Business</a>
                    <a href="{{ route('courses.single-3') }}">Finance & Accounting</a>
                    <a href="{{ route('courses.single-4') }}">IT & Software</a>
                    <a href="{{ route('courses.single-5') }}">Office Productivity</a>
                    <a href="{{ route('courses.single-6') }}">Design</a>
                    <a href="{{ route('courses.single-1') }}">Marketing</a>
                  </div>
                </div>

                <div class="col-lg-auto col-md-6">
                  <div class="d-flex y-gap-10 flex-column">
                    <a href="{{ route('courses.single-1') }}">Lifiestyle</a>
                    <a href="{{ route('courses.single-2') }}">Photography & Video</a>
                    <a href="{{ route('courses.single-3') }}">Health & Fitness</a>
                    <a href="{{ route('courses.single-4') }}">Music</a>
                    <a href="{{ route('courses.single-5') }}">UX Design</a>
                    <a href="{{ route('courses.single-6') }}">Seo</a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-xl-2 offset-xl-1 col-lg-4 col-md-6">
              <div class="text-17 fw-500 text-dark-1 uppercase mb-25">SUPPORT</div>
              <div class="d-flex y-gap-10 flex-column">
                <a href="terms.html">Documentation</a>
                <a href="help-center.html">FAQS</a>
                <a href="dashboard.html">Dashboard</a>
                <a href="{{ route('pages.contact-1') }}">Contact</a>
              </div>
            </div>
          </div>

          <div class="py-30 border-top-light">
            <div class="row justify-between items-center y-gap-20">
              <div class="col-auto">
                <div class="footer-footer__copyright d-flex items-center h-100">
                  � 2022 Educrat. All Right Reserved.
                </div>
              </div>

              <div class="col-auto">
                <div class="d-flex x-gap-20 y-gap-20 items-center flex-wrap">
                  <div>
                    <div class="d-flex x-gap-15">
                      <a href="help-center.html">Help</a>
                      <a href="terms.html">Privacy Policy</a>
                      <a href="terms.html">Cookie Notice</a>
                      <a href="terms.html">Security</a>
                      <a href="terms.html">Terms of Use</a>
                    </div>
                  </div>

                  <div>
                    <a href="#" class="button -md -light-4 px-20">
                      <i class="icon-worldwide mr-5"></i>English
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>


    </div>
  </main>

  <!-- JavaScript -->
  <script src="../../../unpkg.com/leaflet%401.7.1/dist/leaflet.js') }}" integrity="sha512-XQoYMqMTK8LvdxXYG3nZ448hOEQiglfqkJs1NOQV44cWnUrBc8PkAOcXy20w0vlaXaVUearIOBhiXZ5V3ynxwA==" crossorigin=""></script>
  <script src="{{ asset('template/js/vendors.js') }}"></script>
  <script src="{{ asset('template/js/main.js') }}"></script>
</body>
</html>
























